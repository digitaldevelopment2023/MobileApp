import React, { Component } from 'react';
import {AppRegistry, SafeAreaView, StyleSheet, StatusBar} from 'react-native';
import App from './App';
import {name as appName} from './app.json';
import { Provider } from 'react-redux';
import store from './app/store';  
import { MenuProvider } from 'react-native-popup-menu';

class MyApp extends Component {

    render() {
        return (
            <React.Fragment>
                 <StatusBar 
				barStyle = "light-content" 
				hidden = {false}
				backgroundColor = "#0C1F38"
				translucent = {false}
				networkActivityIndicatorVisible = {true}
            />
                <Provider store={store}>
                    <MenuProvider>
                        <App />
                    </MenuProvider>
                </Provider>              
            </React.Fragment>         
        );
    }
}

AppRegistry.registerComponent(appName, () => MyApp);