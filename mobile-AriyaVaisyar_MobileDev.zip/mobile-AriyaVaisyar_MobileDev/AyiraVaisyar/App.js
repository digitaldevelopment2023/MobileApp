import React, {Component} from "react";
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Thirukural from './app/Screens/thirukural/thirukural';
import Login from './app/Screens/login/login';
import Register from './app/Screens/register/register';
import Menu from './app/Screens/menu/menu';
import MembersApprove from './app/Screens/membersApprove/membersApprove';
import MembersApproveDetails from './app/Screens/membersApprove/membersApproveDetails';
import BloodDonor from './app/Screens/bloodDonor/bloodDonor';
import Profile from './app/Screens/profile/profile';
import ProfileEdit from './app/Screens/profileEdit/profileEdit';
import Festival from './app/Screens/festival/festival';
import Acknowledgement from './app/Screens/acknowledgement/acknowledgement';
import ErrorPage from './app/Screens/acknowledgement/errorPage'
import MatrimonyRegister from './app/Screens/matrimony/matrimonyRegister';
import FamilyRegister from './app/Screens/family/familyRegister';
import FamilyMembers from './app/Screens/family/familyMembers';
import EditFamily from './app/Screens/family/editFamily';
import Calendar from './app/Screens/calendar/calendar';
import AnnouncementMenu from './app/Screens/announcement/announcementMenu';
import News from './app/Screens/announcement/news';
import Wishes from './app/Screens/announcement/wishes';
import Announcement from './app/Screens/announcement/announcement ';
import Obituary from './app/Screens/announcement/obituary';
import MatrimonyDetails from './app/Screens/matrimony/matrimonyDetails';
import MatrimonyEdit from './app/Screens/matrimony/matrimonyEdit';
import MatrimonyList from './app/Screens/matrimony/matrimonyList';
import MatrimonyMenu from './app/Screens/matrimony/matrimonyMenu';
import MatrimonyFilter from './app/Screens/matrimony/matrimonyFilter'
import AnnouncementAddEdit from './app/Screens/announcement/announcementAddEdit';
import Friends from './app/Screens/friends/friends';
import EmploymentList from './app/Screens/employment/employmentList';
import EmploymentFilter from './app/Screens/employment/employmentFilter';
import EmploymentAdd from './app/Screens/employment/employmentAdd';
import EmploymentEdit from './app/Screens/employment/employmentEdit';
import EmploymentMenu from './app/Screens/employment/employmentMenu';
import BusinessMenu from './app/Screens/business/businessMenu';
import BusinessFilter from './app/Screens/business/businessFilter';
import BusinessAdd from './app/Screens/business/businessAdd';
import BusinessList from './app/Screens/business/businessList';
import BusinessEdit from './app/Screens/business/businessEdit';
import BusinessApproved from './app/Screens/business/businessApproved';
import BusinessDetails from './app/Screens/business/businessDetails';
import Payment from './app/Screens/payment/payment';
import TermsAndConditions from './app/Screens/payment/termsAndConditions';
import PaymentSuccess from './app/Screens/payment/paymentSuccess';



const Stack = createStackNavigator();

class App extends  Component {

	render(){
		return (
			<NavigationContainer>				
				<Stack.Navigator
					screenOptions={{
						headerShown: false
					}}
					>
						<Stack.Screen name ="Thirukural"  component={Thirukural}/>
						<Stack.Screen name ="Login"  component={Login}/>						
						<Stack.Screen name ="Register"  component={Register}/>
						<Stack.Screen name ="MembersApprove"  component={MembersApprove}/>
						<Stack.Screen name ="MembersApproveDetails"  component={MembersApproveDetails}/>
						<Stack.Screen name ="Menu"  component={Menu}/>
						<Stack.Screen name ="BloodDonor"  component={BloodDonor}/>
						<Stack.Screen name ="Profile"  component={Profile}/>
						<Stack.Screen name ="ProfileEdit"  component={ProfileEdit}/>
						<Stack.Screen name ="Festival"  component={Festival}/>
						<Stack.Screen name ="Acknowledgement"  component={Acknowledgement}/>
						<Stack.Screen name ="MatrimonyRegister"  component={MatrimonyRegister}/>
						<Stack.Screen name ="FamilyRegister"  component={FamilyRegister}/>
						<Stack.Screen name ="FamilyMembers"  component={FamilyMembers}/>
						<Stack.Screen name ="EditFamily"  component={EditFamily}/>
						<Stack.Screen name ="Calendar"  component={Calendar}/>
						<Stack.Screen name ="AnnouncementMenu"  component={AnnouncementMenu}/>
						<Stack.Screen name ="News"  component={News}/>
						<Stack.Screen name ="Wishes"  component={Wishes}/>
						<Stack.Screen name ="Announcement"  component={Announcement}/>
						<Stack.Screen name ="Obituary"  component={Obituary}/>
						<Stack.Screen name ="MatrimonyDetails"  component={MatrimonyDetails}/>
						<Stack.Screen name ="MatrimonyEdit"  component={MatrimonyEdit}/>
						<Stack.Screen name ="MatrimonyList"  component={MatrimonyList}/>
						<Stack.Screen name ="MatrimonyMenu"  component={MatrimonyMenu}/>
						<Stack.Screen name ="MatrimonyFilter"  component={MatrimonyFilter}/>
						<Stack.Screen name ="AnnouncementAddEdit"  component={AnnouncementAddEdit}/>
						<Stack.Screen name ="Friends"  component={Friends}/>
						<Stack.Screen name ="ErrorPage"  component={ErrorPage}/>
						<Stack.Screen name ="EmploymentMenu"  component={EmploymentMenu}/>
						<Stack.Screen name ="EmploymentList"  component={EmploymentList}/>
						<Stack.Screen name ="EmploymentFilter"  component={EmploymentFilter}/>
						<Stack.Screen name ="EmploymentAdd"  component={EmploymentAdd}/>
						<Stack.Screen name ="EmploymentEdit"  component={EmploymentEdit}/>
						<Stack.Screen name ="BusinessAdd"  component={BusinessAdd}/>
						<Stack.Screen name ="BusinessFilter"  component={BusinessFilter}/>
						<Stack.Screen name ="BusinessMenu"  component={BusinessMenu}/>
						<Stack.Screen name ="BusinessList"  component={BusinessList}/>
						<Stack.Screen name ="BusinessEdit"  component={BusinessEdit}/>
						<Stack.Screen name ="BusinessApproved"  component={BusinessApproved}/>
						<Stack.Screen name ="BusinessDetails"  component={BusinessDetails}/>
						<Stack.Screen name ="Payment"  component={Payment}/>
						<Stack.Screen name ="TermsAndConditions"  component={TermsAndConditions}/>
						<Stack.Screen name ="PaymentSuccess"  component={PaymentSuccess}/>
					</Stack.Navigator>
				</NavigationContainer>
			);
		}
	}

 /* Styles will be here */
 const styles = StyleSheet.create({
	container:{
		padding: 20,
		flexDirection:'row',
		alignItems:'center',
	},
	imgContainer:{
		width: 70,
		height: 70
	},
	avatar:{
		width: '100%',
		height:'100%',
		borderRadius: 35,
	},
 text:{
	fontFamily: 'Exo2-Regular',
	paddingLeft: 10,
	fontSize: 16,
	color: '#FFF',
	textTransform:'capitalize'
 }
});

export default App;
