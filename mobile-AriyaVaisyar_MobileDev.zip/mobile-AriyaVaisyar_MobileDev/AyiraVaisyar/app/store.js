import {
    createStore,
    applyMiddleware,
    compose
} from 'redux';
import thunk from 'redux-thunk';
import AsyncStorage from '@react-native-community/async-storage';
import rootReducer from './reducers/index';

import loginReducer from './reducers/loginReducer';
const initialState = {};

const middleware = [thunk];

const saveState = async function (state, next) {
    const newState = loginReducer(state.loginReducer, next);
    const serializedState = JSON.stringify(newState);
    await AsyncStorage.setItem("userInfo", serializedState);
}

const saveStateMiddleWare = store => next => action => {
    saveState(store.getState(), action);
    let result = next(action);
    return result;
}
const store = createStore(rootReducer,
    initialState, 
   compose(
       applyMiddleware(...middleware, saveStateMiddleWare),
       window.devToolsExtension ? window.devToolsExtension() : f => f
   
      // window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
   )
);

export default store;