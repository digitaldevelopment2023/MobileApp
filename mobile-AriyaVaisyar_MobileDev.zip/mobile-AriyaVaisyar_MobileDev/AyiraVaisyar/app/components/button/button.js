/* Package Import will lives here */
import React, { Component } from "react";
import {
  Platform,
  StyleSheet,
  Text,
  View,
  TouchableHighlight,
  Alert
} from "react-native";
/* Package Import will lives here */

/* Project Import will lives here */
import defaultTheme from "../../config/theme/default";
/* Project Import will lives here */

export default class Button extends Component {
  constructor(props) {
    super(props);   
  }
  static navigationOptions = {
    headerShown: false
  };

  render() {
    return (
      <View style={styles.btnContainer}>
        <TouchableHighlight
          underlayColor={defaultTheme.colors.darkPink}
		  style={[styles.button, this.props.style]}
		  value={this.props.value}
		  onPress={this.props.onPress}
		 
        >
          <Text style={[styles.buttonText,{ color: this.props.color, fontSize: this.props.size }]}>{this.props.btnName}</Text>
        </TouchableHighlight>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  btnContainer: {
	width: "100%",
	justifyContent:'center',
	alignItems:'center'
  },
  button: {
    width: 160,
    height: 55,
    margin: 10,
    // borderColor: defaultTheme.colors.white,
    // backgroundColor: defaultTheme.colors.white,
    justifyContent: "center",
    alignContent: "center",
    borderRadius: 6
  },
  buttonText: {
    textAlign: "center"
  }
});
