/* Package Import will lives here */
import React, { Component } from "react";
import { StyleSheet, View, TextInput, Text, Platform } from "react-native";
/* Package Import will lives here */

/* Project Import will lives here */
import defaultTheme from "../../config/theme/default";
/* Project Import will lives here */

export default class TextBox extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<View style={styles.textContainer}>
				<Text style={styles.searchIcon}>{this.props.iconName}</Text>
				<TextInput
					style={[styles.textBox, this.props.style]}
					secureTextEntry={this.props.isPassword !== undefined }
					editable={this.props.isEditable == undefined }
					placeholder={this.props.placeholder}
					value={this.props.value}
					multiline={this.props.multiline}
					numberOfLines={this.props.numberOfLines}					
					autoCapitalize="none"
					keyboardType={this.props.keyboardType == 'number' ? 'numeric' :'email-address'}
					// keyboardType = 'numeric'
					placeholderTextColor={this.props.placeholderTextColor}
					onChangeText={(text) => { this.props.onChange(text) }}
				/>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	textContainer: {
		flexDirection: "row",
		justifyContent: "center",
		alignItems: "center",
		width: "100%"
	},
	searchIcon: {
		padding: 10,
		position: 'absolute',
		left: 0,
		color: defaultTheme.colors.white
	},
	textBox: {
		paddingLeft: 18,
		fontSize:16,
		color: defaultTheme.colors.white,
		width: "100%",		
		borderWidth: 1,
		borderColor: defaultTheme.colors.gray,
		borderWidth: 1,
	}
});
