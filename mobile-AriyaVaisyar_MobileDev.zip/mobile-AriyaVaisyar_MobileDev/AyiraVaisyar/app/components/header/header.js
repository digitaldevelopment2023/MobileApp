/* Package JSON Import will be here */
import React, { Component } from "react";
import { View, StyleSheet, Text, Image, TouchableOpacity,BackHandler,Alert, Button} from "react-native";
// import { DrawerActions } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from '../../actions/loginAction';
import AsyncStorage from '@react-native-community/async-storage';
/* Project Import will lives here */

import defaultTheme from "../../config/theme/default";
import FUI from '../../assets/fui/fui';


/* Project Import will lives here */
class Header extends Component {
	constructor(props) {
		super(props);
	}
static navigationOptions = {
    headerShown: false
  };

  componentDidMount() {		
	BackHandler.addEventListener("hardwareBackPress", this.handleBackPress);
  }

  componentWillUnmount() {		
	BackHandler.removeEventListener("hardwareBackPress", this.handleBackPress);
  }

  handleBackPress = () =>{
	if(this.props.title === "முகப்பு"|| this.props.title === "Thirukural" || this.props.title === "Login" || this.props.title === "நன்றி"){
		Alert.alert(
			'Exit App',
			'Are you sure you want to Exit ?', [{
				text: 'Cancel',				
				style: 'cancel'
			}, {
				text: 'OK',
				onPress: ()=> {BackHandler.exitApp()}
			}, ], {
				cancelable: false
			}
		 )			
		return true;
	}		
	else{
		this.props.navigation.goBack();
		return true;
	}
};
  
async logout (){
    await AsyncStorage.clear();  
  //  this.props.login(''); 
    this.props.navigation.navigate("Login");	 
}
	
render() {
	return (
		<React.Fragment>
			{this.props.title =="Login" ?
			<View/>: (this.props.title === "Home") ||  (this.props.title === "Thirukural") ?		
			<View style={styles.Container}>
				<View style={styles.homeLeftMenu}>
				{/* <TouchableOpacity onPress={()=>this.props.navigation.dispatch(DrawerActions.openDrawer())}>	
					<FUI name="menu" size={25}  style={styles.icons}/>
				</TouchableOpacity> */}
					<Text style={styles.headerTitle}>{this.props.title}</Text>
				</View>
			</View> : (this.props.title === "பதிவுபெறு") ?
			<View style={styles.Container}>
				<View style={styles.homeLeftMenu}>
					<TouchableOpacity onPress={() => this.props.navigation.goBack()}>	
						<Icon name="arrow-back" style={styles.menuIcon} />
					</TouchableOpacity>
					<Text style={styles.headerTitle}>{this.props.title}</Text>
				</View>
			</View>: (this.props.title === "முகப்பு") ?
			<View style={styles.Container}>
				<View style={styles.homeLeftMenu}>
					<TouchableOpacity onPress={() => this.props.navigation.navigate("Menu")}>	
						<Icon name="home" style={styles.menuIcon} />
					</TouchableOpacity>
					<Text style={styles.headerTitle}>{this.props.title}</Text>
				</View>
			<View style={styles.homeRightMenu}>			
			<TouchableOpacity onPress={() => this.logout()}>				
				<Icon name="exit-to-app" style={styles.logout} />
			</TouchableOpacity>
			</View>
		</View> :
		<View style={styles.Container}>
		<View style={styles.homeLeftMenu}>
			<TouchableOpacity onPress={() => this.props.navigation.goBack()}>	
				<Icon name="arrow-back" style={styles.menuIcon} />
			</TouchableOpacity>
			<Text style={styles.headerTitle}>{this.props.title}</Text>
		</View>
	<View style={styles.homeRightMenu}>			
	<TouchableOpacity onPress={() => this.logout()}>				
		<Icon name="exit-to-app" style={styles.logout} />
	</TouchableOpacity>
	</View>
</View>
			}
		</React.Fragment>
	);
}
}

/* Styles will be here */
const styles = StyleSheet.create({	
	Container: {
		flexDirection: "row",
		minHeight: 56,
		maxHeight: 56,
		paddingTop: 0,
		borderColor: defaultTheme.colors.primary,
		borderBottomWidth: 1,
		backgroundColor: defaultTheme.colors.primary
	},
	headerTitle:{
		color: defaultTheme.colors.white,
		fontSize: 17,
		paddingLeft: 10,
		paddingTop: 5,
		fontFamily: 'MeeraInimai-Regular',	
	},
	homeLeftMenu: {
		flex: 5,
		flexDirection: "row",
		justifyContent:'flex-start',
		alignItems:'center',
	},
	reqLeftMenu: {
		flex: 3,
		flexDirection: "row",
		justifyContent:'flex-start',
		alignItems:'center',
	},
	reqRightMenu: {
		flex: 1,
		flexDirection: "row",
		justifyContent:'flex-start',
		alignItems:'center',
	},
	icons:{
		color: defaultTheme.colors.white,
		paddingLeft: 15
	},
	menuIcon:{
		color: defaultTheme.colors.white,
		paddingLeft: 15,
		fontSize: 25
	},
	logout:{
		fontSize: 22,
		color: defaultTheme.colors.white,
		alignItems:'center',
		paddingTop: 12,
		paddingRight: 15,
	},
	verified:{
		fontSize: 22,
		color: defaultTheme.colors.green,
		alignItems:'center',
		paddingTop: 12,
		paddingRight: 18,	
	},
	notVerified:{
		fontSize: 22,
		color: defaultTheme.colors.red,
		alignItems:'center',
		paddingTop: 12,
		paddingRight: 18,
		position:'absolute',
		right: 5
	},
	rating:{
		color: defaultTheme.colors.darkYellow,
		alignItems:'center',
		paddingTop: 12,
		paddingRight: 10,
	},
	star:{
		fontSize: 22,
		color: defaultTheme.colors.yellow,
		alignItems:'center',
		paddingTop: 12,
		paddingRight: 5,
	},
	leftMenu: {
		flex: 4,
		flexDirection: "row"
	},
	rightMenu: {
		flex: 1,
		flexDirection: "row"
	},
	});

/* Styles will be here */

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(
        Object.assign(
            {},
            actions,
        ), dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Header);

