/* Package Import will lives here */
import React, { Component } from "react";
import {StyleSheet,View,ActivityIndicator,} from "react-native";
/* Package Import will lives here */

/* Project Import will lives here */
import defaultTheme from "../../config/theme/default";
/* Project Import will lives here */

class Loader extends Component {
	constructor(props) {
		super(props);		
    }	
    
	static navigationOptions = {
		header: null,
    };
    
	render() {
		return (
            <View style={styles.container}>
               <View style={[styles.container, styles.horizontal]}>
                    <ActivityIndicator size="large" color="#00597b"  />
               </View>
            </View>
		);
	}
}

const styles = StyleSheet.create({
	container: {
        flex: 1,       
        paddingHorizontal:10, 
        paddingBottom:10,
        justifyContent: 'center',
        alignItems: 'center',       
        marginTop:70
    },
    horizontal: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        padding: 10,       
      },
});

export default Loader;
