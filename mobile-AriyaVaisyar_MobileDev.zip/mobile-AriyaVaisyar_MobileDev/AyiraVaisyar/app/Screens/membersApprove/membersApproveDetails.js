/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,	
	TouchableOpacity,
	Animated,
	ImageBackground,
	Image,
	ActivityIndicator,
    ScrollView,
} from "react-native";
import Icon from 'react-native-vector-icons/MaterialIcons';
import moment from 'moment';
import { connect } from 'react-redux';
/* Project Import will lives here */
import {Header, TextBox, Button} from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import axios from 'axios';
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import Modal from 'react-native-modal';

class MembersApproveDetails extends Component {
	constructor(props) {
		super(props);
		this.state = {
            memberDetails: props.route.params.memberDetails,		
			isLoading: false,
            isModalVisible: false,
		}
    }
    
    memberApprove =(id)=>{
		this.setState({isLoading: true,isModalVisible:false});
			apiService(`/api/admin/user/approved`, 'put', {
                adminId : this.props.user.data.DATA.id,
                adminType: this.props.user.data.USERTYPE,
                userId: [this.state.memberDetails.id],
                status: id
            },'',this.props.user.data.JWT,
			(result) => { 
				if(result.status === 200 ){
					this.setState({
                    memberList: result.data.totalUsers,
					totalPageSize:  result.data.totalCount,
					totalPage:  result.data.totalPages,
                    isLoading: false});
                    this.props.navigation.navigate('MembersApprove', { refresh: true });
				}
				else {  
					this.setState({isLoading: false}); 				
				}
			},
			(error) => {
				this.setState({isLoading: false});
			});
      }
      
      componentDidUpdate(prevProps) {
        var params = this.props.route.params;
        if (params && params.refresh) {
            this.memberApprove();
            this.props.route.params.refresh = false;
        }
	}

    openModal = (id) => {
        if(id == 1){
            this.setState({ isModalVisible: true, selectedId: id,popMessage:"நீங்கள் அங்கீகரிக்க விரும்புகிறீர்களா?" });
        }else{
            this.setState({ isModalVisible: true, selectedId: id,popMessage:"நீங்கள் நிராகரிக்க விரும்புகிறீர்களா?" });

        }
    };

    cancelModal = () => {
        this.setState({ isModalVisible: false, selectedId: "" });
    };
 
	render() {
		return (			
			<React.Fragment>
					<Header title="உறுப்பினர் விவரங்கள்" navigation={this.props.navigation}/>
                    <ScrollView>				
				<View style={styles.container}>	
					<View style={styles.bg}>
                        <View style={styles.cardbg}>
                            <View style={styles.userPic}>
                                <View style={styles.img}>
                                {this.state.memberDetails.profileImage != null ?
                                    <Image style={styles.profile} source={{uri: `${ApiUrls.apiEnvironment}`+ this.state.memberDetails.profileImage}} />
                               :<Image key={this.state.time} style={styles.profile} source={require("../../assets/images/profileDefault.jpg")} />}
                                    </View>
                            </View>
                            <View style={styles.mainContainer}>
                               <View style={styles.row}>
                                   <Text style={styles.title}>பெயர்  : </Text>
                                   <Text style={styles.content}>{this.state.memberDetails.name} </Text>
                               </View>
                               <View style={styles.row}>
                                   <Text style={styles.title}>தந்தையின் பெயர் : </Text>
                                   <Text style={styles.content}>{this.state.memberDetails.fathersname} </Text>
                               </View>
                               <View style={styles.row}>
                                   <Text style={styles.title}>பாலினம்  : </Text>
                                   <Text style={styles.content}>{this.state.memberDetails.gender} </Text>
                               </View>
                               <View style={styles.row}>
                                   <Text style={styles.title}>பிறந்த தேதி  : </Text>
                                   <Text style={styles.content}>{moment(this.state.memberDetails.dateOfBirth).format("DD/MM/YYYY")} </Text>
                               </View>
                               <View style={styles.row}>
                                   <Text style={styles.title}>கல்வி  : </Text>
                                   <Text style={styles.content}>{this.state.memberDetails.education.educationName} </Text>
                               </View>
                               <View style={styles.row}>
                                   <Text style={styles.title}>தொழில்  : </Text>
                                   <Text style={styles.content}>{this.state.memberDetails.occupationId.occupationName} </Text>
                               </View>
                               <View style={styles.row}>
                                   <Text style={styles.title}>கைபேசி எண் : </Text>
                                   <Text style={styles.content}>{this.state.memberDetails.phone} </Text>
                               </View>
                               <View style={styles.row}>
                                   <Text style={styles.title}>ஆயிரவைசியரில் உட்பிரிவு : </Text>
                                   <Text style={styles.content}>{this.state.memberDetails.sect} </Text>
                               </View>
                            </View>
                        </View>
                    </View>
                    <View style={styles.placeContainer}>
                       <View style={styles.row}>
                       <View style={styles.iconContainer}>
								{SvgImages.state(40, 40)}
							</View>
                            <View style={styles.textContent}>
                                <Text style={styles.place}>மாவட்டம் : {this.state.memberDetails.district.districtName}  </Text>
                                <Text style={styles.place}>தாலுகா : {this.state.memberDetails.taluk.talukName}  </Text>
                            </View>
                       </View>
                       <View style={styles.btnContainer}>
                            <TouchableOpacity onPress={()=> this.openModal(2)}>
                                <Text style={styles.btn}>நிறுத்திவை</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={()=> this.openModal(1)}>
                                <Text style={styles.btnAccept}>ஒப்புதல்</Text>
                            </TouchableOpacity>
                       </View>
                    </View>
				</View>
                <Modal isVisible={this.state.isModalVisible}
                    animationInTiming={1000}
                    animationOutTiming={1000}
                    backdropTransitionInTiming={800}
                    backdropTransitionOutTiming={800}
                >
                    <View style={styles.popup}>
                        <Text style={styles.confirmText}>{this.state.popMessage}</Text>
                        <View style={styles.popupbtn}>
                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                <Text style={styles.popUpCancel}>ரத்து</Text>
                            </TouchableOpacity>
                            {this.state.selectedId == 1 ?  <TouchableOpacity style={styles.popbtn} onPress={() => this.memberApprove(1)}>
                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                            </TouchableOpacity> :  <TouchableOpacity style={styles.popbtn} onPress={() => this.memberApprove(2)}>
                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                            </TouchableOpacity> }
                          
                        </View>
                    </View>
                </Modal>
                </ScrollView>
			</React.Fragment>
		)}
	}
	const styles = StyleSheet.create({	
		container:{
			flex: 1,
        },
        bg:{
            backgroundColor: defaultTheme.colors.primary,
            height: 300
        },
        row:{
            flexDirection:'row',
        },        
        cardbg:{
            backgroundColor: '#EAEEF3',
            height: 400,
            margin: 20,
            marginTop: 70,
            borderRadius: 10
        },
        userPic:{
            flexDirection:'row',
            justifyContent:'center'
		},
		profile:{
			width: '100%',
            height: '100%',
            borderRadius: 45,
            marginTop: -45
        },
        img:{
            width:90,
            height: 90,
        },
        title:{
            fontFamily: 'MeeraInimai-Regular',
            fontWeight:'bold',
            color: defaultTheme.colors.gray,
            paddingTop: 15
        },
        content:{
            fontFamily: 'MeeraInimai-Regular',
            color: defaultTheme.colors.gray,
            fontSize: 16,
            paddingTop: 15
        },
        mainContainer:{
            marginTop: -45,
            padding: 15
        },
        placeContainer:{
            backgroundColor: defaultTheme.colors.primary,
            marginTop: 190,
            margin: 15,
            borderRadius: 10,
            paddingTop: 10,
            paddingBottom: 25,
            paddingHorizontal: 10
        },
        place:{
            color: defaultTheme.colors.white,
            fontFamily: 'MeeraInimai-Regular',
            fontSize: 15
        },
        placeIcon:{
            color: defaultTheme.colors.white,
            fontSize: 70
        },
        textContent:{
            paddingLeft: 18,
            paddingTop: 10
        },
        btnContainer:{
            flexDirection:'row',
            justifyContent:'space-around',
            marginTop: 10
        },
        btn:{
            backgroundColor: defaultTheme.colors.red,
            color:defaultTheme.colors.white,
            paddingVertical: 10,
            paddingHorizontal: 10,
            borderRadius: 5
        },
        btnAccept:{
            width: 120,
            textAlign:'center',
            backgroundColor: defaultTheme.colors.white,
            color:defaultTheme.colors.primary,
            paddingVertical: 10,
            paddingHorizontal: 10,
            borderRadius: 5
        },
        iconContainer:{
            paddingTop: 10,
            paddingLeft:23,
            width:62
        },
           // popup start
    popup: {
        backgroundColor: "#fff",
        height: 150,
    },
    confirmText: {
        marginTop: 20,
        textAlign: 'center',
        justifyContent: 'center',
        fontFamily: 'MeeraInimai-Regular',
    },
    popbtn: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20
    },
    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    // popup end
    });
    
	function mapStateToProps(state) {
		return {
			user: state.loginReducer.user,
		};
	}	
export default connect(mapStateToProps)(MembersApproveDetails);
