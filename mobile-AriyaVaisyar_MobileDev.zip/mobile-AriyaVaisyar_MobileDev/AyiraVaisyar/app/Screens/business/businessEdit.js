/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    FlatList,
    Image,
    ActivityIndicator,
    TextInput,
    ScrollView,
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import Toast from 'react-native-simple-toast';
import moment from 'moment';
import Icon from 'react-native-vector-icons/MaterialIcons';
import DateTimePicker from "react-native-modal-datetime-picker";
import ImagePicker from 'react-native-image-picker';

class BusinessEdit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            businessInfo: props.route.params.businessInfo,
            defaultCountry: '',
            defaultState: '',
            country: [],
            stateList: [],
            districtList: [],
            talukList: [],
            bloodDonorList: [],
            occupation: [],
            pageNo: 1,
            pageSize: 50,
            totalPageSize: 0,
            totalPage: 0,
            isLoading: true,
            districtId: '',
            occupationID: '',
            talukId: '',
            countryName: '',
            stateName: '',
            description: props.route.params.businessInfo.details,
            addressAndLocation: props.route.params.businessInfo.addressAndLocation,
            contact: props.route.params.businessInfo.contactDetails,
            countryName: '',
            stateName: '',
            picOne: '',
			picTwo: '',
            picOneData: '',
			picTwoData: '',
            picOneSource: '',
			picTwoSource: '',
            picOneId: props.route.params.businessInfo.picOneId,
			picTwoId: props.route.params.businessInfo.picTwoId,
            picOneIdCheck: props.route.params.businessInfo.picOneId,
			picTwoIdCheck: props.route.params.businessInfo.picTwoId,
            createdAt: moment(props.route.params.businessInfo.createdAt).format("YYYY-MM-DD"),
        }
    }

    componentDidMount() {
        this.FormList();
    }
    
    selectPhotoTapped = (num) => {
		const options = {
			quality: 1.0,
			maxWidth: 500,
			maxHeight: 500,
			includeBase64: true,
			storageOptions: {
				skipBackup: true,
				privateDirectory: true
			}
		};

		ImagePicker.showImagePicker(options, (response) => {
			console.log('Response = ', response);
			if (response.didCancel) {
				console.log('User cancelled photo picker');
			}
			else if (response.error) {
				console.log('ImagePicker Error: ', response.error);
			}
			else if (response.customButton) {
				console.log('User tapped custom button: ', response.customButton);
			}
			else {
				var source = {
					uri: response.uri,
					type: response.type,
					name: response.fileName,
					height: response.height,
					width: response.width,
					// 	Platform.OS === "android" ? response.uri : response.uri.replace("file:/", "")
				};
				if (num == 1) {
					this.setState({
						picOneData: source,
                        picOneIdCheck:null,
						picOneSource: "data:image/jpeg;base64," + response.data,
					});
				} else {
					this.setState({
						picTwoData: source,
                        picTwoIdCheck:null,
						picTwoSource: "data:image/jpeg;base64," + response.data,
					});
				}

			}
		});
	}

	removePhoto = (num) => {
		if (num == 1) {
			this.setState({ picOne: "", picOneSource: "",picOneIdCheck:null });
		} else {
			this.setState({ picTwo: "", picTwoSource: "",picTwoIdCheck:null });
		}
    }

    FormList() {
        FormList((FormList) => {
            var item = [];
            FormList.data.business.map(val => {
                item.push({
                    value: val.label,
                    label: val.label,
                })
            })
            var item2 = [];
            FormList.data.country.map(val => {
                if (val.label == this.props.route.params.businessInfo.country) {
                    this.statesGetCall(val.value)
                }
                item2.push({
                    value: val.label,
                    label: val.label,
                    id: val.value
                })
            })
            this.setState({
                occupation: item,
                country: item2,
                defaultOccupation: this.props.route.params.businessInfo.businessName,
                occupationID: this.props.route.params.businessInfo.businessName,
                defaultCountry: this.props.route.params.businessInfo.country,
                countryName: this.props.route.params.businessInfo.country,
                stateName: this.props.route.params.businessInfo.state,
                district: this.props.route.params.businessInfo.district,
                
                taluk: this.props.route.params.businessInfo.taluk,
            });
            console.log("gjhghj"+this.state.district)
        });
    }
    statesGetCall(id) {
        apiService(`/unsecure/mobile/statelist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    var item = [];
                    if (result.data != "") {
                        result.data.map(val => {
                            if (val.label == this.props.route.params.businessInfo.state) {
                                var item2 = [];
                                apiService(`/unsecure/mobile/districtlist/${val.value}`, 'get', '', false, '',
                                    (result) => {
                                        if (result.status === 200) {
                                            var item1 = [];
                                            result.data.map(val => {
                                                if (val.label == this.props.route.params.businessInfo.district) {
                                                    apiService(`/unsecure/mobile/taluklist/${val.value}`, 'get', '', false, '',
                                                        (result) => {
                                                            if (result.status === 200) {
                                                                var item2 = [];
                                                                result.data.map(val => {
                                                                    item2.push({
                                                                        value: val.label,
                                                                        label: val.label,
                                                                        id: val.value
                                                                    })
                                                                })
                                                                this.setState({ talukList: item2, defaultTaluk: this.props.route.params.businessInfo.taluk, isLoading: false });
                                                            }
                                                        },
                                                        (error) => {
                                                        });
                                                }
                                                item1.push({
                                                    value: val.label,
                                                    label: val.label,
                                                    id: val.value
                                                })
                                            })
                                            this.setState({ districtList: item1, defaultDistrict: this.props.route.params.businessInfo.district });
                                        }
                                    },
                                    (error) => {
                                    });
                            }
                            item.push({
                                value: val.label,
                                label: val.label,
                                id: val.value
                            })
                        })
                        this.setState({ stateList: item, defaultState: this.props.route.params.businessInfo.state, stateName: this.props.route.params.businessInfo.state })
                    }
                }
            },
            (error) => {
            });
    }

    states = (id, name) => {
        this.setState({
            countryId: id, countryName: name, stateLoader: true, stateList: [], defaultState: null, stateId: '',
            defaultTaluk: null, defaultDistrict: null, districtId: '', talukId: '', districtList: [], talukList: [],
        });
        apiService(`/unsecure/mobile/statelist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    var item = [];
                    result.data.map(val => {
                        item.push({
                            value: val.label,
                            label: val.label,
                            id: val.value
                        })
                    })
                    this.setState({ stateList: item, stateLoader: false });
                }
            },
            (error) => {
                this.setState({ stateLoader: false });
            });
    }

    district = (id, name) => {
        this.setState({ stateId: id, stateName: name, errMessage: '', defaultTaluk: null, defaultDistrict: null, districtId: '', talukId: '', districtList: [], talukList: [] });
        apiService(`/unsecure/mobile/districtlist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    var item = [];
                    result.data.map(val => {
                        item.push({
                            value: val.label,
                            label: val.label,
                            id: val.value
                        })
                    })
                    this.setState({ districtList: item });
                }
            },
            (error) => {
            });
    }

    taluk = (id, name) => {
        this.setState({ districtId: id, district: name, isDistrictLoading: true, defaultTaluk: null, errMessage: '' });
        apiService(`/unsecure/mobile/taluklist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    console.log(result.data);
                    var item = [];
                    result.data.map(val => {
                        item.push({
                            value: val.label,
                            label: val.label,
                            id: val.value
                        })
                    })
                    this.setState({ talukList: item });
                }
            },
            (error) => {
            });
    }

    occupation = (id) => {
        this.setState({ occupationID: id, errMessage: '' });
    }
    occupation = (id) => {
        // this.checkValidation(id,"OCCUPATION")
        this.setState({ occupationID: id, errMessage: '' });
    }
    checkValidation = (param, type) => {
        var valid = true;
        this.setState({
            errMessage: this.state.districtId != "" ? "" : this.state.errMessage, errMessage: this.state.talukId != "" ? "" : this.state.errMessage,
            errMessage: this.state.occupationID != "" ? "" : this.state.errMessage,
            errMessage: this.state.contact != "" ? "" : this.state.errMessage,
            errMessage: this.state.salary != "" ? "" : this.state.errMessage,
            errMessage: this.state.addressAndLocation != "" ? "" : this.state.errMessage,
            errMessage: this.state.description != "" ? "" : this.state.errMessage,
        })
        switch (type) {
              case "contact":
                if (param.length < 3) {
                    this.setState({ errMessage: "Please enter phone or email" })
                    valid = false;
                }
                break;
            case "addressAndLocation":
                if (param.length < 3) {
                    this.setState({ errMessage: "Please enter address & location" })
                    valid = false;
                }
                break;
            case "description":
                if (param.length < 3) {
                    this.setState({ errMessage: "Please enter details" })
                    valid = false;
                }
                break;

            default:
        }

    }
    submitData = () => {
        if (this.validation()) {
            this.setState({ isLoading: true });
            let formData = new FormData();
            formData.append('id', this.props.route.params.businessInfo.id)
            formData.append('userId', this.props.user.data.DATA.id)
			formData.append('businessName', this.state.occupationID)
			formData.append('country', this.state.countryName)
			formData.append('state', this.state.stateName)			
			formData.append('district', this.state.district)
			formData.append('taluk', this.state.taluk)
			formData.append('contactDetails', this.state.contact)
			formData.append('addressAndLocation', this.state.addressAndLocation)
			formData.append('details', this.state.description)	
            formData.append('createdAt',  this.state.createdAt)	
            formData.append('createdBy', this.props.route.params.businessInfo.createdBy);
            formData.append('isActive', this.props.route.params.businessInfo.isActive);
            formData.append('isSuperAdmin', this.props.route.params.businessInfo.isSuperAdmin);		

			{
                this.state.picOneId != null ?
                    formData.append('picOneId', this.state.picOneId) : null
            }
            {
                this.state.picTwoId != null ?
                    formData.append('picTwoId', this.state.picTwoId) : null
            }

            {
                this.state.picOneSource != "" ?
                    formData.append('picOne', this.state.picOneData) : null
            }
            {
                this.state.picTwoSource != "" ?
                    formData.append('picTwo', this.state.picTwoData) : null
            }

			apiService(`/api/business`, 'put', formData, true, this.props.user.data.JWT,
				(result) => {
                    if (result.status === 200) {
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                        this.setState({ isLoading: false });
                        this.props.navigation.navigate("BusinessList", { taluk: null, district: null, refresh: true })
                    }
                    else {
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                    }
                },
                (error) => {
                    Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
                });

        }
    }


    validation = () => {
        const {district, taluk, stateName, countryName,occupationID, salary, addressAndLocation, description, contact, isChecked } = this.state;
        var valid = true
        this.setState({
            errMessage: this.state.districtId != "" ? "" : this.state.errMessage, errMessage: this.state.talukId != "" ? "" : this.state.errMessage,
            errMessage: this.state.occupationID != "" ? "" : this.state.errMessage,
            errMessage: this.state.contact != "" ? "" : this.state.errMessage,
            errMessage: this.state.salary != "" ? "" : this.state.errMessage,
            errMessage: this.state.addressAndLocation != "" ? "" : this.state.errMessage,
            errMessage: this.state.description != "" ? "" : this.state.errMessage,
            errMessage: this.state.stateId != "" ? "" : this.state.errMessage,
        });
        if (occupationID == "") {
            this.setState({ errMessage: "Please select Occupation" })
            valid = false;
        }
        else if (countryName == "") {
            this.setState({ errMessage: "Please select your country" })
            valid = false;
        }
        else if (stateName == "") {
            this.setState({ errMessage: "Please select your state" })
            valid = false;
        }
        else if (district == "") {
            this.setState({ errMessage: "Please select your district" })
            valid = false;
        }
        else if (taluk == "") {
            this.setState({ errMessage: "Please select your taluk" })
            valid = false;
        }
        else if (contact == "") {
            this.setState({ errMessage: "Please enter phone or email" })
            valid = false;
        }
        else if (addressAndLocation == "") {
            this.setState({ errMessage: "Please enter address & location" })
            valid = false;
        }
        else if (description == "") {
            this.setState({ errMessage: "Please enter details" })
            valid = false;
        }
        return valid;
    }



    render() {
        return (
            <React.Fragment>
                <Header title="வணிகம் திருத்து" navigation={this.props.navigation} />
                <ScrollView>
                    {this.state.isLoading === true ?
                        <Loader /> :
                        <View style={styles.container}>
                            <View style={styles.placeContainer}>
                                <Text style={styles.lable}>தொழில் (Occupation) <Text style={styles.mandatory}>*</Text> </Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.occupation}
                                        containerStyle={{ height: 50 }}
                                        defaultValue={this.state.defaultOccupation}
                                        placeholder="தொழில்"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.lighterGray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.occupation(item.label)}
                                    />
                                </View>
                                <Text style={styles.lable}>நாடு (Country) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.country}
                                        defaultValue={this.state.defaultCountry}
                                        containerStyle={{ height: 50 }}
                                        placeholder="நாடு"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.states(item.id, item.label)}
                                    />
                                </View>

                                <Text style={styles.lable}>மாநிலம் (State) <Text style={styles.mandatory}>*</Text> </Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.stateList}
                                        defaultValue={this.state.defaultState}
                                        containerStyle={{ height: 50 }}
                                        placeholder="மாநிலம்"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.district(item.id, item.label)}
                                    />
                                </View>

                                <Text style={styles.lable}>மாவட்டம் (District) <Text style={styles.mandatory}>*</Text> </Text>
                                <View style={styles.district}>
                                    <DropDownPicker
                                        dropDownMaxHeight={100}
                                        items={this.state.districtList}
                                        defaultValue={this.state.defaultDistrict}
                                        containerStyle={{ height: 50 }}
                                        placeholder="மாவட்டம்"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        max={3}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.taluk(item.id, item.label)}
                                    />

                                </View>
                                <Text style={styles.lable}>தாலுகா (Taluk) <Text style={styles.mandatory}>*</Text> </Text>
                                <View style={styles.taluk}>
                                    <DropDownPicker
                                        dropDownMaxHeight={100}
                                        items={this.state.talukList}
                                        defaultValue={this.state.defaultTaluk}
                                        containerStyle={{ height: 50 }}
                                        placeholder="தாலுகா"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        max={3}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.setState({ talukId: item.value, taluk: item.label, defaultTaluk: item.value, errMessage: '' })}
                                    />
                                </View>
                                <Text style={styles.lable}>தொடர்புகொள்ள (Phone or Email) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.textContainer}>
                                    <TextBox
                                        style={styles.textBox}
                                        placeholder="தொடர்புகொள்ள (Phone or Email)"
                                        borderWidth={1}
                                        placeholderTextColor={defaultTheme.colors.lighterGray}
                                        value={this.state.contact}
                                        onChange={contact => { this.setState({ contact: contact }, this.checkValidation(contact, "contact")) }}
                                    />
                                </View>
                                <Text style={styles.lable}>முகவரி & இருப்பிடம் (Address & Location) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.textContainer}>
                                    <TextInput
                                        style={styles.textarea}
                                        value={this.state.addressAndLocation}
                                        numberOfLines={3} maxLength={150} multiline={true} onChangeText={(addressAndLocation) => this.setState({ addressAndLocation: addressAndLocation }, this.checkValidation(addressAndLocation, "addressAndLocation"))} />
                                    <Text>{150 - this.state.addressAndLocation.length}/150 Characters</Text>
                                </View>

                                <Text style={styles.lable}>விவரங்கள் (Details) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.textContainer}>
                                    <TextInput
                                        style={styles.textarea}
                                        value={this.state.description}
                                        numberOfLines={3} maxLength={500} multiline={true} onChangeText={(description) => this.setState({ description: description }, this.checkValidation(description, "description"))} />
                                    <Text>{500 - this.state.description.length}/500 Characters</Text>
                                </View>                              
                            </View>
                            


                            <View style={styles.row}>
                                <Text style={styles.lable}>வணிக படம் </Text>
                                {(this.state.picOneIdCheck == null) && (this.state.picOneSource == "") ?
                                    <TouchableOpacity style={styles.imageplaceholder} onPress={() => this.selectPhotoTapped(1)}>
                                        <Icon name="add" style={styles.plus} />
                                    </TouchableOpacity> :
                                    <View style={styles.registrProfileDesign}>
                                        {this.state.picOneIdCheck != null ?
                                            <Image key={454} source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + this.state.picOneId + "?" + this.state.time }} style={{ width: '100%', height: '100%' }} />
                                            : <Image key={581} source={{ uri: this.state.picOneSource }} style={{ width: '100%', height: '100%' }} />}
                                    </View>}
                                {(this.state.picOneIdCheck != null) || (this.state.picOneSource != "") ?
                                    <TouchableOpacity style={styles.deleteIcon} onPress={() => this.removePhoto(1)}>
                                        {SvgImages.deleteIcon(20, 20)}
                                    </TouchableOpacity>

                                    : null}
                            </View>


                            <View style={styles.row}>
                                <Text style={styles.lable}>வணிக படம் </Text>
                                {(this.state.picTwoIdCheck == null) && (this.state.picTwoSource == "") ?
                                    <TouchableOpacity style={styles.imageplaceholder} onPress={() => this.selectPhotoTapped(2)}>
                                        <Icon name="add" style={styles.plus} />
                                    </TouchableOpacity> :
                                    <View style={styles.horoscopePicDesign}>
                                        {this.state.picTwoIdCheck != null ?
                                            <Image key={454} source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + this.state.picTwoId + "?" + this.state.time }} style={{ width: '100%', height: '100%' }} />
                                            : <Image key={581} source={{ uri: this.state.picTwoSource }} style={{ width: '100%', height: '100%' }} />}
                                    </View>}
                                {(this.state.picTwoIdCheck != null) || (this.state.picTwoSource != "") ?
                                    <TouchableOpacity style={styles.deleteIcon} onPress={() => this.removePhoto(2)}>
                                        {SvgImages.deleteIcon(20, 20)}
                                    </TouchableOpacity>

                                    : null}
                            </View>
                            <Text style={styles.errMsg}>{this.state.errMessage}</Text>

                            <View style={styles.popupbtn}>
                                <TouchableOpacity style={styles.popbtn}>
                                    <Text style={styles.popUpCancel}  onPress={() =>   this.props.navigation.navigate("BusinessList", { taluk: null, district: null, refresh: true })}>ரத்து</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.popbtn} onPress={() => this.submitData()}>
                                    <Text style={styles.popUpbtnText}>சமர்ப்பிக்கவும்</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    }
                </ScrollView>
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        // padding: 10
    },
    textContainer: {
        margin: 10,
    },
    textBox: {
        fontFamily: 'MeeraInimai-Regular',
        borderWidth: 1,
        borderRadius: 4,
        fontSize: 15,
        top: 8,
        paddingLeft: 12,
        color: defaultTheme.colors.gray,
        position: 'relative',
        borderColor: defaultTheme.colors.lighterGray
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        // margin: 10,
        marginBottom: 15
    },
    mt12: {
        margin: 10,
    },
    district: {
        margin: 10,
    },
    taluk: {
        margin: 10,
    },

    mainContainer: {
        position: 'relative',
        zIndex: 0,
        // padding: 10,
        marginTop: 20,
        marginBottom: 365
    },
    bottomText: {
        paddingLeft: 20
    },
    name: {
        marginTop: 15,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontWeight: 'bold'
    },

    lable: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 15,
        top: 8,
        paddingLeft: 12,
        position: 'relative'
    },
    mandatory: {
        color: defaultTheme.colors.red,
    },

    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 15,
        paddingBottom: 20
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    errMsg: {
        textAlign: 'center',
        color: defaultTheme.colors.red,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 12,
    },
    textarea: {
        borderWidth: 1,
        borderRadius: 4,
        paddingBottom: 60,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray,
        textAlignVertical: 'top'
    },
    photoText: {
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		paddingTop: 45,
		fontSize: 15,
		position: 'relative'
	},
    imageplaceholder: {
		width: 80,
		height: 80,
		margin: 10,
		borderWidth: 1,
		borderColor: defaultTheme.colors.lighterGray,
		borderRadius: 4,
		justifyContent: 'center',
        marginRight:30,
        marginTop:-10
	},
	plus: {
		paddingLeft: 20,
		justifyContent: 'center',
		fontSize: 40,
		color: defaultTheme.colors.gray
	},
    deleteIcon:{
        right:12        
    },
	horoscopePicDesign:{
        width: 85,
        height: 100,
        borderWidth:0.5,
        borderColor:defaultTheme.colors.gray,
        marginTop:10,
        marginLeft:170
    },
    registrProfileDesign:{
        width: 85,
        height: 100,
        borderWidth:0.5,
        borderColor:defaultTheme.colors.gray,
        marginTop:10,
        marginLeft:170,
        marginBottom:10
    }
});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(BusinessEdit);
