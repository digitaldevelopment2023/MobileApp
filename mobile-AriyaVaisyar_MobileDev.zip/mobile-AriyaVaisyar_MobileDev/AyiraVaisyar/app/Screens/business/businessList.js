/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    FlatList,
    Image,
    ActivityIndicator
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
import { ScrollView } from "react-native-gesture-handler";
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import SegmentedControlTab from "react-native-segmented-control-tab";
import Icon from 'react-native-vector-icons/MaterialIcons';
import Modal from 'react-native-modal';
import {
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger,
} from 'react-native-popup-menu';
import { compose } from "redux";

class BusinessList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            district: props.route.params.district,
            taluk: props.route.params.taluk,
            pageNo: 1,
            pageSize: 50,
            totalPageSize: 0,
            totalPage: 0,
            isLoading: true,
            selectedIndex: 0,
            talukFilter: null,
            isModalVisible: false,
        }
    }

    componentDidMount() {
        this.FormList();
    }

    componentDidUpdate(prevProps) {
        var params = this.props.route.params;
        if (params && params.refresh) {
            this.setState({ selectedIndex: 1 });
            this.employmentUserApi();
            this.props.route.params.refresh = false;
        }
    }

    FormList() {
        if (this.state.district != null) {
            this.setState({ selectedIndex: 0 });
            this.employmentFilterApi();
        } else {
            this.setState({ selectedIndex: 1 });
            this.employmentUserApi();
        }

    }
    employmentFilterApi = () => {
        apiService(`/api/business/filter/${this.state.pageNo}/${this.state.pageSize}`, 'post', {
            district: this.state.district,
            taluk: this.state.taluk
        }, '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    console.log(result.data.totalBusiness);
                    this.setState({
                        employmentList: result.data.totalBusiness,
                        totalPageSize: result.data.totalCount,
                        totalPage: result.data.totalPages,
                        isLoading: false

                    });
                }
            },
            (error) => {
            });
    }


    employmentUserApi = () => {
        apiService(`/api/businessLists/${this.props.user.data.DATA.id}`, 'get', ''
            , '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    this.setState({
                        employmentList: result.data,
                        isLoading: false
                    });
                }
            },
            (error) => {
            });

    }

    pagination = () => {
        if (this.state.totalPage > this.state.pageNo) {
            this.setState({
                pageNo: this.state.pageNo + 1
            }, () => this.FormList())
        }
    }

    openModal = (id) => {
        this.setState({ isModalVisible: true, selectedId: id });
    };

    cancelModal = () => {
        this.setState({ isModalVisible: false, selectedId: "" });
    };

    deleteEmployment = () => {
        this.setState({ isLoading: true, isModalVisible: false, });
        apiService(`/api/business/${this.state.selectedId}`, 'delete', '', '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    this.setState({ isModalVisible: false, selectedId: '', selectedIndex: 1 }, function () {
                        this.employmentUserApi();
                    });
                    Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                }
                else {
                    this.setState({ isLoading: false, isModalVisible: false, });
                }
            },
            (error) => {
                this.setState({ isLoading: false, isModalVisible: false, });
            });
    }

    render() {
        return (
            <React.Fragment>
                <Header title="வணிகம்" navigation={this.props.navigation} />
                {this.state.isLoading == true ?
                    <Loader /> :
                    <View style={styles.container}>
                        {this.state.isDistrictLoading || this.state.stateLoader ? <ActivityIndicator size="small" color={defaultTheme.colors.primary} /> :
                            <View style={styles.mainContainer}>
                                <View>
                                </View>
                                {this.state.selectedIndex == 0 ?
                                    <View>
                                        {this.state.employmentList.length != 0 ?
                                            <FlatList
                                                data={this.state.employmentList}
                                                extraData={this.state}
                                                onEndReachedThreshold={0}
                                                onEndReached={this.pagination}
                                                keyExtractor={(item) => item.id.toString()}
                                                renderItem={({ item }) =>
                                                    <View style={styles.card}>
                                                        <View style={styles.content}>
                                                            <View style={styles.header}>
                                                                <View style={styles.row}>
                                                                    {SvgImages.job(25, 25)}
                                                                    <Text style={styles.headerTitle}>Business {item.id}</Text>
                                                                </View>
                                                            </View>

                                                            <Text style={styles.headBorder}></Text>
                                                            <View style={styles.bottomText}>
                                                                <Text style={styles.detailsHead}>{item.businessName}</Text>
                                                                <View>
                                                                    <Text style={styles.detailsHead}>மாவட்டம் & தாலுகா (district  & taluk)</Text>
                                                                    <Text style={styles.details}>{item.district} (Dt), {item.taluk}(Tk)</Text>
                                                                </View>
                                                                <View>
                                                                    <Text style={styles.detailsHead}>முகவரி & இருப்பிடம் (Address & Location)</Text>
                                                                    <Text style={styles.details}>{item.addressAndLocation}</Text>
                                                                </View>
                                                                <View>
                                                                    <Text style={styles.detailsHead}>தொடர்புகொள்ள (Contact Details)</Text>
                                                                    <Text style={styles.details}>{item.contactDetails}</Text>
                                                                </View>
                                                                <View style={styles.detailsBtn}>
                                                                    <TouchableOpacity onPress={() => this.props.navigation.navigate("BusinessDetails", { businessInfo: item, isApproved: false })}>
                                                                        <Text style={[styles.btn, styles.fontFamily]}>மேலும்</Text>
                                                                    </TouchableOpacity>
                                                                </View>
                                                            </View>
                                                        </View>
                                                    </View>
                                                } />
                                            : <View>
                                                <Text style={styles.noDataFound}>No data Found</Text>
                                            </View>}
                                    </View>
                                    :
                                    <View>
                                        {this.state.employmentList.length != 0 ?
                                            <FlatList
                                                data={this.state.employmentList}
                                                extraData={this.state}
                                                onEndReachedThreshold={0}
                                                keyExtractor={(item) => item.id.toString()}
                                                renderItem={({ item }) =>
                                                    <View style={styles.card}>
                                                        <View style={styles.content}>
                                                            <View style={styles.header}>
                                                                <View style={styles.row}>
                                                                    {SvgImages.job(25, 25)}
                                                                    <Text style={styles.headerTitle}>Business {item.id}</Text>
                                                                    {item.isSuperAdmin == "Y" ?
                                                                        <Text style={styles.isStatusApproved}>APPROVED</Text> : item.isSuperAdmin == "R" ? <Text style={styles.isStatusReject}> REJECT </Text>: <Text style={styles.isStatusProgress}> INPROGRESS</Text>}
                                                                </View>
                                                                <View style={styles.editIcon}>
                                                                    <Menu>
                                                                        <MenuTrigger text={<Icon name="more-horiz" style={styles.moreIcon} />} />
                                                                        <MenuOptions>
                                                                            <MenuOption onSelect={() => this.props.navigation.navigate("BusinessDetails", { businessInfo: item, isApproved: false })} >
                                                                                <Text style={styles.edit}>மேலும் விவரங்கள்</Text>
                                                                            </MenuOption>
                                                                            <MenuOption onSelect={() => this.props.navigation.navigate("BusinessEdit", { businessInfo: item })} >
                                                                                <Text style={styles.edit}>திருத்து</Text>
                                                                            </MenuOption>
                                                                            <MenuOption onSelect={() => this.openModal(item.id)} >
                                                                                <Text style={styles.delete}>நீக்கு</Text>
                                                                            </MenuOption>
                                                                        </MenuOptions>
                                                                    </Menu>
                                                                </View>

                                                            </View>
                                                            <Text style={styles.headBorder}></Text>
                                                            <View style={styles.bottomText}>
                                                                <Text style={styles.detailsHead}>{item.businessName}</Text>
                                                                <View>
                                                                    <Text style={styles.detailsHead}>மாவட்டம் & தாலுகா (district  & taluk)</Text>
                                                                    <Text style={styles.details}>{item.district} (Dt), {item.taluk}(Tk)</Text>
                                                                </View>
                                                                <View>
                                                                    <Text style={styles.detailsHead}>முகவரி & இருப்பிடம் (Address & Location)</Text>
                                                                    <Text style={styles.details}>{item.addressAndLocation}</Text>
                                                                </View>
                                                                <View>
                                                                    <Text style={styles.detailsHead}>தொடர்புகொள்ள (Contact Details)</Text>
                                                                    <Text style={styles.details}>{item.contactDetails}</Text>
                                                                </View>
                                                                {item.isSuperAdmin == "R" ?
                                                                <View>
                                                                    <Text style={styles.detailsHead}>நிராகரிக்கப்பட்ட காரணம் (Reason to reject)</Text>
                                                                    <Text style={styles.details}>{item.rejectReason}</Text>
                                                                </View>:null}
                                                            </View>
                                                        </View>
                                                    </View>
                                                } />
                                            : <View>
                                                <Text style={styles.noDataFound}>No data Found</Text>
                                            </View>}
                                    </View>
                                }
                            </View>
                        }
                    </View>
                }
                {this.state.selectedIndex == 1 ?
                    <TouchableOpacity style={styles.footer} onPress={() => this.props.navigation.navigate("BusinessAdd")}>
                        <Icon name="add" style={styles.plus} />
                        <Text style={styles.footerText}>வணிகத்தை உருவாக்கவும்</Text>
                    </TouchableOpacity>
                    : null}


                <Modal isVisible={this.state.isModalVisible}
                    animationInTiming={1000}
                    animationOutTiming={1000}
                    backdropTransitionInTiming={800}
                    backdropTransitionOutTiming={800}
                >
                    <View style={styles.popup}>
                        <Text style={styles.confirmText}>நீங்கள் நிச்சயமாக நீக்க விரும்புகிறீர்களா?</Text>
                        <View style={styles.popupbtn}>
                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                <Text style={styles.popUpCancel}>ரத்து</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.popbtn} onPress={() => this.deleteEmployment()}>
                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 5,
    },
    headBorder: {
        borderBottomColor: defaultTheme.colors.liteBorder,
        borderBottomWidth: 1,
        width: 353
    },
    iconContainer: {
        paddingTop: 10,
        width: 40
    },
    mt12: {
        margin: 10,
    },
    district: {
        margin: 10,
    },
    card: {
        borderWidth: 0.5,
        borderColor: defaultTheme.colors.lighterGray,
        borderRadius: 4,
        flexDirection: 'row',
        paddingVertical: 5,
        paddingHorizontal: 10,
        marginBottom: 20,
        marginTop: 10
    },
    userPic: {
        width: 70,
        height: 70,
    },
    profile: {
        width: '100%',
        height: '100%'
    },
    mainContainer: {
        position: 'relative',
        zIndex: 0,
        padding: 10,
        marginTop: 5,
        // marginBottom: 565
    },
    content: {
        // paddingLeft: 5,
    },
    bottomText: {
        paddingLeft: 15
    },
    name: {
        marginTop: 15,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontWeight: 'bold'
    },
    detailsHead: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        paddingTop: 10,
        fontSize: 14,
        fontWeight: 'bold'
    },
    details: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        paddingTop: 4
    },
    salaryHead: {
        flexDirection: 'row',
    },
    detailsHeadSalary: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 14,
        fontWeight: 'bold',
        paddingTop: 10,
        paddingBottom: 10
    },
    detailsSalary: {
        paddingTop: 10
    },
    lable: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.white,
        fontSize: 15,
        top: 8,
        paddingLeft: 12,
        position: 'relative'
    },
    mandatory: {
        color: defaultTheme.colors.red,
    },
    noDataFound: {
        marginTop: 30,
        textAlign: 'center'
    },
    footer: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: defaultTheme.colors.white,
        paddingVertical: 10
    },
    footerText: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 15,
        paddingLeft: 10
    },
    plus: {
        paddingLeft: 50,
        fontSize: 35,
        justifyContent: 'center',
        alignItems: 'center',
        color: defaultTheme.colors.gray
    },
    moreIcon: {
        fontSize: 25,
        marginTop: 15,
        color: defaultTheme.colors.lighterGray
    },
    headerTitle: {
        color: defaultTheme.colors.gray,
        paddingTop: 4,
        paddingHorizontal: 10,
        fontWeight: 'bold'
    },
    isStatusReject: {
        color: defaultTheme.colors.red,
        paddingTop: 6,
        paddingHorizontal: 10,
        marginLeft: 25,
        fontWeight: 'bold',
        fontSize: 12,
    },
    isStatusApproved: {
        color: defaultTheme.colors.green,
        paddingTop: 6,
        paddingHorizontal: 10,
        marginLeft: 25,
        fontWeight: 'bold',
        fontSize: 12,
    },
    isStatusProgress: {
        color: defaultTheme.colors.yellow,
        paddingTop: 6,
        paddingHorizontal: 10,
        marginLeft: 25,
        fontWeight: 'bold',
        fontSize: 12
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        borderBottomColor: defaultTheme.colors.lightGray,
        height: 20

    },
    edit: {
        color: defaultTheme.colors.gray,
        fontSize: 22,
        alignItems: 'center',
        paddingHorizontal: 10,
        paddingTop: 4,
        paddingBottom: 5,
    },
    edit: {
        fontFamily: 16,
        fontFamily: 'MeeraInimai-Regular',
        padding: 8
    },
    delete: {
        fontFamily: 16,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.red,
        padding: 8
    },
    // popup start
    popup: {
        backgroundColor: "#fff",
        height: 150,
    },
    confirmText: {
        marginTop: 20,
        textAlign: 'center',
        justifyContent: 'center',
        fontFamily: 'MeeraInimai-Regular',
    },
    popbtn: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20
    },
    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    // popup end
    editIcon: {
        paddingRight: 20,
        paddingTop: 5
    },
    detailsBtn: {
        paddingTop: 2,
        paddingBottom:5,
        flexDirection: 'row',
        justifyContent: 'flex-end'
    },
    btn: {
        backgroundColor: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 11,
        width: 100,
        borderRadius: 50,
        marginLeft: 5,
        fontSize: 12,
        textAlign: 'center',
        color: defaultTheme.colors.white
    },

});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(BusinessList);
