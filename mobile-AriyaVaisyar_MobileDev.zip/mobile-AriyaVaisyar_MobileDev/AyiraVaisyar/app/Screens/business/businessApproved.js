/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,
	TouchableOpacity,
	FlatList,
	Image,
} from "react-native";
import { connect } from 'react-redux';
import moment from 'moment';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import CheckBox from 'react-native-check-box';
import FastImage from "react-native-fast-image";
import Modal from 'react-native-modal';
import Toast from 'react-native-simple-toast';
import { ForceTouchGestureHandler } from "react-native-gesture-handler";

class BusinessApproved extends Component {
	constructor(props) {
		super(props);
		this.state = {
			businessList: [],
			memberListAdd: [],
			isChecked: [],
			select_array: [],
			pageNo: 1,
			pageSize: 50,
			totalPageSize: 0,
			totalPage: 0,
			isLoading: false,
			isCheckedMember: false,
            isModalVisible: false,
		}
	}

	componentDidMount() {
		this.getMemberList();
	}

	componentDidUpdate(prevProps) {
		var params = this.props.route.params;
		if (params && params.refresh) {
			this.getMemberList();
			this.props.route.params.refresh = false;
		}
	}

	getMemberList = () => {
		this.setState({ isLoading: true });
			var URL = '/api/superadmin/businessLists/'
		
		apiService(`${URL}${this.props.user.data.DATA.id}`, 'get', '', '', this.props.user.data.JWT,
			(result) => {
				if (result.status === 200) {
					this.setState({
						businessList: result.data,
						isLoading: false
					});

				}
				else {
					this.setState({ isLoading: false });
				}
			},
			(error) => {
				this.setState({ isLoading: false });
			});
	}

	pagination = () => {
		if (this.state.totalPage > this.state.pageNo) {
			this.setState({
				pageNo: this.state.pageNo + 1
			}, () => this.getMemberList())
		}
	}

	



	memberApprove = (id) => {
		this.setState({ isLoading: true });
		console.log(this.state.select_array);
		apiService(`/api/admin/user/approved`, 'put', {
			adminId: this.props.user.data.DATA.id,
			adminType: this.props.user.data.USERTYPE,
			userId: this.state.select_array,
			status: id
		}, '', this.props.user.data.JWT,
			(result) => {
				if (result.status === 200) {
					this.getMemberList();
				}
				else {
					this.setState({ isLoading: false });
				}
			},
			(error) => {
				this.setState({ isLoading: false });
			});
	}

    businessApprove = (data) => {
		this.setState({ isLoading: true,isModalVisible:false });
		apiService(`/api/business/approved`, 'put', {
			businessId: this.state.selectedId
		}, '', this.props.user.data.JWT,
			(result) => {
				if (result.status === 200) {
                    Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
					this.getMemberList();
				}
				else {
                    Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
					this.setState({ isLoading: false, });
				}
			},
			(error) => {
				this.setState({ isLoading: false });
			});
	}

	gotoDetailsPage = (id) => {
       console.log(id)
	   this.props.navigation.navigate("BusinessDetails", {  businessInfo: id ,isApproved:true}) 
    };

    openModal = (id) => {
        this.setState({ isModalVisible: true, selectedId: id });
    };

    cancelModal = () => {
        this.setState({ isModalVisible: false, selectedId: "" });
    };

	render() {
		return (
			<React.Fragment>
				<Header title="வணிகம் இணைத்தல்" navigation={this.props.navigation} />
				<View style={styles.container}>
					{this.state.isLoading == true ?
						<Loader /> :
						<View>
							{this.state.businessList.length != 0 ?
								<View>
									<FlatList
										data={this.state.businessList}
										extraData={this.state}
										onEndReachedThreshold={0}
										keyExtractor={(item) => item.id.toString()}
										onEndReached={this.pagination}
										renderItem={({ item }) =>
											<View style={[styles.card, styles.row]}>
												<View style={[styles.row]}>
													<View style={styles.userPic}>
														{item.picOneId != null ?
															<Image style={styles.profile} source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + item.picOneId}}  /> :
															<Image key={this.state.time} style={styles.profile} source={require("../../assets/images/EmptyImage.png")} />
														}
														{/* <Image style={styles.profile} source={{ uri: `${ApiUrls.apiEnvironment}` + item.profileImage }} /> */}
													</View>
												</View>
												<View style={styles.content}>
													<View style={styles.nameContainer}>
														<Text style={[styles.name, styles.fontFamily]}>{item.businessName}</Text>
													</View>
													<Text style={[styles.fontFamily, styles.fathersname]}>{item.district} (Dt) </Text>
													<View style={styles.row}>
														<Text style={[styles.taluk, styles.fontFamily]}>{item.taluk} (Tk)</Text>
													</View>
													<View style={styles.detailsBtn}>
                                                        <TouchableOpacity onPress={() => this.gotoDetailsPage(item)}>
															<Text style={[styles.btn, styles.fontFamily]}>மேலும்</Text>
														</TouchableOpacity>
														<TouchableOpacity onPress={() => this.openModal(item.id)}>
															<Text style={[styles.btn, styles.fontFamily]}>ஒப்புதல்</Text>
														</TouchableOpacity>
													</View>
												</View>
											</View>
										}
									/>
								</View> : <View>
									<Text style={styles.noDataFound}> No data Found</Text>
								</View>}
						</View>
					}
				</View>
                
                <Modal isVisible={this.state.isModalVisible}
                    animationInTiming={1000}
                    animationOutTiming={1000}
                    backdropTransitionInTiming={800}
                    backdropTransitionOutTiming={800}
                >
                    <View style={styles.popup}>
                        <Text style={styles.confirmText}>நீங்கள் நிச்சயமாக அங்கீகரிக்க விரும்புகிறீர்களா?</Text>
                        <View style={styles.popupbtn}>
                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                <Text style={styles.popUpCancel}>ரத்து</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.popbtn} onPress={() => this.businessApprove()}>
                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>
			</React.Fragment>
		)
	}
}
const styles = StyleSheet.create({
	container: {
		flex: 1,
		padding: 10
	},
	row: {
		flexDirection: 'row',
		justifyContent: 'space-between'
	},
	card: {
		borderWidth: 1,
		borderRadius: 5,
		borderColor: defaultTheme.colors.lighterGray,
		paddingVertical: 10,
		paddingHorizontal: 10,
		marginVertical: 10
	},
	userPic: {
		width: 90,
		height: 90,
		paddingLeft: 15,
        marginTop:6
	},
	profile: {
		width: '100%',
		height: '100%'
	},
	content: {
		paddingLeft: 10,
		width: '60%',
		
	},
	nameContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between'
	},
	fontFamily: {
		fontFamily: 'MeeraInimai-Regular',
	},
	name: {
		fontSize: 16,
		fontWeight: 'bold',
		color: defaultTheme.colors.gray
	},
	dob: {
		fontSize: 12,
		color: defaultTheme.colors.gray
	},
	fathersname: {
		fontSize: 13,
		paddingTop: 4,
		color: defaultTheme.colors.gray
	},
	taluk: {
		fontSize: 12,
		paddingTop: 2,
		color: defaultTheme.colors.gray
	},
	btn: {
		backgroundColor: defaultTheme.colors.primary,
		paddingVertical: 5,
		paddingHorizontal: 10,
		width: 100,
		borderRadius: 50,
        marginLeft:5,
		fontSize: 12,
		textAlign: 'center',
		color: defaultTheme.colors.white
	},
	noDataFound: {
		textAlign: 'center',
		marginTop: 300
	},
	checkBoxText: {
		color: defaultTheme.colors.gray,
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 10
	},
	footer: {
		flexDirection: 'row',
		justifyContent: 'flex-end',
		alignItems: 'center',
		backgroundColor: defaultTheme.colors.white,
		paddingVertical: 10
	},
	btnAccept: {
		width: 120,
		textAlign: 'center',
		backgroundColor: defaultTheme.colors.primary,
		color: defaultTheme.colors.white,
		paddingVertical: 10,
		paddingHorizontal: 10,
		marginRight: 10,
		borderRadius: 5
	},
	checkBox: {
		paddingTop: 32,
		width: 35,
		height: 80
	},
	detailsBtn: {
        paddingTop:5,
		flexDirection: 'row',
		justifyContent: 'flex-end'
	},
     // popup start
     popup: {
        backgroundColor: "#fff",
        height: 150,
    },
    confirmText: {
        marginTop: 20,
        textAlign: 'center',
        justifyContent: 'center',
        fontFamily: 'MeeraInimai-Regular',
    },
    popbtn: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20
    },
    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    // popup end
});

function mapStateToProps(state) {
	return {
		user: state.loginReducer.user,
	};
}
export default connect(mapStateToProps)(BusinessApproved);
