/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Animated,
    ImageBackground,
    Image,
    ScrollView,
    TextInput,
    ActivityIndicator
} from "react-native";
import Icon from 'react-native-vector-icons/MaterialIcons';
import moment from 'moment';
import { connect } from 'react-redux';
/* Project Import will lives here */
import { Header, TextBox, Button } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import axios from 'axios';
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import ImageModal from 'react-native-image-modal';
import Toast from 'react-native-simple-toast';
import Modal from 'react-native-modal';

class BusinessDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            businessInfo: props.route.params.businessInfo,
            isApproved: props.route.params.isApproved,
            isLoading: false,
            isModalVisible: false,
            isModalVisibleApproved:false,
            rejectReason: ''
        }
    }
    componentDidMount() {
        var currentDate = new Date();
        this.setState({ updateImg: currentDate }, this.getCalender)
    }
    memberApprove = (id) => {
        this.setState({ isLoading: true });
        apiService(`/api/admin/user/approved`, 'put', {
            adminId: this.props.user.data.DATA.id,
            adminType: this.props.user.data.USERTYPE,
            userId: [this.state.businessInfo.id],
            status: id
        }, '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    this.setState({
                        memberList: result.data.totalUsers,
                        totalPageSize: result.data.totalCount,
                        totalPage: result.data.totalPages,
                        isLoading: false
                    });
                    this.props.navigation.navigate('MembersApprove', { refresh: true });
                }
                else {
                    this.setState({ isLoading: false });
                }
            },
            (error) => {
                this.setState({ isLoading: false });
            });
    }

    componentDidUpdate(prevProps) {
        var params = this.props.route.params;
        if (params && params.refresh) {
            this.memberApprove();
            this.props.route.params.refresh = false;
        }
    }

    openModal = (id) => {
        this.setState({ isModalVisible: true, selectedId: id,errMessage:'' });
    };

    cancelModal = () => {
        this.setState({ isModalVisible: false, selectedId: "" });
    };

    openModal2 = (id) => {
        this.setState({ isModalVisibleApproved: true, selectedId: id,errMessage:'' });
    };

    cancelModal2 = () => {
        this.setState({ isModalVisibleApproved: false, selectedId: "" });
    };

    businessApprove = () => {
        this.setState({ isLoading: true ,isModalVisibleApproved:false});
        apiService(`/api/business/approvedOrRejectPermission`, 'put', {
            businessId: this.state.businessInfo.id,
            permissionType: "Y",
        }, '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                    this.props.navigation.navigate("BusinessApproved", { refresh: true })

                }
                else {
                    Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                    this.setState({ isLoading: false, });
                }
            },
            (error) => {
                this.setState({ isLoading: false });
            });
    }

    businessReject = () => {
        if(this.rejectReasonValidation()){
            this.setState({ isLoading: true,isModalVisible:false });
            apiService(`/api/business/approvedOrRejectPermission`, 'put', {
                businessId: this.state.businessInfo.id,
                permissionType: "R",
                rejectReason:this.state.rejectReason,
            }, '', this.props.user.data.JWT,
                (result) => {
                    if (result.status === 200) {
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                        this.setState({ isLoading: false,rejectReason:'' });
                        this.props.navigation.navigate("BusinessApproved", { refresh: true })
    
                    }
                    else {
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                        this.setState({ isLoading: false, });
                    }
                },
                (error) => {
                    this.setState({ isLoading: false });
                });
        }
      
    }

    rejectReasonValidation = () =>{
        const { rejectReason } = this.state;
        var valid = true
        this.setState({ errMessage: this.state.rejectReason != "" ? "" : this.state.errMessage });
        if (rejectReason == "") {
            this.setState({ errMessage: "Please enter reject reason" })
            valid = false;
        }
        // else if(talukId ==""){
        //     this.setState({errMessage: "Please select your taluk"})
        //     valid = false;
        // }
        return valid;
    }

    render() {
        return (
            <React.Fragment>
                <Header title="வணிக விவரங்கள்" navigation={this.props.navigation} />
                <ScrollView>
                    <View style={styles.container}>
                        <View style={styles.bg}>
                            <View style={styles.cardbg}>
                                {/* <View style={styles.userPic}>
                                <View style={styles.img}>
                                    <Image style={styles.profile} source={{uri: `${ApiUrls.apiEnvironment}`+ this.state.memberDetails.profileImage}} />
                                </View>
                            </View> */}
                                <View style={styles.mainContainer}>
                                    <View style={styles.row}>
                                        <Text style={styles.title}>தொழில்  </Text>
                                    </View>
                                    <Text style={styles.content}>{this.state.businessInfo.businessName} </Text>
                                    <View style={styles.row}>
                                        <Text style={styles.title}>தொடர்புகொள்ள (Phone or Email)  </Text>
                                    </View>
                                    <Text style={styles.content}>{this.state.businessInfo.contactDetails} </Text>
                                    <View style={styles.row}>
                                        <Text style={styles.title}>முகவரி & இருப்பிடம் (Address & Location)   </Text>
                                    </View>
                                    <Text style={styles.content}>{this.state.businessInfo.addressAndLocation} </Text>
                                    <View style={styles.row}>
                                        <Text style={styles.title}>விவரங்கள் (Details)   </Text>
                                    </View>
                                    <Text style={styles.content}>{this.state.businessInfo.details} </Text>
                                    <View style={styles.row}>
                                        <Text style={styles.title}>வணிக படம் (Image)   </Text>
                                    </View>
                                    <View style={styles.imgContainer}>
                                        <View >
                                            {this.state.businessInfo.picOneId != null ?
                                                <View>
                                                    <View style={styles.imgPost}>
                                                        <ImageModal
                                                            resizeMode="contain"
                                                            key={this.state.updateImg}
                                                            imageBackgroundColor={defaultTheme.colors.white}
                                                            style={{ width: 130, height: 130 }}
                                                            source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + this.state.businessInfo.picOneId + "?" + this.state.updateImg, }}
                                                        />
                                                    </View>
                                                </View> :  <View style={styles.imgPost}>
                                                        <ImageModal
                                                            resizeMode="contain"
                                                            key={this.state.updateImg}
                                                            imageBackgroundColor={defaultTheme.colors.white}
                                                            style={{ width: 130, height: 130 }}
                                                            source={require("../../assets/images/EmptyImage.png")}  />
                                                       
                                                    </View>
                                            }
                                        </View>
                                        <View>
                                            {this.state.businessInfo.picTwoId != null ?
                                                <View>
                                                    <View style={styles.imgPost}>
                                                        <ImageModal
                                                            resizeMode="contain"
                                                            key={this.state.updateImg}
                                                            imageBackgroundColor={defaultTheme.colors.white}
                                                            style={{ width: 130, height: 130 }}
                                                            source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + this.state.businessInfo.picTwoId + "?" + this.state.updateImg, }}
                                                        />
                                                    </View>
                                                </View> : <View style={styles.imgPost}>
                                                        <ImageModal
                                                            resizeMode="contain"
                                                            key={this.state.updateImg}
                                                            imageBackgroundColor={defaultTheme.colors.white}
                                                            style={{ width: 130, height: 130 }}
                                                            source={require("../../assets/images/EmptyImage.png")}  />
                                                       
                                                    </View>
                                            }
                                        </View>
                                    </View>

                                </View>

                            </View>
                        </View>
                        <View style={styles.placeContainer}>
                            <View style={styles.row}>
                                <View style={styles.iconContainer}>
                                    {SvgImages.state(40, 40)}
                                </View>
                                <View style={styles.textContent}>
                                    <Text style={styles.place}>மாவட்டம் : {this.state.businessInfo.district}  </Text>
                                    <Text style={styles.place}>தாலுகா : {this.state.businessInfo.taluk}  </Text>
                                </View>
                            </View>
                            {this.state.isApproved == true ?
                                <View style={styles.btnContainer}>
                                    <TouchableOpacity onPress={() => this.openModal()}>
                                        <Text style={styles.btn}>நிராகரிக்கப்பு</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={() => this.openModal2()}>
                                        <Text style={styles.btnAccept}>ஒப்புதல்</Text>
                                    </TouchableOpacity>
                                </View>
                                : null}
                        </View>
                    </View>
                </ScrollView>
                <Modal isVisible={this.state.isModalVisible}
                    animationInTiming={1000}
                    animationOutTiming={1000}
                    backdropTransitionInTiming={800}
                    backdropTransitionOutTiming={800}
                >
                    <View style={styles.popup}>
                        {/* <Text style={styles.confirmText}>நீங்கள் நிராகரிக்க விரும்புகிறீர்களா?</Text> */}
                        <Text style={styles.lable}>நிராகரிக்க காரணம் (Reason to reject) <Text style={styles.mandatory}>*</Text></Text>
                        <View style={styles.textContainer}>
                            <TextInput
                                style={styles.textarea}
                                numberOfLines={3} maxLength={250} multiline={true} onChangeText={(rejectReason) => this.setState({ rejectReason: rejectReason })} />
                            <Text style={styles.errorlable}>{250 - this.state.rejectReason.length}/250 Characters</Text>
                        </View>
                        <Text style={styles.errMsg}>{this.state.errMessage}</Text>
                        <View style={styles.popupbtn}>
                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                <Text style={styles.popUpCancel}>ரத்து</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.popbtn} onPress={() => this.businessReject()}>
                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>
                <Modal isVisible={this.state.isModalVisibleApproved}
                    animationInTiming={1000}
                    animationOutTiming={1000}
                    backdropTransitionInTiming={800}
                    backdropTransitionOutTiming={800}
                >
                     <View style={styles.popupApprove}>
                        <Text style={styles.confirmText}>நீங்கள் நிச்சயமாக அங்கீகரிக்க விரும்புகிறீர்களா?</Text>
                        <View style={styles.popupbtn}>
                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal2}>
                                <Text style={styles.popUpCancel}>ரத்து</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.popbtn} onPress={() => this.businessApprove()}>
                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    bg: {
        backgroundColor: defaultTheme.colors.primary,
        height: 340
    },
    row: {
        flexDirection: 'row',
    },
    cardbg: {
        backgroundColor: '#EAEEF3',
        height: 400,
        margin: 20,
        marginTop: 30,
        borderRadius: 10
    },
    userPic: {
        flexDirection: 'row',
        justifyContent: 'center'
    },
    profile: {
        width: '100%',
        height: '100%',
        borderRadius: 45,
        marginTop: -45
    },
    img: {
        width: 90,
        height: 90,
    },
    title: {
        fontFamily: 'MeeraInimai-Regular',
        fontWeight: 'bold',
        color: defaultTheme.colors.gray,
        paddingTop: 15
    },
    content: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 16,
        paddingTop: 15,
    },
    mainContainer: {
        padding: 15,
        paddingTop:5
    },
    placeContainer: {
        backgroundColor: defaultTheme.colors.primary,
        marginTop: 220,
        margin: 15,
        borderRadius: 10,
        paddingTop: 10,
        paddingBottom: 25,
        paddingHorizontal: 10
    },
    place: {
        color: defaultTheme.colors.white,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 15
    },
    placeIcon: {
        color: defaultTheme.colors.white,
        fontSize: 70
    },
    textContent: {
        paddingLeft: 18,
        paddingTop: 10
    },
    btnContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginTop: 10
    },
    btn: {
        backgroundColor: defaultTheme.colors.red,
        color: defaultTheme.colors.white,
        paddingVertical: 10,
        paddingHorizontal: 10,
        borderRadius: 5
    },
    btnAccept: {
        width: 120,
        textAlign: 'center',
        backgroundColor: defaultTheme.colors.white,
        color: defaultTheme.colors.primary,
        paddingVertical: 10,
        paddingHorizontal: 10,
        borderRadius: 5
    },
    iconContainer: {
        paddingTop: 10,
        paddingLeft: 23,
        width: 62
    },

    imgPost: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 10
    },
    imgContainer: {
        marginTop: 20,
        flexDirection: 'row',
        justifyContent: 'space-around'
    },
    popupApprove: {
        backgroundColor: "#fff",
        height: 150,
    },
    // popup start
    popup: {
        backgroundColor: "#fff",
        height: 330,
    },
    confirmText: {
        marginTop: 20,
        textAlign: 'center',
        justifyContent: 'center',
        fontFamily: 'MeeraInimai-Regular',
    },
    popbtn: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20
    },
    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    // popup end
    textarea: {
        borderWidth: 1,
        borderRadius: 4,
        // width:150,
        margin:15,
        paddingBottom: 60,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray,
        textAlignVertical: 'top'
    },
    lable: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 13,       
        paddingLeft: 12,
        paddingTop:20
    },
    errorlable: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 13,
        paddingLeft: 20,
    },
    mandatory: {
        color: defaultTheme.colors.red,
    },
    errMsg: {
        textAlign: 'center',
        color: defaultTheme.colors.red,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 12,
    },
});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(BusinessDetails);
