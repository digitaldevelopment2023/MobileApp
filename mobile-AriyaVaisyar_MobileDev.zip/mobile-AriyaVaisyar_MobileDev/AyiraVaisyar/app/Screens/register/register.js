/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,
	Image,	
	TouchableOpacity,
	PermissionsAndroid,
	ScrollView,
	Linking,
	ActivityIndicator,
	Alert
} from "react-native";
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from '../../actions/loginAction';
import RadioForm, {RadioButton, RadioButtonInput, RadioButtonLabel} from 'react-native-simple-radio-button';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePicker  from "react-native-modal-datetime-picker";
import ImagePicker from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/MaterialIcons';
import CheckBox from 'react-native-check-box';
import Toast from 'react-native-simple-toast';
import moment from 'moment'
/* Project Import will lives here */
import {Header, TextBox, Button, Loader} from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";

class Register extends Component {
	constructor(props) {
		super(props);
		this.state = {
			defaultCountry: '',
			defaultState:'',
			dob:'',
			isDateTimePickerVisible: false,
			isChecked: false,
			isLoading: true,
			education:[],
			occupation: [],
			bloodGroup:[],
			country:[],
			stateList:[],
			districtList:[],
			talukList:[],
			talukId:[],
			sect:[],
			subCaste:[],
			name:'',
			gender:'',
			educationID:'',
			occupationID:'',
			selectedDateShow:'',
			spouseName:'',
			fatherName:'',
			countryId:'',
			stateId:'',
			districtId:'',
			talukId:'',
			mobileNo:props.user.data.DATA.phone || null,
			alterMobileNo:'',
			email:'',
			income:'',
			casteId:null,
			subCasteId:null,
			bloodGroupId:'',
			bloodDonate:'',
			// password:'',
			imagesource:'',	
			profilePic:'',
			profilePicId:'',
			maximumDate:null,
			isEditable: true,
			isRegister: false,
			defaultDistrict: null,
			defaultTaluk: null

		}
	}

	componentDidMount(){
		this.FormList();
		this.getSubSect();
		this.camerapermission();
		this.date();
		this.setState({ imagesource: ""});
	}
	
	_showDateTimePicker = () => this.setState({ isDateTimePickerVisible: true });

	_hideDateTimePicker = () => this.setState({ isDateTimePickerVisible: false });
  
	_handleDatePicked = (date) => {
	  	var selectedDateShow =  moment(date).format('DD-MM-YYYY')
		var selectedDate =  moment(date).format('YYYY-MM-DD')	  
	  this.setState({ dob: selectedDate, selectedDateShow: selectedDateShow,errDob:''})
	  this._hideDateTimePicker();
	};

	date =()=>{
		let today=new Date();
		const days_to_subtract=5475;
		let new_date= new Date(today.valueOf()-(days_to_subtract*24*60*60*1000))
		this.setState({ maximumDate: new_date});
	}

	FormList() {
		FormList((FormList)=>{
			this.setState({				 
				education: FormList.data.education,
				occupation: FormList.data.occupation,
				country: FormList.data.country,
				bloodGroup: FormList.data.bloodGroup,
				sect: FormList.data.sect,
				isLoading: false,
			 });
			 
			if(FormList.data.country !=  ""){
				FormList.data.country.map(val => {
					var CountryID ;
					if((val.label === "India") || (val.label === "இந்தியா") || (val.label === "india") || (val.label === "INDIA")){
						// COUNTRY API
						CountryID = val.value;
						this.setState({defaultCountry: val.value, countryId:  val.value})
						apiService(`/unsecure/mobile/statelist/${CountryID}`, 'get', '',false, '',	
						(result) => {
							if(result.status === 200){
								this.setState({stateList: result.data,});
								if(result.data !=  ""){
									result.data.map(val => {
										if((val.label === "தமிழ்நாடு") || (val.label === "Tamilnadu") || (val.label === "Tamil Nadu") || (val.label === "TAMILNADU") ||  (val.label === "TAMIL NADU")){
											// state API
											stateID = val.value;
											this.setState({defaultState: val.value,stateId: val.value, stateList: result.data})
											apiService(`/unsecure/mobile/districtlist/${stateID}`, 'get', '',false, '',	
												(response) => {
													if(response.status === 200){
														this.setState({districtList: response.data,});
													}
												},
												(error) => {
													// this.setState({isLoading: false});
												});
										}
									})
								}
							}
						},
						(error) => {
							// this.setState({isLoading: false});
						});
					}
				})

			}		 
		 });
	 }

	education =(id)=>{
		this.checkValidation(id,"EDUCATION")
		this.setState({educationID: id, errEducation:''});
	}

	occupation =(id)=>{
		this.checkValidation(id,"OCCUPATION")
		this.setState({occupationID: id, errOccupation:''});
	}

	states =(id)=>{
		this.checkValidation(id,"COUNTRYNAME")
		this.setState({countryId: id,defaultState:null, defaultDistrict: null, defaultTaluk: null, stateList:[], districtList:[], talukList:[], stateId:'', districtId:'',talukId:''});
		apiService(`/unsecure/mobile/statelist/${id}`, 'get', '',false, '',	
		(result) => {
			if(result.status === 200){
				this.setState({stateList: result.data});
			}
		},
		(error) => {
			// this.setState({isLoading: false});
		});
	}

	 district=(id)=>{
		this.checkValidation(id,"STATENAME")
		this.setState({stateId: id, defaultState:id, defaultDistrict: null, defaultTaluk: null,  districtList:[], talukList:[],districtId:'', talukId:'', errState:''});
		apiService(`/unsecure/mobile/districtlist/${id}`, 'get', '',false, '',	
			(result) => {
				if(result.status === 200){
					this.setState({districtList: result.data,});
				}
			},
			(error) => {
				// this.setState({isLoading: false});
		});
	 }

	taluk = (id)=>{
		this.checkValidation(id,"DISTRICTNAME")
		this.setState({districtId: id, defaultDistrict:id, defaultTaluk: null, talukId:'', talukList:[], errDistrict:''});
		apiService(`/unsecure/mobile/taluklist/${id}`, 'get', '',false, '',	
			(result) => {
				if(result.status === 200){
					this.setState({talukList: result.data});
				}
			},
			(error) => {
				// this.setState({isLoading: false});
		});
	}

	getSubSect =()=>{
		apiService(`/unsecure/mobile/subsectlist`, 'get', '',false, '',	
		(result) => {
			if(result.status === 200){
				this.setState({subCaste: result.data, isLoading: false});
			}
		},
		(error) => {
			// this.setState({isLoading: false});
		});
	}

	sect = (id)=>{
		this.checkValidation(id,"CASTE")
		this.setState({casteId: id, errCaste:''});
	}
	subCaste = (id)=>{
		this.checkValidation(id,"SUBCASTE")
		this.setState({subCasteId: id});
	}

	gender =(gender)=>{
		this.checkValidation(gender,"GENDER");
		this.setState({gender:gender, errGender:''})
	}

	bloodGrp =(id)=>{
		this.checkValidation(id,"BLOODGROUP")
		this.setState({bloodGroupId:id, errBloodGroup:''})
	}

	bloodDonate =(bloodDonate)=>{
		this.checkValidation(bloodDonate,"BLOODDONATE")
		{this.setState({bloodDonate:bloodDonate, errDonate:''})}
	}
	terms =(isCheck)=>{
		{
			this.setState({
				isChecked: isCheck == false ? true : isCheck == true ? false: true ,
			errTerms:''})}
	}

	handleSubmit = ()=>{
		if(this.validation()) {
			{this.setState({isRegister:true})}
			apiService(`/api/user/`, 'put', {
				id: this.props.user.data.DATA.id,
				createdAt: this.props.user.data.DATA.createdAt,
				email:this.state.email,
				name: this.state.name,
				phone: this.state.mobileNo,
				alternativeMobileNumber: this.state.alterMobileNo,
				spouseName: this.state.spouseName,
				fatherName: this.state.fatherName,
				educationId: this.state.educationID,
				occupationId: this.state.occupationID,
				gender: this.state.gender,
				dateOfBirth: this.state.dob,
				sectId: this.state.casteId,
				subSectId: this.state.subCasteId,
				bloodGroupId: this.state.bloodGroupId,
				bloodDonate: this.state.bloodDonate,
				countryId: this.state.countryId,
				stateId: this.state.stateId,
				districtId: this.state.districtId,
				talukId:  this.state.talukId,
				profilePicId: this.state.profilePicId,
				isUserRegister: "Y",
				income: this.state.income
			}, false, this.props.user.data.JWT,	
			(result) => {
				if(result.status == 200){

					if(result.data.SUCCESS === true){
									this.setState({
										isLoading: false
									},function() {
										this.props.login(result.data);                
									});
									if(result.data.DATA.isUserRegister == "Y"){
										this.props.navigation.navigate("Acknowledgement");
									}
								}
								else{
									Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
									this.props.navigation.navigate("Login");
									this.setState({isLoading: false})
								}

					// this.setState({isChecked: false, isRegister: false});
					// Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
					// apiService(`/unsecure/mobile/login`, 'post', {phone: this.state.mobileNo}, false, '',	
					// 	(response) => {				  
					// 		if(response.data.SUCCESS === true){
					// 			this.setState({
					// 				isLoading: false
					// 			},function() {
					// 				this.props.login(response.data);                
					// 			});
					// 			if(response.data.DATA.isUserRegister == "Y"){
					// 				this.props.navigation.navigate("Login");
					// 			}
					// 		}
					// 		else{
					// 			Toast.showWithGravity(response.data.MESSAGE, Toast.LONG, Toast.TOP)
					// 			this.props.navigation.navigate("Login");
					// 			this.setState({isLoading: false})
					// 		}
					// 	},
					// 	(error) => {
					// 		this.setState({isLoading: false});
					// 	});
					}
				else{					
					this.setState({isChecked: false, isRegister: false});
					Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
				}
			},
			(error) => {
				Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
				this.setState({isRegister: false});
			});
		}
	}


checkValidation=(param,type)=>{
	var valid = true;
	let emailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
	var nameRegex = /^[a-zA-Z ]{2,30}$/;
	var mobileNoReg =  /^[1-9][0-9]{9}$/;
	this.setState({errName: this.state.name != "" ? "": this.state.errName,	errGender:this.state.gender != "" ? "":this.state.errGender, errEducation:this.state.educationID != "" ? "": this.state.errEducation, errOccupation:this.state.occupationID != "" ? "": this.state.errOccupation,	errDob:this.state.dob != "" ? "": this.state.errDob, errFatherName:this.state.fatherName != "" ? "": this.state.errFatherName, errCountry:this.state.countryId != "" ? "": this.state.errCountry, errState:this.state.stateId != "" ? "": this.state.errState, errDistrict:this.state.districtId != "" ? "": this.state.errDistrict, errTaluk:this.state.talukId !=  "" ? "": this.state.errTaluk, errMobile:this.state.mobileNo != "" ? "": this.state.errMobile,	errEmail:this.state.email != "" ? "": this.state.errEmail, errCaste:this.state.casteId != "" ? "": this.state.errCaste, errBloodGroup:this.state.bloodGroupId != "" ? "": this.state.errBloodGroup,	errDonate:this.state.bloodDonate != "" ? "": this.state.errBloodGroup, errTerms:this.state.isChecked != true ? "": this.state.errTerms,
	errprofilePic:this.state.profilePic != "" ? "": this.state.errprofilePic
	});
    switch(type) {
 
      case "NAME":
		if(param.length < 3){
			this.setState({errName: "Please enter valid name"})
		}
		break;
		case "GENDER":
			if(param == "" || param == null){
				this.setState({errGender: "Please select gender"})
				valid = false;
			}
			break;
		case "EDUCATION":
			if(param ==""){
				this.setState({errEducation: "Please select Education"})
				valid = false;
			}
			break;
		case "OCCUPATION":
			if(param ==""){
				this.setState({errOccupation: "Please select Occupation"})
				valid = false;
			}
			break;
		case "DOB":
			if(param =="" ||param == null){
			this.setState({errDob: "Please select Date of Birth"})
			valid = false;
		}
		break;
		case "FATHERSNAME":
			if(param.length < 3){
				this.setState({errFatherName: "Please enter your fathers name"})
				valid = false;
			}
			break;
		case "COUNTRYNAME":
			if(param ==""){
				this.setState({errCountry: "Please select your country"})
				valid = false;
			}
		case "STATENAME":
			if(param ==""){
				this.setState({errState: "Please select your state"})
				valid = false;
			}
			break;
		case "DISTRICTNAME":
			if(param ==""){
				this.setState({errDistrict: "Please select your district"})
				valid = false;
			}
			break;
		case "TALUK":
			if(param ==""){
				this.setState({errTaluk: "Please select your taluk"})
				valid = false;
		}
		break;
		case "MOBILENUMBER":
			if(mobileNoReg.test(param) === false){
				this.setState({errMobile: "Please enter your mobile Number"})
				valid = false;
			}
		break;
		case "EMAIL":
			if(emailReg.test(param) === false){
				this.setState({errEmail: "Please enter valid Email"})
				valid = false;
			}
		break;
		case "INCOME":
			if(param ==""){
				this.setState({errIncome: "Please select your Income"})
				valid = false;
			}
		break;
		case "BLOODGROUP":
			if(param ==""){
				this.setState({errBloodGroup: "Please select your Blood Group"})
				valid = false;
			}
		break;
		case "BLOODDONATE":
			if(param ==""){
				this.setState({errDonate: "Please select blood donation"})
				valid = false;
			}
			break;
		case "PASSWORD":
			if((param.length < 6) ||(param.length >20)){
				this.setState({errPassword: "Password Contains Minmun 6 character"})
				valid = false;
			}
		break;
 
      default:
        // Alert.alert("err");
    
      }
 
  }

  validation=() =>{		
	const {name, gender, educationID, occupationID, dob, fatherName, countryId, stateId, districtId, talukId, mobileNo, casteId, income, bloodGroupId, isChecked} = this.state;
	var valid = true
	this.setState({errName: this.state.name != "" ? "": this.state.errName,	errGender:this.state.gender != "" ? "":this.state.errGender, errEducation:this.state.educationID != "" ? "": this.state.errEducation, errOccupation:this.state.occupationID != "" ? "": this.state.errOccupation,	errDob:this.state.dob != "" ? "": this.state.errDob, errFatherName:this.state.fatherName != "" ? "": this.state.errFatherName, errCountry:this.state.countryId != "" ? "": this.state.errCountry, errState:this.state.stateId != "" ? "": this.state.errState, errDistrict:this.state.districtId != "" ? "": this.state.errDistrict, errTaluk:this.state.talukId !=  "" ? "": this.state.errTaluk, errMobile:this.state.mobileNo != "" ? "": this.state.errMobile,	errEmail:this.state.email != "" ? "": this.state.errEmail, errCaste:this.state.casteId != "" ? "": this.state.errCaste, errBloodGroup:this.state.bloodGroupId != "" ? "": this.state.errBloodGroup,	errDonate:this.state.bloodDonate != "" ? "": this.state.errBloodGroup, errTerms:this.state.isChecked != true ? "": this.state.errTerms
	,errIncome: this.state.income != "" ? "": this.state.errIncome,
});
	let emailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
	var nameRegex = /^[a-zA-Z ]{2,30}$/;
	var mobileNoReg =  /^[1-9][0-9]{9}$/;
	if(name.length< 3){
		this.setState({errName: "Please enter valid name"})
		valid = false;
	}
	if(gender == "" || gender == null){
		this.setState({errGender: "Please select gender"})
		valid = false;
	}
	if(educationID ==""){
		this.setState({errEducation: "Please select Education"})
		valid = false;
	}
	if(occupationID ==""){
		this.setState({errOccupation: "Please select Occupation"})
		valid = false;
	}
	if(dob =="" ||dob == null ){
		this.setState({errDob: "Please select Date of Birth"})
		valid = false;
	}
	if(fatherName.length < 3){
		this.setState({errFatherName: "Please enter your fathers name"})
		valid = false;
	}
	if(countryId ==""){
		this.setState({errCountry: "Please select your country"})
		valid = false;
	}
	if(stateId ==""){
		this.setState({errState: "Please select your state"})
		valid = false;
	}
	if(districtId ==""){
		this.setState({errDistrict: "Please select your district"})
		valid = false;
	}
	if(talukId ==""){
		this.setState({errTaluk: "Please select your taluk"})
		valid = false;
	}
	if(mobileNoReg.test(mobileNo) === false){
		this.setState({errMobile: "Please enter your mobile Number"})
		valid = false;
	}
	if(income ==""){
		this.setState({errIncome: "Please select your Income"})
		valid = false;
	}
	if(casteId =="" || casteId == null){
		this.setState({errCaste: "Please select your sect"})
		valid = false;
	}
	if(bloodGroupId ==""){
		this.setState({errBloodGroup: "Please select your Blood Group"})
		valid = false;
	}		
	// if(password ==""){
	// 	this.setState({errPassword: "Please enter your password"})
	// 	valid = false;
	// }
	if(isChecked == false){
		this.setState({errTerms: "Please accept Terms and conditions"})
		valid = false;
	}	
	   return valid;
}

	async camerapermission(){
		try {
			const granted = await PermissionsAndroid.request(
			  PermissionsAndroid.PERMISSIONS.CAMERA
		
			);
			if (granted === PermissionsAndroid.RESULTS.GRANTED) {
			  console.log("You can use the camera");
			} else {
			//   console.log("Camera permission denied");
			}
		  } catch (err) {
			console.warn(err);
		  }
	  }

	  selectPhotoTapped =()=> {
		const options = {
			quality: 1.0,
			maxWidth: 500,
			maxHeight: 500,
			includeBase64: true,
			storageOptions: {
			skipBackup: true,
			privateDirectory: true 
			}
		};

		ImagePicker.showImagePicker(options, (response) => {
		console.log('Response = ', response);        
		if (response.didCancel) {
			console.log('User cancelled photo picker');
		}
		else if (response.error) {
			console.log('ImagePicker Error: ', response.error);
		}
		else if (response.customButton) {
			console.log('User tapped custom button: ', response.customButton);
		}
		else {
			var source = { 
				uri: response.uri,
				type:response.type,
				name:response.fileName,
				height: response.height,
				width: response.width,      			
				// 	Platform.OS === "android" ? response.uri : response.uri.replace("file:/", "")
			};
			this.setState({
				profilePic: source,
				imagesource: "data:image/jpeg;base64,"+ response.data,  
			},this.profilePicUpload(source));
		}
		});
	  }

	profilePicUpload =(source)=>{
		let formData = new FormData();
			formData.append('file', source)
			formData.append('fileType', "PROFILE")
			apiService(`/unsecure/file`, 'post', formData, true ,'',	
			(result) => {
				if(result.data.SUCCESS = true){
					this.setState({profilePicId: result.data.RESPONSE.id})
				}
			},
			(error) => {
				Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
			});
	}
	  
	removePhoto =()=>{
		this.setState({ imagesource: ""});
	}

	income =(id)=>{
		this.checkValidation(id,"INCOME")
		this.setState({income: id, errIncome:''});
	}
	

	render() {
		var radio_props = [
			{label: 'ஆண் (Male)', value: "Male" },
			{label: 'பெண் (Female)', value: "Female" }
		  ];
		  
		  var radio_propss = [
			{label: 'ஆம் (Yes)', value: "Y" },
			{label: 'இல்லை (No)', value: "N" }
		  ];

		  var income =[
			{label: '1 லட்சம் வரை', value: '1 லட்சம் வரை'},
			{label: '1 முதல் 3 லட்சம் வரை', value: '1 முதல் 3 லட்சம் வரை'},
			{label: '3 முதல் 5 லட்சம் வரை', value: '3 முதல் 5 லட்சம் வரை'},
			{label: '5 முதல் 10 லட்சம் வரை', value: '5 முதல் 10 லட்சம் வரை'},
			{label: '10 லட்சத்திற்கு மேல்', value: '10 லட்சத்திற்கு மேல்'}
		]
		
		return (			
			<React.Fragment>
				<Header title="பதிவுபெறு" navigation={this.props.navigation}/>
				<ScrollView>
				{this.state.isLoading === true ?
				<Loader/>	:
				<View style={styles.container}>
					<View style={styles.textContainer}>
						<Text style={styles.lable}>பெயர் (Name) <Text  style={styles.mandatory}>*</Text></Text>
						<TextBox
							style={styles.textBox}
							// iconName={(<FUI name="userPerson" size={25} style={styles.icon} />)}
							// type="email"
							placeholder="பெயர் (Name)"							      
							borderWidth={1}
							placeholderTextColor={ defaultTheme.colors.lighterGray}
							value= {this.state.name}
							onChange={name =>{this.setState({name:name}, this.checkValidation(name,"NAME"))}}
															
						/>
						<Text style={styles.errMsg}>{this.state.errName}</Text>
					</View>
					<View>
						<Text style={styles.lable}>பாலினம் (Gender) <Text  style={styles.mandatory}>*</Text></Text>
						<View style={styles.radioContainer}>
							<RadioForm
								radio_props={radio_props}
								labelStyle={styles.radioBtn}
								initial={-1}
								formHorizontal={true}
								buttonColor={defaultTheme.colors.primary}
								labelColor={defaultTheme.colors.primary}
								selectedButtonColor={defaultTheme.colors.primary}
								buttonOuterColor={'red'}
								buttonInnerColor={'red'}
								buttonSize={14}
								animation={true}
								onPress={(value) => {this.gender(value)}}
							/>
							<Text style={styles.errMsg}>{this.state.errGender}</Text>
						</View>
					</View>
					<View style={styles.textContainer}>
						<Text style={styles.lable}>கல்வி (Education) <Text  style={styles.mandatory}>*</Text></Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={this.state.education}
								containerStyle={{height: 50}}
								placeholder="கல்வி"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.education(item.value)}
							/>
						</View>
						<Text style={styles.errMsg}>{this.state.errEducation}</Text>
					</View>

					<View style={styles.textContainer}>
						<Text style={styles.lable}>தொழில் (Occupation) <Text  style={styles.mandatory}>*</Text> </Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={this.state.occupation}
								containerStyle={{height: 50}}
								placeholder="தொழில்"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.occupation(item.value)}
							/>
						</View>
						<Text style={styles.errMsg}>{this.state.errOccupation}</Text>
					</View>

					<View style={styles.textContainer}>
						<Text style={styles.lable}>பிறந்த தேதி (Date of Birth) <Text  style={styles.mandatory}>*</Text> </Text>						
						<TouchableOpacity onPress={this._showDateTimePicker} style={styles.datePicker}>
							<Icon name="date-range" size={25}  style={styles.icons}/>
							{this.state.selectedDateShow == ""?
							<Text style={styles.datePlaceholder}>பிறந்த தேதி </Text>:
							<Text style={styles.dateTime}>{this.state.selectedDateShow} </Text>}
						</TouchableOpacity>	
						<DateTimePicker
							isVisible={this.state.isDateTimePickerVisible}
							mode='date'
							maximumDate={this.state.maximumDate}
							onConfirm={this._handleDatePicked}
							onCancel={this._hideDateTimePicker}
						/>
						<Text style={styles.errMsg}>{this.state.errDob}</Text>						
					</View>
					<View style={styles.textContainer}>
						<Text style={styles.lable}>கணவன் அல்லது மனைவியின் பெயர் (Spouse Name)</Text>
						<TextBox
							style={styles.textBox}
							placeholder="கணவன் அல்லது மனைவியின் பெயர்"							      
							borderWidth={1}
							placeholderTextColor={ defaultTheme.colors.lighterGray}
							value= {this.state.spouseName}
							onChange={spouseName =>{this.setState({spouseName:spouseName},this.checkValidation(this.state.dob,"DOB"))}}								
						/>
					</View>

					<View style={styles.textContainer}>
						<Text style={styles.lable}>தந்தையின் பெயர் (Father’s Name) <Text  style={styles.mandatory}>*</Text> </Text>
						<TextBox
							style={styles.textBox}
							placeholder="தந்தையின் பெயர்"							      
							borderWidth={1}
							placeholderTextColor={ defaultTheme.colors.lighterGray}
							value= {this.state.fatherName}
							onChange={fatherName =>{this.setState({fatherName:fatherName}, this.checkValidation(fatherName,"FATHERSNAME"))}}								
						/>
						<Text style={styles.errMsg}>{this.state.errFatherName}</Text>
					</View>
					<View style={styles.textContainer}>
						<Text style={styles.lable}>நாடு (Country) <Text  style={styles.mandatory}>*</Text> </Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={this.state.country}								
								defaultValue={this.state.defaultCountry}
								searchable={true}
								searchablePlaceholder="Search Country"
								searchablePlaceholderTextColor={defaultTheme.colors.lighterGray}
								containerStyle={{height: 50}}
								placeholder="நாடு"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.states(item.value)}
							/>
						</View>
						<Text style={styles.errMsg}>{this.state.errCountry}</Text>
					</View>
					<View style={styles.textContainer}>
						<Text style={styles.lable}>மாநிலம் (State ) <Text  style={styles.mandatory}>*</Text> </Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={this.state.stateList}
								defaultValue={this.state.defaultState}
								searchable={true}
								searchablePlaceholder="Search state"
								searchablePlaceholderTextColor={defaultTheme.colors.lighterGray}
								containerStyle={{height: 50}}
								placeholder="மாநிலம்"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.district(item.value)}
							/>
						</View>
						<Text style={styles.errMsg}>{this.state.errState}</Text>
					</View>
					<View style={styles.textContainer}>
						<Text style={styles.lable}>மாவட்டம் (District) <Text  style={styles.mandatory}>*</Text> </Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={this.state.districtList}
								defaultValue={this.state.defaultDistrict}
								searchable={true}
								searchablePlaceholder="Search District"
								searchablePlaceholderTextColor={defaultTheme.colors.lighterGray}
								containerStyle={{height: 50}}
								placeholder="மாவட்டம்"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.taluk(item.value)}
							/>
						</View>
						<Text style={styles.errMsg}>{this.state.errDistrict}</Text>
					</View>
					<View style={styles.textContainer}>
						<Text style={styles.lable}>தாலுகா (Taluk) <Text  style={styles.mandatory}>*</Text> </Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={this.state.talukList}
								defaultValue={this.state.defaultTaluk}
								containerStyle={{height: 50}}
								placeholder="தாலுகா"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item => this.setState({talukId: item.value,defaultTaluk: item.value, errTaluk:''})}
							/>
						</View>
						<Text style={styles.errMsg}>{this.state.errTaluk}</Text>
					</View>

					<View style={styles.textContainer}>
						<Text style={styles.lable}>கைபேசி எண் (Mobile Number) <Text  style={styles.mandatory}>*</Text> </Text>
						<TextBox
							style={styles.textBox}
							placeholder="கைபேசி எண்"							      
							borderWidth={1}
							isEditable={this.state.isEditable}
							placeholderTextColor={ defaultTheme.colors.lighterGray}
							value= {this.state.mobileNo}
							keyboardType="number"
							onChange={mobileNo =>{this.setState({mobileNo:mobileNo},this.checkValidation(mobileNo,"MOBILENUMBER"))}}								
						/>
						<Text style={styles.errMsg}>{this.state.errMobile}</Text>
					</View>

					<View style={styles.textContainer}>
						<Text style={styles.lable}>மாற்று கைபேசி எண் (Alternative Mobile Number)</Text>
						<TextBox
							style={styles.textBox}
							placeholder="மாற்று கைபேசி எண்"							      
							borderWidth={1}
							keyboardType="number"
							placeholderTextColor={ defaultTheme.colors.lighterGray}
							value= {this.state.alterMobileNo}
							onChange={alterMobileNo =>{this.setState({alterMobileNo:alterMobileNo})}}								
						/>
					</View>

					<View style={styles.textContainer}>
						<Text style={styles.lable}>மின்னஞ்சல் (Email)</Text>
						<TextBox
							style={styles.textBox}
							// iconName={(<FUI name="userPerson" size={25} style={styles.icon} />)}
							type="email"
							placeholder="மின்னஞ்சல் (Email)"							      
							borderWidth={1}
							placeholderTextColor={ defaultTheme.colors.lighterGray}
							value= {this.state.email}
							onChange={email =>{this.setState({email:email},this.checkValidation(email,"EMAIL"))}}								
						/>
					</View>
					<View style={styles.textContainer}>
						<Text style={styles.lable}>ஆண்டு வருமானம் (income)<Text  style={styles.mandatory}>*</Text> </Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={income}
								containerStyle={{height: 50}}
								placeholder="ஆண்டு வருமானம்"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.income(item.value)}
							/>
								<Text style={styles.errMsg}>{this.state.errIncome}</Text>
						</View>
					</View>
					<View style={styles.textContainer}>
						<Text style={styles.lable}>ஆயிரவைசியரில் உட்பிரிவு (Sect) <Text  style={styles.mandatory}>*</Text> </Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={this.state.sect}
								containerStyle={{height: 50}}
								placeholder="ஆயிரவைசியரில் உட்பிரிவு"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.sect(item.value)}
							/>
						</View>
						<Text style={styles.errMsg}>{this.state.errCaste}</Text>
					</View>				
					<View style={styles.textContainer}>
						<Text style={styles.lable}>கோத்திரம்  (Sub-Sect) </Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={this.state.subCaste}
								searchable={true}
								searchablePlaceholder="Search..."
								dropDownMaxHeight={300}
								searchablePlaceholderTextColor={defaultTheme.colors.lighterGray}
								containerStyle={{height: 50}}
								placeholder="கோத்திரம் "
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item => this.subCaste(item.value)}
							/>
						</View>
						{/* <Text style={styles.errMsg}>{this.state.errSubCaste}</Text> */}
					</View>

					<View style={styles.textContainer}>
						<Text style={styles.lable}>இரத்த வகை (Blood Group)   <Text  style={styles.mandatory}>*</Text> </Text>
						<View style={styles.mt12}>
							<DropDownPicker
								items={this.state.bloodGroup}
								containerStyle={{height: 50}}
								placeholder="இரத்த வகை "
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.lighterGray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item => this.bloodGrp(item.value)}
							/>
						</View>
						<Text style={styles.errMsg}>{this.state.errBloodGroup}</Text>
					</View>
					<View>
						<Text style={styles.lable}>இரத்த தானம் (Blood Donate)  <Text  style={styles.mandatory}>*</Text> </Text>
						<View style={styles.radioContainer}>
							<RadioForm
								radio_props={radio_propss}
								labelStyle={styles.radioBtn}
								initial={-1}
								formHorizontal={true}
								buttonColor={defaultTheme.colors.primary}
								labelColor={defaultTheme.colors.primary}
								selectedButtonColor={defaultTheme.colors.primary}
								buttonOuterColor={'red'}
								buttonInnerColor={'red'}
								buttonSize={14}
								animation={true}
								onPress={(value) => {this.bloodDonate(value)}}
							/>
							<Text style={styles.errMsg}>{this.state.errDonate}</Text>
						</View>
					</View>
					{/* <View style={styles.textContainer}>
						<Text style={styles.lable}>கடவுச்சொல் (Password) <Text  style={styles.mandatory}>*</Text> </Text>
						<TextBox
							style={styles.textBox}
							placeholder="கடவுச்சொல்"							      
							borderWidth={1}
							placeholderTextColor={ defaultTheme.colors.lighterGray}
							isPassword={true}
							value= {this.state.password}
							onChange={password =>{this.setState({password:password}, this.checkValidation(password,"PASSWORD"))}}								
						/>
						<Text style={styles.errMsg}>{this.state.errPassword}</Text>
					</View> */}
					<View>
						<Text style={styles.lable}>புகைப்படத்தைப் பதிவேற்றுக </Text>
						{this.state.imagesource =="" ?
							<TouchableOpacity style={styles.imageplaceholder} onPress={()=>this.selectPhotoTapped()}>
								<Icon name="add" style={styles.plus}/>
							</TouchableOpacity> :
							<TouchableOpacity style={styles.imageOuter}  onPress={()=>this.selectPhotoTapped()}>
								<View style={{width: 85, height: 100}}>
									<Image source={{uri:this.state.imagesource}}  style={{ width: 85, height: 100}} />
								</View>							
							</TouchableOpacity>
						}
						{this.state.imagesource !="" ?
							<TouchableOpacity onPress={()=>this.removePhoto()}>								
								<Text style={styles.error}>Remove</Text>
							</TouchableOpacity> : null }
						<Text style={styles.errMsg}>{this.state.errprofilePic}</Text>
					</View>
					<CheckBox
						style={{marginTop: 20}}
						onClick={()=> {this.terms(this.state.isChecked)}}
						isChecked={this.state.isChecked}
						rightText={"நான் விதிமுறைகளையும் நிபந்தனைகளையும் ஏற்றுக்கொள்கிறேன்"}
						rightTextStyle={styles.checkBoxText}
						checkBoxColor ={ defaultTheme.colors.primary}
					/>
					<Text style={styles.errMsg}>{this.state.errTerms}</Text>
					<View>
					<TouchableOpacity onPress={() => Linking.openURL('http://www.ayiravaisya.com/terms of use.htm')}>
						<Text style={styles.center}>Terms and Conditions</Text>
					</TouchableOpacity>
					</View>					
					<View>
					
						<Button
							style={styles.button}
							btnName="உள்நுழைய"
							color={defaultTheme.colors.white}
							size={16}							
							onPress={()=>this.handleSubmit()}
						/>
					</View>
				</View>
			}
				</ScrollView>
				
    		</React.Fragment>
		);
	}
}

const styles = StyleSheet.create({
	container:{
		flex: 1,
		padding: 10
	},
	row:{
		flexDirection:'row',
		justifyContent:'space-between',
		paddingHorizontal: 5
	},
	radioContainer:{
		marginTop: 15
	},
	mt12:{
		marginTop: 12
	},
	radioBtn:{
		fontFamily: 'MeeraInimai-Regular',
		marginRight: 20,
		paddingTop:5
	},
	textBox:{
		borderWidth : 1.5,
		marginVertical:10,
		borderRadius: 4,
		paddingBottom: 6,
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		borderColor: defaultTheme.colors.lighterGray
	},
	datePicker:{
		flexDirection:'row',
		alignItems:'center',
		borderBottomWidth : 1.5,
		marginVertical:10,
		borderRadius: 4,
		borderWidth : 1,
		borderColor: defaultTheme.colors.lighterGray,
		height: 45,
	},
	icons:{
		color: defaultTheme.colors.lighterGray,
		right:7 ,
		position: 'absolute'
	},
	dateTime:{
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 14,
		left:15 ,
		color: defaultTheme.colors.gray,
		position: 'relative'
	},
	datePlaceholder:{
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 14,
		left:15 ,
		color: defaultTheme.colors.lighterGray,
		position: 'relative'
	},
	lable:{
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		fontSize:15,
		top: 8,
		position:'relative'
	},
	text:{
		color: defaultTheme.colors.white
	},

	button:{
		backgroundColor: defaultTheme.colors.primary,
		color: defaultTheme.colors.white,
		width:'100%',
		fontFamily: 'MeeraInimai-Regular',
	},	
	checkBoxText:{
		color: defaultTheme.colors.gray,
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 10
	},
	imageOuter:{
		width: 108,
		height: 108,
		margin: 10,		
		justifyContent:'center',
	},
	imageplaceholder:{
		width: 108,
		height: 108,
		margin: 10,	
		borderWidth: 1,
		borderColor: defaultTheme.colors.lighterGray,
		borderRadius: 4,
		justifyContent:'center'
	},
	plus:{
		paddingLeft:30,
		fontSize:  40,
		color: defaultTheme.colors.gray
	},
	error: {
		color: defaultTheme.colors.red,
		paddingLeft: 12
	},
	mandatory:{
		color: defaultTheme.colors.red,	
	},
	errMsg:{
		color: defaultTheme.colors.red,
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 10,
		height: 15,
	},
	center:{
		flexDirection:'row',
		justifyContent:'center',
		textAlign:'center',
		textDecorationLine: 'underline'
	}
  });

  function mapStateToProps(state) {
	return {
		user: state.loginReducer.user,
	};
}

function mapDispatchToProps(dispatch) {
	return bindActionCreators(
		Object.assign(
			{},
			actions,
		), dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Register);
