/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Animated,
    ImageBackground,
    Image,
    ScrollView,
    ActivityIndicator
} from "react-native";
import Toast from 'react-native-simple-toast';
import Modal from 'react-native-modal';
import ImagePicker from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/MaterialIcons';
import moment from 'moment';
import { connect } from 'react-redux';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import ImageModal from 'react-native-image-modal';


class MatrimonyDetails extends Component {
    constructor(props) {
        super(props);
        console.log(props.route.params.matrimonyDetails)
        this.state = {
            userInfo: props.route.params.matrimonyDetails,
            isLoading: false,
            updateImg: new Date(),
            isModalVisible: false,
        }
    }
    componentDidUpdate(prevProps) {
        var params = this.props.route.params;
        if (params && params.refresh) {
            this.setState({ userInfo: this.props.route.params.matrimonyDetails, updateImg: new Date() })
            this.props.route.params.refresh = false;
        }
    }
    openModal = (id) => {
		this.setState({isModalVisible: true, selectedId: id});
		};

	cancelModal = () => {
		this.setState({isModalVisible: false, selectedId: ""});
		};
    deleteRegister() {
        this.setState({isLoading: true});
        apiService(`/api/marriageRegistration/${this.state.selectedId}`, 'delete', '','',this.props.user.data.JWT,
		(result) => { 
			if(result.status === 200 ){
				this.setState({isModalVisible: false, selectedId: '', isLoading: false,});
				Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP);
                this.props.navigation.navigate("MatrimonyList", {refresh: true,isUser:true });
			}
			else {  
				this.setState({isLoading: false, isModalVisible: false,}); 				
			}
		},
		(error) => {
			this.setState({isLoading: false, isModalVisible: false,});
		});
    }

    render() {

        return (
            <React.Fragment>
                <Header title="திருமணப்பதிவு" navigation={this.props.navigation} />
                <ScrollView>
                    {this.state.isLoading === true ?
                        <Loader /> :
                        <View>
                            <View>
                                <Image style={styles.profile_bg} source={require("../../assets/images/profile_bg.png")} />
                                <View style={styles.userPic}>
                                    <View style={styles.img}>
                                        {this.state.userInfo.registrProfilePicId != null ?
                                        <Image key={this.state.time} style={styles.profile} source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + this.state.userInfo.registrProfilePicId + "?" + this.state.updateImg }} />:
                                        <Image key={this.state.time} style={styles.profile} source={require("../../assets/images/profileDefault.jpg")}  />
                                     }   
                                    </View>
                                    <View>
                                    </View>
                                </View>
                            </View>
                            <View style={styles.container}>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.user(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>பெயர்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.name}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.gender(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>பாலினம்</Text>
                                        {this.state.userInfo.gender == "Male" ?
                                            <Text style={styles.content}>ஆண்</Text> :
                                            <Text style={styles.content}>பெண்</Text>
                                        }

                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.calender(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>பிறந்த தேதி</Text>
                                        <Text style={styles.content}>{moment(this.state.userInfo.dateOfBirth).format('DD-MM-YYYY')} </Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.father(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>தந்தையின் பெயர்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.fatherName}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.mother(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>தாயார் பெயர்</Text>
                                        <Text style={styles.content}>{(this.state.userInfo.motherName == "") || (this.state.userInfo.motherName == null) ? "-" : this.state.userInfo.motherName}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.education(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>கல்வி</Text>
                                        <Text style={styles.content}>{this.state.userInfo.education} </Text>
                                    </View>
                                </View>
                                    <View style={[styles.row, styles.mainContent]}>
                                <View style={styles.iconContainer}>
                                    {SvgImages.alterMobile(30, 30)}
                                </View>
                                <View>
                                    <Text style={styles.nameTitle}>தொடர்பு கொள்ள</Text>
                                    <Text style={styles.content}>{this.state.userInfo.contact}</Text>
                                </View>
                            </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.taluk(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>பணிபுரியும் ஊர்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.workingTown}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.money(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>மாத வருமானம்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.monthlySalary}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.community(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>ஆயிரவைசியரில் உட்பிரிவு</Text>
                                        <Text style={styles.content}>{this.state.userInfo.sect}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.group(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>கோத்திரம்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.subSect}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.zodiac(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>ராசி மற்றும்  நட்சத்திரம்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.zodiacAndStar}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.timeZome(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>திசை இருப்பு</Text>
                                        <Text style={styles.content}>{this.state.userInfo.timeZome}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.food(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>உணவுப் பழக்கம்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.foodHabbit}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.horoscope(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>ஜாதக விவரம்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.horoscopeDescription}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.expectation(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>துணை பற்றிய எதிர்பார்ப்பு</Text>
                                        <Text style={styles.content}>{this.state.userInfo.expectationOfVice}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.otherDetails(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>இதர விவரங்கள்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.otherDetails}</Text>
                                    </View>
                                </View>
                                <View style={[styles.row, styles.mainContent]}>
                                    <View style={styles.iconContainer}>
                                        {SvgImages.moreDescription(30, 30)}
                                    </View>
                                    <View>
                                        <Text style={styles.nameTitle}>கூடுதல் தகவல்கள்</Text>
                                        <Text style={styles.content}>{this.state.userInfo.moreDescription}</Text>
                                    </View>
                                </View>
                                {this.state.userInfo.horoscopePicId != null ?
                                    <View style={[styles.row, styles.mainContent]}>
                                        <View style={styles.iconContainer}>
                                            {SvgImages.horoscopePic(30, 30)}
                                        </View>

                                        <View>
                                            <Text style={styles.nameTitle}>ஜாதகம்</Text>
                                            <View>
                                                <View style={styles.imgPost}>
                                                    <ImageModal
                                                        resizeMode="contain"
                                                        imageBackgroundColor={defaultTheme.colors.white}
                                                        key={this.state.updateImg}
                                                        style={{ width: 270, height: 190 }}
                                                        source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + this.state.userInfo.horoscopePicId + "?" + this.state.updateImg }}

                                                    />
                                                </View>
                                            </View>
                                        </View>
                                    </View> : null
                                }
                                <Modal isVisible={this.state.isModalVisible}
                                    animationInTiming={1000}
                                    animationOutTiming={1000}
                                    backdropTransitionInTiming={800}
                                    backdropTransitionOutTiming={800}
                                >
                                    <View style={styles.popup}>
                                        <Text style={styles.confirmText}>நீங்கள் நிச்சயமாக நீக்க விரும்புகிறீர்களா?</Text>
                                        <View style={styles.popupbtn}>
                                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                                <Text style={styles.popUpCancel}>ரத்து</Text>
                                            </TouchableOpacity>
                                            <TouchableOpacity style={styles.popbtn} onPress={() => this.deleteRegister()}>
                                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                </Modal>
{/* 
                                {this.props.user.data.DATA.id == this.state.userInfo.userId ?
                                    <View style={styles.popupbtn}>
                                        <TouchableOpacity style={styles.popbtn} onPress={() => this.openModal(this.state.userInfo.id)}>
                                            <Text style={styles.popUpCancel}>நீக்கு</Text>
                                        </TouchableOpacity>
                                        <TouchableOpacity style={styles.popbtn} onPress={() => this.props.navigation.navigate("MatrimonyEdit", { matrimonyDetails: this.state.userInfo })}>
                                            <Text style={styles.popUpbtnText}>திருத்து</Text>
                                        </TouchableOpacity>
                                    </View> : null} */}
                            </View>
                        </View>
                    }
                </ScrollView>
            </React.Fragment>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
        marginTop: -10
    },
    row: {
        flexDirection: 'row',
        paddingHorizontal: 5
    },
    profile_bg: {
        // width:'100%',
        // paddingBottom: 40,
        // height:''

    },
    userPic: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        paddingRight: 50,
        marginTop: -120
    },
    profile: {
        width: '100%',
        height: '100%',
        borderRadius: 75,
        marginTop: -30,
        borderColor: defaultTheme.colors.white,
        borderWidth: 3,
        overflow: 'hidden',
        shadowColor: defaultTheme.colors.white,
        shadowRadius: 10,
        shadowOpacity: 1,
    },
    horoscopeImg: {
        width: '100%',
        height: '100%',
        borderWidth: 3,
        overflow: 'hidden',
        shadowColor: defaultTheme.colors.white,
        shadowRadius: 10,
        shadowOpacity: 1,
    },
    img: {
        width: 150,
        height: 150,
    },
    horoscope: {
        width: 150,
        height: 150,
    },
    cardbg: {
        backgroundColor: '#EAEEF3',
        borderRadius: 10,
        padding: 10
    },
    titleContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
    },
    title: {
        fontFamily: 'MeeraInimai-Regular',
        fontWeight: 'bold',
        paddingVertical: 4,
        paddingHorizontal: 6,
        fontSize: 20,
        color: defaultTheme.colors.gray,
        backgroundColor: defaultTheme.colors.white
    },
    mainContent: {
        marginVertical: 10
    },
    iconContainer: {
        paddingTop: 10,
        width: 40
    },
    content: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 14,
        paddingTop: 1,
        fontWeight: 'bold',
    },
    mainContainer: {
        marginTop: -45,
        padding: 15
    },
    placeContainer: {
        backgroundColor: defaultTheme.colors.primary,
        marginTop: 220,
        margin: 15,
        borderRadius: 10,
        paddingTop: 10,
        paddingBottom: 25,
        paddingHorizontal: 10
    },
    place: {
        color: defaultTheme.colors.white,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 15
    },
    placeIcon: {
        color: defaultTheme.colors.white,
        fontSize: 70
    },
    textContent: {
        paddingLeft: 18,
        paddingTop: 10
    },
    // register
    radioContainer: {
        marginTop: 15
    },
    mt12: {
        marginTop: 12
    },
    radioBtn: {
        fontFamily: 'MeeraInimai-Regular',
        marginRight: 20,
        paddingTop: 5
    },
    textBox: {
        borderWidth: 1.5,
        marginVertical: 10,
        borderRadius: 4,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray
    },
    datePicker: {
        flexDirection: 'row',
        alignItems: 'center',
        borderBottomWidth: 1.5,
        marginVertical: 10,
        borderRadius: 4,
        borderWidth: 1,
        borderColor: defaultTheme.colors.lighterGray,
        height: 45,
    },
    icons: {
        color: defaultTheme.colors.lighterGray,
        right: 7,
        position: 'absolute'
    },
    dateTime: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 14,
        // left: 15,
        color: defaultTheme.colors.gray,
        position: 'relative'
    },
    datePlaceholder: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 14,
        left: 15,
        color: defaultTheme.colors.lighterGray,
        position: 'relative'
    },
    lable: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 15,
        top: 8,
        position: 'relative'
    },
    text: {
        color: defaultTheme.colors.white
    },

    button: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        width: '100%',
        fontFamily: 'MeeraInimai-Regular',
    },
    checkBoxText: {
        color: defaultTheme.colors.gray,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 10
    },
    imageOuter: {
        width: 108,
        height: 108,
        margin: 10,
        justifyContent: 'center',
    },
    imageplaceholder: {
        width: 108,
        height: 108,
        margin: 10,
        borderWidth: 1,
        borderColor: defaultTheme.colors.lighterGray,
        borderRadius: 4,
        justifyContent: 'center'
    },
    plus: {
        paddingLeft: 30,
        fontSize: 40,
        color: defaultTheme.colors.gray
    },
    camera: {
        flexDirection: 'row',
        top: 70,
        right: 125,
        padding: 10,
        zIndex: 999,
        position: 'absolute',
    },
    cameraIcon: {
        color: defaultTheme.colors.primary,
    },
    edit: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        top: -30,
        right: -39,
        padding: 10,
        position: 'absolute'
    },
    editIcon: {
        color: defaultTheme.colors.white,

    },
    nameTitle: {
        color: defaultTheme.colors.lighterGray,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 13
    },
    error: {
        color: defaultTheme.colors.red,
        paddingLeft: 12
    },
    imgPost: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'flex-start',
        marginBottom: 10
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    popup:{
		backgroundColor:"#fff",
		height: 150,
	},
	confirmText:{
		marginTop: 20,
		textAlign:'center',
		justifyContent:'center',
		fontFamily: 'MeeraInimai-Regular',
	},
	popbtn:{
		flexDirection:'row',
		justifyContent:'center',
		alignItems:'center',
		marginTop: 20
	},
});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(MatrimonyDetails);
