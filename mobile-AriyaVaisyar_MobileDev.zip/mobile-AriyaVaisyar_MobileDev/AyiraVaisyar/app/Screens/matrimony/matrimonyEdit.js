/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    PermissionsAndroid,
    ScrollView,
    ActivityIndicator,
    FlatList
} from "react-native";
import RadioForm, { RadioButton, RadioButtonInput, RadioButtonLabel } from 'react-native-simple-radio-button';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePicker from "react-native-modal-datetime-picker";
import ImagePicker from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/MaterialIcons';
import CheckBox from 'react-native-check-box';
import Toast from 'react-native-simple-toast';
import moment from 'moment';
import { connect } from 'react-redux';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { FormList } from "../../utils/common";
import SegmentedControlTab from "react-native-segmented-control-tab";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import Modal from 'react-native-modal';



class matrimonyEdit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            matrimonyDetails: props.route.params.matrimonyDetails,
            isLoading: true,
            selectedDateShow: '',
            starAndFoot: [],
            education: [],
            isModalVisible: false,
            id: props.route.params.matrimonyDetails.id,
            name: props.route.params.matrimonyDetails.name,
            fatherName: props.route.params.matrimonyDetails.fatherName,
            motherName: props.route.params.matrimonyDetails.motherName,
            dateOfBirth: props.route.params.matrimonyDetails.dateOfBirth,
            dob: moment(props.route.params.matrimonyDetails.dateOfBirth).format("YYYY-MM-DD"),
            gender: props.route.params.matrimonyDetails.gender,
            timeZome: props.route.params.matrimonyDetails.timeZome,
            zodiacAndStar: props.route.params.matrimonyDetails.zodiacAndStar,
            userId: props.route.params.matrimonyDetails.userId,
            workingTown: props.route.params.matrimonyDetails.workingTown,
            monthlySalary: props.route.params.matrimonyDetails.monthlySalary,
            foodHabbit: props.route.params.matrimonyDetails.foodHabbit,
            horoscopeDescription: props.route.params.matrimonyDetails.horoscopeDescription,
            expectationOfVice: props.route.params.matrimonyDetails.expectationOfVice,
            horoscopePicId: props.route.params.matrimonyDetails.horoscopePicId,
            registrProfilePicId: props.route.params.matrimonyDetails.registrProfilePicId,
            registrProfilePicIdCheck: props.route.params.matrimonyDetails.registrProfilePicId,
            horoscopePicIdCheck: props.route.params.matrimonyDetails.horoscopePicId,
            moreDescription: props.route.params.matrimonyDetails.moreDescription,
            otherDetails: props.route.params.matrimonyDetails.otherDetails,
            createdAt: moment(props.route.params.matrimonyDetails.createdAt).format("YYYY-MM-DD"),
            educationID: props.route.params.matrimonyDetails.education,
            casteId: props.route.params.matrimonyDetails.sect,
            subCasteId: props.route.params.matrimonyDetails.subSect,
            marriedBrotherCount: props.route.params.matrimonyDetails.marriedBrotherCount,
            unMarriedBrotherCount: props.route.params.matrimonyDetails.unMarriedBrotherCount,
            unMarriedSisterCount: props.route.params.matrimonyDetails.unMarriedSisterCount,
            marriedSisterCount: props.route.params.matrimonyDetails.marriedSisterCount,
            isActive: props.route.params.matrimonyDetails.isActive,
            contact:  props.route.params.matrimonyDetails.contact,
            horoscopePic: '',
            registrProfilePic: '',
            zodiacList: [],
            directionAstrologyList: [],
            starList: [],
            education: [],
            sect: [],
            subCaste: [],
            income: '',
            isDateTimePickerVisible: false,
            isChecked: false,
            imagesource: '',
            horoscopePicSource: '',
            registrProfilePicSource: '',
            profileForCreation: '',
            selectedIndex: 0,
            maximumDate: null,
            time: new Date(),
        }
    }

    componentDidMount() {
        this.FormList();
        this.camerapermission();
        this.MatrimonyRegister();
        this.date();
        this.setState({ horoscopePicSource: "" });
        this.setState({ registrProfilePicSource: "" });
    }

    handleIndexChange = (index) => {
        this.setState({ selectedIndex: index });
    }

    FormList() {
        FormList((FormList) => {
            var educationList = [];
            FormList.data.education.map(val => {
                educationList.push({
                    value: val.label, label: val.label
                })
            })

            var sectList = [];
            FormList.data.sect.map(val => {
                sectList.push({
                    value: val.label, label: val.label
                })
            })


            this.setState({
                education: educationList,
                sect: sectList,
                defaultEducation: this.props.route.params.matrimonyDetails.education,
                defaultSect: this.props.route.params.matrimonyDetails.sect

            });


        });
    }

    date = () => {
        let today = new Date();
        const days_to_subtract = 6570;
        let new_date = new Date(today.valueOf() - (days_to_subtract * 24 * 60 * 60 * 1000))
        this.setState({ maximumDate: new_date });
    }

    getAgeFromBirthday(birthday) {
        if (birthday) {
            var birthday = moment(birthday).format("DD-MM-YYYY"),
                age = moment.duration(moment().diff(birthday)).asYears();
            var ageCheck = age.toFixed(0);
            return ageCheck;

        }
    }


    MatrimonyRegister() {


        apiService(`${'/api/zodiaclist'}`, 'get', '', '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    var item = [];
                    result.data.map(val => {
                        item.push({
                            value: val.zodiacName, label: val.zodiacName
                        })
                    })
                    this.setState({ zodiacList: item, defaultZodiacAndStar: this.props.route.params.matrimonyDetails.zodiacAndStar });
                }
            },
            (error) => {
            });
        apiService(`/api/directionastrologylist`, 'get', '', '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    var item = [];

                    result.data.map(val => {
                        item.push({
                            value: val.direcationName, label: val.direcationName
                        })
                    })
                    this.setState({ directionAstrologyList: item, defaultTimeZome: this.props.route.params.matrimonyDetails.timeZome });
                }
            },
            (error) => {
            });

        apiService(`/unsecure/mobile/subsectlist`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    var item = [];
                    result.data.map(val => {
                        item.push({
                            value: val.label, label: val.label
                        })
                    })
                    this.setState({ isLoading: false, subCaste: item, isLoading: false, defaultSubSect: (this.props.route.params.matrimonyDetails.subSect === null) || (this.props.route.params.matrimonyDetails.subSect == "") ? null : this.props.route.params.matrimonyDetails.subSect });
                }
            },
            (error) => {
            });



    }

    getStarList = (id) => {
        apiService(`/api/starlist/${1255}`, 'get', '', '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    var item = [];
                    result.data.map(val => {
                        item.push({
                            value: val.starName, label: val.starName
                        })
                    })
                    this.setState({ starList: item });
                }
            },
            (error) => {
            });

    }

    _showDateTimePicker = () => this.setState({ isDateTimePickerVisible: true });

    _hideDateTimePicker = () => this.setState({ isDateTimePickerVisible: false });

    _handleDatePicked = (date) => {
        var selectedDateShow = moment(date).format('DD-MM-YYYY, HH:mm:ss a')
        var selectedDate = moment(date).format('YYYY-MM-DD')
        this.setState({ dob: selectedDate, selectedDateShow: selectedDateShow, errDob: '' })
        this._hideDateTimePicker();
    };

    async camerapermission() {
        try {
            const granted = await PermissionsAndroid.request(
                PermissionsAndroid.PERMISSIONS.CAMERA

            );
            if (granted === PermissionsAndroid.RESULTS.GRANTED) {
                console.log("You can use the camera");
            } else {
                //   console.log("Camera permission denied");
            }
        } catch (err) {
            console.warn(err);
        }
    }

    selectPhotoTapped = (num) => {
        const options = {
            quality: 1.0,
            maxWidth: 500,
            maxHeight: 500,
            includeBase64: true,
            storageOptions: {
                skipBackup: true,
                privateDirectory: true
            }
        };

        ImagePicker.showImagePicker(options, (response) => {
            console.log('Response = ', response);
            if (response.didCancel) {
                console.log('User cancelled photo picker');
            }
            else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            }
            else if (response.customButton) {
                console.log('User tapped custom button: ', response.customButton);
            }
            else {
                var source = {
                    uri: response.uri,
                    type: response.type,
                    name: response.fileName,
                    height: response.height,
                    width: response.width,
                    // 	Platform.OS === "android" ? response.uri : response.uri.replace("file:/", "")
                };
                if (num == 1) {
                    this.setState({
                        registrProfilePic: source,
                        registrProfilePicIdCheck: null,
                        registrProfilePicSource: "data:image/jpeg;base64," + response.data,
                    });
                } else {
                    this.setState({
                        horoscopePic: source,
                        horoscopePicIdCheck: null,
                        horoscopePicSource: "data:image/jpeg;base64," + response.data,
                    });
                }

            }
        });
    }

    removePhoto = (num) => {
        if (num == 1) {
            this.setState({ registrProfilePicSource: "", registrProfilePicIdCheck: null, registrProfilePic: "" });
        } else {
            this.setState({ horoscopePicSource: "", horoscopePicIdCheck: null, horoscopePic: "" });
        }

    }

    openModal = (id) => {
        this.setState({ isModalVisible: true, selectedId: id });
    };

    cancelModal = () => {
        this.setState({ isModalVisible: false, selectedId: "" });
    };
    deleteRegister() {
        this.setState({ isLoading: true, isModalVisible: false, });
        apiService(`/api/marriageRegistration/${this.state.selectedId}`, 'delete', '', '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    this.setState({ isModalVisible: false, selectedId: '', isLoading: false, });
                    Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP);
                    this.props.navigation.navigate("MatrimonyList", { refresh: true, isUser: true });
                }
                else {
                    this.setState({ isLoading: false, isModalVisible: false, });
                }
            },
            (error) => {
                this.setState({ isLoading: false, isModalVisible: false, });
            });
    }




    sect = (id) => {
        this.checkValidation(id, "CASTE")
        this.setState({ casteId: id, errCaste: '' });
    }
    subCaste = (id) => {
        this.checkValidation(id, "SUBCASTE")
        this.setState({ subCasteId: id });
    }

    gender = (gender) => {
        this.checkValidation(gender, "GENDER");
        this.setState({ gender: gender, errGender: '' })
    }

    education = (id) => {
        this.checkValidation(id, "EDUCATION")
        this.setState({ educationID: id, errEducation: '' });
    }

    income = (id) => {
        this.checkValidation(id, "INCOME")
        this.setState({ income: id, errMonthlySalary: '' });
    }

    foodHabbit = (foodHabbit) => {
        this.checkValidation(foodHabbit, "FOODHABBIT");
        this.setState({ foodHabbit: foodHabbit, errFoodHabbit: '' })
    }
    horoscope = (horoscope) => {
        this.checkValidation(horoscope, "HOROSCOPE");
        this.setState({ horoscopeDescription: horoscope, errHoroscopeDescription: '' })
    }

    expectationOfVice = (value) => {
        this.checkValidation(value, "EXPECTATION");
        this.setState({ expectationOfVice: value, errExpectationOfVice: '' })
    }
    otherDetails = (value) => {
        this.checkValidation(value, "OTHERDETAILS");
        this.setState({ otherDetails: value, errOtherDetails: '' })
    }
    timeZome = (value) => {
        this.checkValidation(value, "TIMEZOME");
        this.setState({ timeZome: value, errTimeZome: '' })
    }
    zodiacAndStar = (value) => {
        this.checkValidation(value, "ZODIACANDSTAR");
        this.setState({ zodiacAndStar: value, errZodiacAndStar: '' })
    }



    checkValidation = (param, type) => {
        var valid = true;
        this.setState({
            errName: this.state.name != "" ? "" : this.state.errName,
            errGender: this.state.gender != "" ? "" : this.state.errGender,
            errDob: this.state.dob != "" ? "" : this.state.errDob,
            errEducation: this.state.educationID != "" ? "" : this.state.errEducation,
            errZodiacAndStar: this.state.zodiacAndStar != "" ? "" : this.state.errZodiacAndStar,
            errTimeZome: this.state.timeZome != "" ? "" : this.state.errTimeZome,
            errCaste: this.state.casteId != "" ? "" : this.state.errCaste,
            errMonthlySalary: this.state.monthlySalary != "" ? "" : this.state.errMonthlySalary,
            errFatherName: this.state.fatherName != "" ? "" : this.state.errFatherName,
            errFoodHabbit: this.state.foodHabbit != "" ? "" : this.state.errFoodHabbit,
            errHoroscopeDescription: this.state.horoscopeDescription != "" ? "" : this.state.errHoroscopeDescription,
            errExpectationOfVice: this.state.expectationOfVice != "" ? "" : this.state.errExpectationOfVice,
            errOtherDetails: this.state.otherDetails != "" ? "" : this.state.errOtherDetails,
            errWorkingTown: this.state.workingTown != "" ? "" : this.state.errWorkingTown,
            errContact: this.state.contact != "" ? "" : this.state.errContact,

        });
        switch (type) {

            case "NAME":
                if (param.length < 3) {
                    this.setState({ errName: "Please enter valid name" })
                }
                break;
            case "GENDER":
                if (param == "" || param == null) {
                    this.setState({ errGender: "Please select gender" })
                    valid = false;
                }
                break;
            case "EDUCATION":
                if (param == "") {
                    this.setState({ errEducation: "Please select Education" })
                    valid = false;
                }
                break;
            case "HOROSCOPE":
                if (param == "") {
                    this.setState({ errHoroscopeDescription: "Please select HoroscopeDescription" })
                    valid = false;
                }
                break;
            case "DOB":
                if (param == "" || param == null) {
                    this.setState({ errDob: "Please select Date of Birth" })
                    valid = false;
                }
                break;
            case "INCOME":
                if (param == "") {
                    this.setState({ errMonthlySalary: "Please Enter your MonthlyIncome" })
                    valid = false;
                }
                break;

            case "OTHERDETAILS":
                if (param == "") {
                    this.setState({ errOtherDetails: "Please select OtherDetails" })
                    valid = false;
                }
                break;
            case "TIMEZOME":
                if (param == "") {
                    this.setState({ errTimeZome: "Please select TimeZome" })
                    valid = false;
                }
                break;
            case "ZODIACANDSTAR":
                if (param == "") {
                    this.setState({ errZodiacAndStar: "Please select ZodiacAndStar" })
                    valid = false;
                }
                break;

            case "WORKINGTOWN":
                if (param == "") {
                    this.setState({ errWorkingTown: "Please Enter your WorkingTown" })
                    valid = false;
                }
                break;
                case "CONTACT":
				if (param == "") {
					this.setState({ errWorkingTown: "Please Enter Phone or Email" })
					valid = false;
				}
				break;

            case "FATHER":
                if (param == "") {
                    this.setState({ errFatherName: "Please Enter your FatherName" })
                    valid = false;
                }
                break;

            default:
            // Alert.alert("err");

        }

    }

    validation = () => {
        const { name, gender, educationID,
            dob, zodiacAndStar, timeZome,
            casteId, monthlySalary, fatherName,
            foodHabbit, horoscopeDescription, expectationOfVice, workingTown,contact, otherDetails } = this.state;
        var valid = true
        this.setState({
            errName: this.state.name != "" ? "" : this.state.errName,
            errGender: this.state.gender != "" ? "" : this.state.errGender,
            errDob: this.state.dob != "" ? "" : this.state.errDob,
            errEducation: this.state.educationID != "" ? "" : this.state.errEducation,
            errZodiacAndStar: this.state.zodiacAndStar != "" ? "" : this.state.errZodiacAndStar,
            errTimeZome: this.state.timeZome != "" ? "" : this.state.errTimeZome,
            errCaste: this.state.casteId != "" ? "" : this.state.errCaste,
            errMonthlySalary: this.state.monthlySalary != "" ? "" : this.state.errMonthlySalary,
            errFatherName: this.state.fatherName != "" ? "" : this.state.errFatherName,
            errFoodHabbit: this.state.foodHabbit != "" ? "" : this.state.errFoodHabbit,
            errHoroscopeDescription: this.state.horoscopeDescription != "" ? "" : this.state.errHoroscopeDescription,
            errExpectationOfVice: this.state.expectationOfVice != "" ? "" : this.state.errExpectationOfVice,
            errOtherDetails: this.state.otherDetails != "" ? "" : this.state.errOtherDetails,
            errWorkingTown: this.state.workingTown != "" ? "" : this.state.errWorkingTown,
            errContact: this.state.contact != "" ? "" : this.state.errContact,
        });

        if (name.length < 3) {
            this.setState({ errName: "Please enter valid name" })
            valid = false;
        }
        if (gender == "" || gender == null) {
            this.setState({ errGender: "Please select gender" })
            valid = false;
        }
        if (dob == "" || dob == null) {
            this.setState({ errDob: "Please select Date of Birth" })
            valid = false;
        }
        if (casteId == "") {
            this.setState({ errCaste: "Please select caste" })
            valid = false;
        }
        if (educationID == "") {
            this.setState({ errEducation: "Please select Education" })
            valid = false;
        }

        if (zodiacAndStar == "") {
            this.setState({ errZodiacAndStar: "Please select ZodiacAndStar" })
            valid = false;
        }
        if (timeZome == "") {
            this.setState({ errTimeZome: "Please select TimeZome" })
            valid = false;
        }
        if (workingTown == "") {
            this.setState({ errWorkingTown: "Please enter WorkingTown" })
            valid = false;
        }
        if (contact == "") {
			this.setState({ errContact: "Please enter Phone or Email" })
			valid = false;
		}
        if (monthlySalary == "") {
            this.setState({ errMonthlySalary: "Please enter MonthlyIncome" })
            valid = false;
        }
        if (fatherName == "") {
            this.setState({ errFatherName: "Please enter your FatherName" })
            valid = false;
        }
        if (foodHabbit == "") {
            this.setState({ errFoodHabbit: "Please select FoodHabbit" })
            valid = false;
        }
        if (horoscopeDescription == "") {
            this.setState({ errHoroscopeDescription: "Please select HoroscopeDescription" })
            valid = false;
        }
        if (expectationOfVice == "") {
            this.setState({ errExpectationOfVice: "Please select ExpectationOfVice" })
            valid = false;
        }
        if (otherDetails == "") {
            this.setState({ errOtherDetails: "Please select OtherDetails" })
            valid = false;
        }

        return valid;
    }


    handleSubmit = () => {
        if (this.validation()) {
            this.setState({ isLoading: true });
            let formData = new FormData();
            formData.append('id', this.state.id)
            formData.append('name', this.state.name)
            formData.append('fatherName', this.state.fatherName)
            formData.append('motherName', this.state.motherName)
            formData.append('userId', this.props.user.data.DATA.id)
            formData.append('gender', this.state.gender)
            formData.append('dateOfBirth', this.state.dob)
            formData.append('sect', this.state.casteId)
            formData.append('subSect', this.state.subCasteId)
            formData.append('timeZome', this.state.timeZome)
            formData.append('zodiacAndStar', this.state.zodiacAndStar)
            formData.append('education', this.state.educationID)
            formData.append('workingTown', this.state.workingTown)
            formData.append('contact', this.state.contact)
            formData.append('monthlySalary', this.state.monthlySalary)
            formData.append('marriedBrotherCount', this.state.marriedBrotherCount)
            formData.append('unMarriedBrotherCount', this.state.unMarriedBrotherCount)
            formData.append('marriedSisterCount', this.state.marriedSisterCount)
            formData.append('unMarriedSisterCount', this.state.unMarriedSisterCount)
            formData.append('foodHabbit', this.state.foodHabbit)
            formData.append('horoscopeDescription', this.state.horoscopeDescription)
            formData.append('expectationOfVice', this.state.expectationOfVice)
            formData.append('otherDetails', this.state.otherDetails)
            formData.append('moreDescription', this.state.moreDescription)
            formData.append('profileForCreation', this.state.profileForCreation)

            formData.append('createdAt', this.state.createdAt);
            formData.append('isActive', this.state.isActive);

            {
                this.state.horoscopePicId != null ?
                    formData.append('horoscopePicId', this.state.horoscopePicId) : null
            }
            {
                this.state.registrProfilePicId != null ?
                    formData.append('registrProfilePicId', this.state.registrProfilePicId) : null
            }

            {
                this.state.horoscopePicSource != "" ?
                    formData.append('horoscopePic', this.state.horoscopePic) : null
            }
            {
                this.state.registrProfilePicSource != "" ?
                    formData.append('registrProfilePic', this.state.registrProfilePic) : null
            }

            apiService(`/api/marriageRegistration`, 'put', formData, true, this.props.user.data.JWT,
                (result) => {
                    if (result.data.SUCCESS = true) {
                        this.setState({ isLoading: false });
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP);
                        this.props.navigation.navigate("MatrimonyList", { refresh: true, isUser: true })
                        // this.props.navigation.navigate("MatrimonyDetails", { matrimonyDetails: result.data.RESPONSE, refresh: true })
                    }
                },
                (error) => {
                    Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
                });
        }
    }

    render() {

        var gender_props = [
            { label: 'ஆண் (Male)', value: "Male" },
            { label: 'பெண் (Female)', value: "Female" }
        ];
        var foodHabbitprops = [
            { label: 'சைவம் (Veg)', value: "சைவம் (Veg)" },
            { label: 'அசைவம் (Non Veg)', value: "அசைவம் (Non Veg)" }
        ];
        var horoscopeDescriptionprops = [
            { label: 'சுத்த ஜாதகம்', value: "சுத்த ஜாதகம்" },
            { label: 'செவாய் தோஷம்', value: "செவாய் தோஷம்" },
            { label: 'ராகு கேது', value: "ராகு கேது" },
            { label: 'செவாய் + ராகு கேது', value: "செவாய் + ராகு கேது" }
        ];
        var expectationprops = [
            { label: 'தொழில்புரிபவர்', value: "தொழில்புரிபவர்" },
            { label: 'வேலையில் இருபவர்', value: "வேலையில் இருபவர்" },
            { label: 'இல்லத்தரசி', value: "இல்லத்தரசி" },
        ];
        var otherDetailsprops = [
            { label: 'முதல் திருமணம்', value: "முதல் திருமணம்" },
            { label: 'மறுமணம்', value: "மறுமணம்" },
            { label: 'விவகாரத்தானவர்', value: "விவகாரத்தானவர்" },
            { label: 'குழந்தைகள் உண்டு', value: "குழந்தைகள் உண்டு" },
        ];
        var income = [
            { label: '1 லட்சம் வரை', value: '1 லட்சம் வரை' },
            { label: '1 முதல் 3 லட்சம் வரை', value: '1 முதல் 3 லட்சம் வரை' },
            { label: '3 முதல் 5 லட்சம் வரை', value: '3 முதல் 5 லட்சம் வரை' },
            { label: '5 முதல் 10 லட்சம் வரை', value: '5 முதல் 10 லட்சம் வரை' },
            { label: '10 லட்சத்திற்கு மேல்', value: '10 லட்சத்திற்கு மேல்' }
        ]

        return (
            <React.Fragment>
                <Header title="திருமணப்பதிவு திருத்து" navigation={this.props.navigation} />
                <ScrollView>
                    {this.state.isLoading === true ?
                        <Loader /> :
                        <View style={styles.container}>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>ஜாதகர் பெயர் (Name) <Text style={styles.mandatory}>*</Text></Text>
                                <TextBox
                                    style={styles.textBox}
                                    placeholder="ஜாதகர் பெயர் (Name)"
                                    borderWidth={1}
                                    placeholderTextColor={defaultTheme.colors.lighterGray}
                                    value={this.state.name}
                                    onChange={name => { this.setState({ name: name }, this.checkValidation(name, "NAME")) }}

                                />
                                <Text style={styles.errMsg}>{this.state.errName}</Text>
                            </View>
                            <View>
                                <Text style={styles.lable}>பாலினம் (Gender) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.radioContainer}>
                                    <RadioForm
                                        radio_props={gender_props}
                                        labelStyle={styles.radioBtn}
                                        initial={this.state.gender == "Male" ? 0 : 1}
                                        formHorizontal={true}
                                        buttonColor={defaultTheme.colors.primary}
                                        labelColor={defaultTheme.colors.primary}
                                        selectedButtonColor={defaultTheme.colors.primary}
                                        buttonOuterColor={'red'}
                                        buttonInnerColor={'red'}
                                        buttonSize={14}
                                        animation={true}
                                        onPress={(value) => { this.gender(value) }}
                                    />
                                    <Text style={styles.errMsg}>{this.state.errGender}</Text>
                                </View>
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>பிறந்த தேதி மற்றும் நேரம் <Text style={styles.mandatory}>*</Text> </Text>
                                <TouchableOpacity onPress={this._showDateTimePicker} style={styles.datePicker}>
                                    <Icon name="date-range" size={25} style={styles.icons} />
                                    {this.state.dob == "" ?
                                        <Text style={styles.datePlaceholder}>பிறந்த தேதி மற்றும் நேரம் </Text> :
                                        <Text style={styles.dateTime}>{moment(this.state.dob).format('DD-MM-YYYY')}</Text>}
                                </TouchableOpacity>
                                <DateTimePicker
                                    isVisible={this.state.isDateTimePickerVisible}
                                    mode='datetime'
                                    date={moment(`${this.state.dob}`).toDate()}
                                    maximumDate={this.state.maximumDate}
                                    onConfirm={this._handleDatePicked}
                                    onCancel={this._hideDateTimePicker}
                                />
                                <Text style={styles.errMsg}>{this.state.errDob}</Text>
                            </View>

                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>ராசி மற்றும்  நட்சத்திரம் <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.zodiacList}
                                        defaultValue={this.state.defaultZodiacAndStar}
                                        containerStyle={{ height: 50 }}
                                        placeholder="ராசி மற்றும்  நட்சத்திரம்  (Zodiac and Star) "
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.zodiacAndStar(item.label)}
                                    />
                                </View>
                                <Text style={styles.errMsg}>{this.state.errZodiacAndStar}</Text>
                            </View>


                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>திசை இருப்பு  <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.directionAstrologyList}
                                        defaultValue={this.state.defaultTimeZome}
                                        containerStyle={{ height: 50 }}
                                        placeholder="திசை இருப்பு"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.timeZome(item.label)}
                                    />
                                </View>
                                <Text style={styles.errMsg}>{this.state.errTimeZome}</Text>
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>கல்வி (Education)  <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.education}
                                        defaultValue={this.state.defaultEducation}
                                        containerStyle={{ height: 50 }}
                                        placeholder="கல்வி"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.education(item.label)}
                                    />
                                </View>
                                <Text style={styles.errMsg}>{this.state.errEducation}</Text>
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>ஆயிரவைசியர் உட்ப்பிரிவு<Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.sect}
                                        defaultValue={this.state.defaultSect}
                                        containerStyle={{ height: 50 }}
                                        placeholder="ஆயிரவைசியர் உட்ப்பிரிவு"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.sect(item.label)}
                                    />
                                </View>
                                <Text style={styles.errMsg}>{this.state.errCaste}</Text>
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>கோத்திரம்</Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.subCaste}
                                        defaultValue={this.state.defaultSubSect}
                                        containerStyle={{ height: 50 }}
                                        placeholder="கோத்திரம்"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.subCaste(item.label)}
                                    />
                                </View>
                                {/* <Text style={styles.errMsg}>{this.state.errName}</Text> */}
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>தந்தையின் பெயர் (Father’s Name)<Text style={styles.mandatory}>*</Text></Text>
                                <TextBox
                                    style={styles.textBox}
                                    placeholder="தந்தையின் பெயர்"
                                    borderWidth={1}
                                    placeholderTextColor={defaultTheme.colors.lighterGray}
                                    value={this.state.fatherName}
                                    onChange={fatherName => { this.setState({ fatherName: fatherName }, this.checkValidation(fatherName, "FATHER")) }}

                                />
                                <Text style={styles.errMsg}>{this.state.errFatherName}</Text>
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>தாயார் பெயர் (Mother's Name)</Text>
                                <TextBox
                                    style={styles.textBox}
                                    placeholder="தாயார் பெயர்"
                                    borderWidth={1}
                                    placeholderTextColor={defaultTheme.colors.lighterGray}
                                    value={this.state.motherName}
                                    onChange={motherName => { this.setState({ motherName: motherName }) }}

                                />
                                {/* <Text style={styles.errMsg}>{this.state.errName}</Text> */}
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>பணிபுரியும் ஊர் (Working town)<Text style={styles.mandatory}>*</Text></Text>
                                <TextBox
                                    style={styles.textBox}
                                    placeholder="பணிபுரியும் ஊர்"
                                    borderWidth={1}
                                    placeholderTextColor={defaultTheme.colors.lighterGray}
                                    value={this.state.workingTown}
                                    onChange={workingTown => { this.setState({ workingTown: workingTown }, this.checkValidation(workingTown, "WORKINGTOWN")) }}

                                />
                                <Text style={styles.errMsg}>{this.state.errWorkingTown}</Text>
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>மாத வருமானம் (Monthly income)<Text style={styles.mandatory}>*</Text></Text>
                                <TextBox
                                    style={styles.textBox}
                                    placeholder="மாத வருமானம்"
                                    borderWidth={1}
                                    placeholderTextColor={defaultTheme.colors.lighterGray}
                                    value={this.state.monthlySalary}
                                    onChange={monthlySalary => { this.setState({ monthlySalary: monthlySalary }, this.checkValidation(monthlySalary, "INCOME")) }}
                                />
                                <Text style={styles.errMsg}>{this.state.errMonthlySalary}</Text>
                            </View>

                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>தொடர்புகொள்ள (Phone or Email)<Text style={styles.mandatory}>*</Text></Text>
                                <TextBox
                                    style={styles.textBox}
                                    placeholder="தொடர்புகொள்ள"
                                    borderWidth={1}
                                    placeholderTextColor={defaultTheme.colors.lighterGray}
                                    value={this.state.contact}
                                    onChange={contact => { this.setState({ contact: contact }, this.checkValidation(contact, "CONTACT")) }}

                                />
                                <Text style={styles.errMsg}>{this.state.errContact}</Text>
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={[styles.lable, styles.bold]}>உடன் பிறந்தோர்:</Text>
                                <Text style={[styles.lable, styles.bold]}>சகோதரர்கள் : </Text>
                                <View style={styles.familyInfo}>
                                    <View style={styles.oneHalf}>
                                        <Text style={styles.lable}>திருமணமாகாதவர் </Text>
                                        <TextBox
                                            style={styles.smallTextBox}
                                            borderWidth={1}
                                            placeholderTextColor={defaultTheme.colors.lighterGray}
                                            value={this.state.unMarriedBrotherCount}
                                            onChange={unMarriedBrotherCount => { this.setState({ unMarriedBrotherCount: unMarriedBrotherCount }) }}
                                        />
                                    </View>
                                    <View style={styles.twoHalf}>
                                        <Text style={styles.lable}>திருமணமானவர்  </Text>
                                        <TextBox
                                            style={styles.smallTextBox}
                                            borderWidth={1}
                                            placeholderTextColor={defaultTheme.colors.lighterGray}
                                            value={this.state.marriedBrotherCount}
                                            onChange={marriedBrotherCount => { this.setState({ marriedBrotherCount: marriedBrotherCount }) }}
                                        />
                                    </View>
                                </View>
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={[styles.lable, styles.bold]}>சகோதரிகள் : </Text>
                                <View style={styles.familyInfo}>
                                    <View style={styles.oneHalf}>
                                        <Text style={styles.lable}>திருமணமாகாதவர்</Text>
                                        <TextBox
                                            style={styles.smallTextBox}
                                            borderWidth={1}
                                            placeholderTextColor={defaultTheme.colors.lighterGray}
                                            value={this.state.unMarriedSisterCount}
                                            onChange={unMarriedSisterCount => { this.setState({ unMarriedSisterCount: unMarriedSisterCount }) }}
                                        />
                                    </View>
                                    <View style={styles.twoHalf}>
                                        <Text style={styles.lable}>திருமணமானவர்</Text>
                                        <TextBox
                                            style={styles.smallTextBox}
                                            borderWidth={1}
                                            placeholderTextColor={defaultTheme.colors.lighterGray}
                                            value={this.state.marriedSisterCount}
                                            onChange={marriedSisterCount => { this.setState({ marriedSisterCount: marriedSisterCount }) }}
                                        />
                                    </View>
                                </View>
                            </View>
                            <View>
                                <Text style={styles.lable}>உணவுப் பழக்கம் (Food Habbit) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.radioContainer}>
                                    <RadioForm
                                        radio_props={foodHabbitprops}
                                        labelStyle={styles.radioBtn}
                                        initial={this.state.foodHabbit == "சைவம் (Veg)" ? 0 : 1}
                                        formHorizontal={true}
                                        buttonColor={defaultTheme.colors.primary}
                                        labelColor={defaultTheme.colors.primary}
                                        selectedButtonColor={defaultTheme.colors.primary}
                                        buttonOuterColor={'red'}
                                        buttonInnerColor={'red'}
                                        buttonSize={14}
                                        animation={true}
                                        onPress={(value) => { this.foodHabbit(value) }}
                                    />
                                    <Text style={styles.errMsg}>{this.state.errFoodHabbit}</Text>
                                </View>
                            </View>
                            <View>
                                <Text style={styles.lable}>ஜாதக விவரம் (Horoscope Description) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.radioContainer}>
                                    <RadioForm
                                        radio_props={horoscopeDescriptionprops}
                                        labelStyle={styles.radioBtn}
                                        initial={this.state.horoscopeDescription == "சுத்த ஜாதகம்" ? 0 : this.state.horoscopeDescription == "செவாய் தோஷம்" ? 1 : this.state.horoscopeDescription == "ராகு கேது" ? 2 : this.state.horoscopeDescription == "செவாய் + ராகு கேது" ? 3 : -1}
                                        formHorizontal={false}
                                        buttonColor={defaultTheme.colors.primary}
                                        labelColor={defaultTheme.colors.primary}
                                        selectedButtonColor={defaultTheme.colors.primary}
                                        buttonOuterColor={'red'}
                                        buttonInnerColor={'red'}
                                        buttonSize={14}
                                        animation={true}
                                        onPress={(value) => { this.horoscope(value) }}
                                    />
                                    <Text style={styles.errMsg}>{this.state.errHoroscopeDescription}</Text>
                                </View>
                            </View>
                            <View>
                                <Text style={styles.lable}>துணை பற்றிய எதிர்பார்ப்பு <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.radioContainer}>
                                    <RadioForm
                                        radio_props={expectationprops}
                                        labelStyle={styles.radioBtn}
                                        initial={this.state.expectationOfVice == "தொழில்புரிபவர்" ? 0 : this.state.expectationOfVice == "வேலையில் இருபவர்" ? 1 : this.state.expectationOfVice == "இல்லத்தரசி" ? 2 : -1}
                                        formHorizontal={false}
                                        buttonColor={defaultTheme.colors.primary}
                                        labelColor={defaultTheme.colors.primary}
                                        selectedButtonColor={defaultTheme.colors.primary}
                                        buttonOuterColor={'red'}
                                        buttonInnerColor={'red'}
                                        buttonSize={14}
                                        animation={true}
                                        onPress={(value) => { this.expectationOfVice(value) }}
                                    />
                                    <Text style={styles.errMsg}>{this.state.errExpectationOfVice}</Text>
                                </View>
                            </View>
                            <View>
                                <Text style={styles.lable}>இதர விவரங்கள் <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.radioContainer}>
                                    <RadioForm
                                        radio_props={otherDetailsprops}
                                        labelStyle={styles.radioBtn}
                                        initial={this.state.otherDetails == "முதல் திருமணம்" ? 0 : this.state.otherDetails == "மறுமணம்" ? 1 : this.state.otherDetails == "விவகாரத்தானவர்" ? 2 : this.state.otherDetails == "குழந்தைகள் உண்டு" ? 3 : -1}
                                        formHorizontal={false}
                                        buttonColor={defaultTheme.colors.primary}
                                        labelColor={defaultTheme.colors.primary}
                                        selectedButtonColor={defaultTheme.colors.primary}
                                        buttonOuterColor={'red'}
                                        buttonInnerColor={'red'}
                                        buttonSize={14}
                                        animation={true}
                                        onPress={(value) => { this.otherDetails(value) }}
                                    />
                                    <Text style={styles.errMsg}>{this.state.errOtherDetails}</Text>
                                </View>
                            </View>
                            <View style={styles.textContainer}>
                                <Text style={styles.lable}>கூடுதல் தகவல்கள் (More Description)<Text style={styles.mandatory}>*</Text></Text>
                                <TextBox
                                    style={styles.textarea}
                                    placeholder="கூடுதல் தகவல்கள்"
                                    borderWidth={1}
                                    placeholderTextColor={defaultTheme.colors.lighterGray}
                                    value={this.state.moreDescription}
                                    multiline={true}
                                    numberOfLines={3}
                                    onChange={moreDescription => { this.setState({ moreDescription: moreDescription }) }}

                                />
                                {/* <Text style={styles.errMsg}>{this.state.errName}</Text> */}
                            </View>





                            <View style={styles.row}>
                                <Text style={styles.photoText}>புகைப்படத்தைப் பதிவேற்றுக </Text>
                                {(this.state.registrProfilePicIdCheck == null) && (this.state.registrProfilePicSource == "") ?
                                    <TouchableOpacity style={styles.imageplaceholder} onPress={() => this.selectPhotoTapped(1)}>
                                        <Icon name="add" style={styles.plus} />
                                    </TouchableOpacity> :
                                    <View style={styles.registrProfileDesign}>
                                        {this.state.registrProfilePicIdCheck != null ?
                                            <Image key={454} source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + this.state.registrProfilePicId + "?" + this.state.time }} style={{ width: '100%', height: '100%' }} />
                                            : <Image key={581} source={{ uri: this.state.registrProfilePicSource }} style={{ width: '100%', height: '100%' }} />}
                                    </View>}
                                {(this.state.registrProfilePicIdCheck != null) || (this.state.registrProfilePicSource != "") ?
                                    <TouchableOpacity style={styles.deleteIcon} onPress={() => this.removePhoto(1)}>
                                        {SvgImages.deleteIcon(20, 20)}
                                    </TouchableOpacity>

                                    : null}
                            </View>


                            <View style={styles.row}>
                                <Text style={styles.photoText}>ஜாதகத்திதைப் பதிவேற்றுக </Text>
                                {(this.state.horoscopePicIdCheck == null) && (this.state.horoscopePicSource == "") ?
                                    <TouchableOpacity style={styles.imageplaceholder} onPress={() => this.selectPhotoTapped(2)}>
                                        <Icon name="add" style={styles.plus} />
                                    </TouchableOpacity> :
                                    <View style={styles.horoscopePicDesign}>
                                        {this.state.horoscopePicIdCheck != null ?
                                            <Image key={454} source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + this.state.horoscopePicId + "?" + this.state.time }} style={{ width: '100%', height: '100%' }} />
                                            : <Image key={581} source={{ uri: this.state.horoscopePicSource }} style={{ width: '100%', height: '100%' }} />}
                                    </View>}
                                {(this.state.horoscopePicIdCheck != null) || (this.state.horoscopePicSource != "") ?
                                    <TouchableOpacity style={styles.deleteIcon} onPress={() => this.removePhoto(2)}>
                                        {SvgImages.deleteIcon(20, 20)}
                                    </TouchableOpacity>

                                    : null}
                            </View>
                            {/* <View>
                                <Button
                                    style={styles.button}
                                    btnName="சமர்ப்பிக்கவும்"
                                    color={defaultTheme.colors.white}
                                    size={16}
                                    onPress={() => this.handleSubmit()}
                                />
                            </View> */}
                            <View style={styles.popupbtn}>
                                <TouchableOpacity style={styles.popbtn} onPress={() => this.openModal(this.state.id)}>
                                    <Text style={styles.popUpCancel}>நீக்கு</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.popbtn} onPress={() => this.handleSubmit()}>
                                    <Text style={styles.popUpbtnText}>திருத்து</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    }
                </ScrollView>

                <Modal isVisible={this.state.isModalVisible}
                    animationInTiming={1000}
                    animationOutTiming={1000}
                    backdropTransitionInTiming={800}
                    backdropTransitionOutTiming={800}
                >
                    <View style={styles.popup}>
                        <Text style={styles.confirmText}>நீங்கள் நிச்சயமாக நீக்க விரும்புகிறீர்களா?</Text>
                        <View style={styles.popupbtn}>
                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                <Text style={styles.popUpCancel}>ரத்து</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.popbtn} onPress={() => this.deleteRegister()}>
                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>

            </React.Fragment>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 5
    },
    downRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        //paddingHorizontal: 5
    },
    radioContainer: {
        marginTop: 15
    },
    mt12: {
        marginTop: 12
    },
    textContainer: {
        paddingBottom: 4
    },
    textBox: {
        borderWidth: 1.5,
        borderRadius: 4,
        paddingBottom: 6,
        textAlignVertical: "top",
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray
    },
    textarea: {
        borderWidth: 1.5,
        borderRadius: 4,
        paddingBottom: 6,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray
    },
    smallTextBox: {
        borderWidth: 1.5,
        borderRadius: 4,
        paddingBottom: 6,
        marginRight: 15,
        width: '90%',
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray
    },
    lable: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 15,
        position: 'relative'
    },
    photoText: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        paddingTop: 45,
        fontSize: 15,
        position: 'relative'
    },
    bold: {
        fontWeight: 'bold'
    },

    text: {
        color: defaultTheme.colors.white
    },
    radioBtn: {
        fontFamily: 'MeeraInimai-Regular',
        marginRight: 20,
        paddingTop: 5
    },
    datePicker: {
        flexDirection: 'row',
        alignItems: 'center',
        borderBottomWidth: 1.5,
        marginVertical: 10,
        borderRadius: 4,
        borderWidth: 1,
        borderColor: defaultTheme.colors.lighterGray,
        height: 45,
    },
    icons: {
        color: defaultTheme.colors.lighterGray,
        right: 7,
        position: 'absolute'
    },
    dateTime: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 14,
        left: 15,
        color: defaultTheme.colors.gray,
        position: 'relative'
    },
    datePlaceholder: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 14,
        left: 15,
        color: defaultTheme.colors.lighterGray,
        position: 'relative'
    },
    mandatory: {
        color: defaultTheme.colors.red,
    },
    familyInfo: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingTop: 5,
    },
    oneHalf: {
        flex: 1,
        alignItems: 'flex-start'
    },
    twoHalf: {
        flex: 1,
        alignItems: 'flex-start',
    },
    imageplaceholder: {
        width: 80,
        height: 80,
        margin: 10,
        borderWidth: 1,
        borderColor: defaultTheme.colors.lighterGray,
        borderRadius: 4,
        justifyContent: 'center'
    },
    plus: {
        paddingLeft: 20,
        justifyContent: 'center',
        fontSize: 40,
        color: defaultTheme.colors.gray
    },
    button: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        width: '100%',
        fontFamily: 'MeeraInimai-Regular',
    },
    errMsg: {
        color: defaultTheme.colors.red,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 10,
        height: 15,
    },
    footer: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: defaultTheme.colors.primary,
        paddingVertical: 2
    },
    footerText: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 15,
        paddingLeft: 50,
    },
    tabStyle: {
        backgroundColor: defaultTheme.colors.secondory,
        color: defaultTheme.colors.secondory,
        fontFamily: 'Comfortaa-SemiBold',
        borderColor: defaultTheme.colors.secondory,
        height: 50,
    },
    tabActive: {
        backgroundColor: defaultTheme.colors.secondory,
        color: defaultTheme.colors.secondory,
    },
    tabText: {
        fontSize: 13,
        color: defaultTheme.colors.white,
        fontFamily: 'Comfortaa-SemiBold',
    },

    card: {
        borderWidth: 1,
        borderRadius: 5,
        borderColor: defaultTheme.colors.lighterGray,
        paddingVertical: 10,
        paddingHorizontal: 10,
        marginVertical: 10
    },
    userPic: {
        width: 90,
        height: 90,
        paddingLeft: 15
    },
    profile: {
        width: '100%',
        height: '100%'
    },
    content: {
        paddingLeft: 10,
        width: '60%',
        paddingTop: 12
    },
    nameContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    name: {
        fontSize: 16,
        fontWeight: 'bold',
        color: defaultTheme.colors.gray
    },
    education: {
        fontSize: 12,
        paddingTop: 2,
        color: defaultTheme.colors.gray
    },
    workingTown: {
        fontSize: 12,
        paddingTop: 2,
        color: defaultTheme.colors.gray
    },
    dob: {
        fontSize: 12,
        color: defaultTheme.colors.gray
    },
    btn: {
        backgroundColor: defaultTheme.colors.primary,
        paddingVertical: 5,
        paddingHorizontal: 10,
        width: 100,
        borderRadius: 50,
        fontSize: 12,
        textAlign: 'center',
        color: defaultTheme.colors.white
    },
    fontFamily: {
        fontFamily: 'MeeraInimai-Regular',
    },
    deleteIcon: {
        right: 12,

    },
    horoscopePicDesign: {
        width: 85,
        height: 100,
        borderWidth: 0.5,
        borderColor: defaultTheme.colors.gray,
        marginTop: 10,
        marginLeft: 45
    },
    registrProfileDesign: {
        width: 85,
        height: 100,
        borderWidth: 0.5,
        borderColor: defaultTheme.colors.gray,
        marginTop: 10,
        marginLeft: 35,
        marginBottom: 10
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    popup: {
        backgroundColor: "#fff",
        height: 150,
    },
    confirmText: {
        marginTop: 20,
        textAlign: 'center',
        justifyContent: 'center',
        fontFamily: 'MeeraInimai-Regular',
    },
    popbtn: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20
    },

});
function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(matrimonyEdit);
