/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    FlatList,
    Image,
    ActivityIndicator
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
import { ScrollView } from "react-native-gesture-handler";
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';

class matrimonyMenu extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }
    gotoEmploymentList = () => {
        this.props.navigation.navigate("BusinessList", { taluk: this.state.taluk, district: null })
    }



    render() {
        return (
            <React.Fragment>
                <Header title="திருமணப்பதிவுகள்" navigation={this.props.navigation} />
                <View style={styles.container}>
                    <TouchableOpacity style={[styles.card, styles.newsColor]} onPress={() => this.props.navigation.navigate("MatrimonyFilter")}>
                        <View style={styles.img}>{SvgImages.martimonySearch(60, 60)}</View>
                        <Text style={styles.text}>திருமணப்பதிவுகள் தேடல்</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.card, styles.wishesColor]} onPress={() => this.props.navigation.navigate("MatrimonyList",{ isUser:true })}>
                        <View style={styles.img}>{SvgImages.martimonyCreation(60, 60)}</View>
                        <Text style={styles.text}>திருமணப்பதிவு பார்க்கவும் / உருவாக்கவும்</Text>
                    </TouchableOpacity>
                </View>

            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10
    },
    row: {
        flexDirection: 'row',
    },
    card: {
        flexDirection: 'row',
        // justifyContent:'center',
        alignItems: 'center',
        backgroundColor: '#2196f3',
        paddingVertical: 25,
        borderRadius: 8,
        marginBottom: 10
    },
    approveColor: {
        backgroundColor: defaultTheme.colors.green,
    },
    newsColor: {
        backgroundColor: defaultTheme.colors.lightBlue,
    },
    wishesColor: {
        backgroundColor: '#FF69B4'
    },
    obituary: {
        backgroundColor: '#ff5722'
    },
    announcementColor: {
        backgroundColor: defaultTheme.colors.yellow,
    },
    img: {
        paddingLeft: 10,
    },
    text: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 18,
        paddingLeft: 20,
        color: defaultTheme.colors.white,
        width: 250
    },
});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(matrimonyMenu);
