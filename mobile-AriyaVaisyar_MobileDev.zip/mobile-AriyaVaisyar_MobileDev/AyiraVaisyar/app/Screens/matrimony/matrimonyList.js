/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    PermissionsAndroid,
    ScrollView,
    ActivityIndicator,
    FlatList
} from "react-native";
import RadioForm, { RadioButton, RadioButtonInput, RadioButtonLabel } from 'react-native-simple-radio-button';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePicker from "react-native-modal-datetime-picker";
import ImagePicker from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/MaterialIcons';
import CheckBox from 'react-native-check-box';
import Toast from 'react-native-simple-toast';
import moment from 'moment';
import { connect } from 'react-redux';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { FormList } from "../../utils/common";
import SegmentedControlTab from "react-native-segmented-control-tab";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';


class matrimonyList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            matrimonyList:[],
            isUser: props.route.params.isUser,
            sect: props.route.params.sect,
            gender: props.route.params.gender,
            horoscopeDescription: props.route.params.horoscopeDescription,
            otherDetails: props.route.params.otherDetails,
            pageNo: 1,
            pageSize: 50,

        }
    }

    componentDidMount() {
        this.AllRegisterCall();
    }

    componentDidUpdate(prevProps) {
        var params = this.props.route.params;
        if (params && params.refresh) {
            this.AllRegisterCall();
            this.props.route.params.refresh = false;
        }
    }



    AllRegisterCall() {
        this.setState({ isLoading: true });
        if (this.state.isUser == false) {
            console.log(this.state.sect + " " + this.state.gender + " " + this.state.horoscopeDescription + " " + this.state.otherDetails)
            var URL = '/api/marriageRegistrations/filter/'

            apiService(`${URL}${this.state.pageNo}/${this.state.pageSize}/${this.props.user.data.DATA.id}`, 'post', {
                gender: this.state.gender,
                sect: this.state.sect,
                horoscopeDescription: this.state.horoscopeDescription,
                otherDetails: this.state.otherDetails,
            }, '', this.props.user.data.JWT,

                (result) => {
                    if (result.status === 200) {
                        var item = [];
                        result.data.totalRegistr.map(val => {
                            var age = moment.duration(moment().diff(val.dateOfBirth)).asYears();
                            var dob = age.toFixed(0);
                            item.push({
                                name: val.name, fatherName: val.fatherName, workingTown: val.workingTown, dateOfBirth: dob,
                                registrProfilePicId: val.registrProfilePicId, education: val.education,
                                monthlySalary: val.monthlySalary, id: val.id,
                                allDetails: val

                            })
                        })
                        this.setState({ matrimonyList: item, isLoading: false });
                    }
                },
                (error) => {
                });
        }
        else {
            var URL = '/api/userMarriageRegistrations/'
            apiService(`${URL}${this.state.pageNo}/${this.state.pageSize}/${this.props.user.data.DATA.id}`, 'get', '', '', this.props.user.data.JWT,
                (result) => {
                    if (result.status === 200) {
                        var item = [];
                        result.data.totalRegistr.map(val => {
                            var age = moment.duration(moment().diff(val.dateOfBirth)).asYears();
                            var dob = age.toFixed(0);
                            item.push({
                                name: val.name, fatherName: val.fatherName, workingTown: val.workingTown, dateOfBirth: dob,
                                registrProfilePicId: val.registrProfilePicId, education: val.education,
                                monthlySalary: val.monthlySalary, id: val.id,
                                allDetails: val

                            })
                        })
                        this.setState({ matrimonyList: item, isLoading: false });
                    }
                },
                (error) => {
                });
        }

    }


    render() {
        return (
            <React.Fragment>
                <Header title={"திருமணப்பதிவுகள்"} navigation={this.props.navigation} />

                <View style={styles.container}>
                    {this.state.isLoading === true ?
                        <Loader /> :
                        <View>
                            {this.state.matrimonyList.length != 0 ?
                                <FlatList
                                    data={this.state.matrimonyList}
                                    extraData={this.state}
                                    onEndReachedThreshold={0}
                                    keyExtractor={(item) => item.id.toString()}
                                    onEndReached={this.pagination}
                                    renderItem={({ item }) =>
                                        <View style={[styles.card, styles.downRow]}>
                                            <View style={[styles.downRow]}>
                                                <View style={styles.userPic}>
                                                    {item.registrProfilePicId != null ?
                                                        <Image style={styles.profile} source={{ uri: `${ApiUrls.apiEnvironment}` + "/unsecure/view/" + item.registrProfilePicId }} /> :
                                                        <Image style={styles.profile} source={require("../../assets/images/profileDefault.jpg")} />

                                                    }
                                                </View>
                                            </View>
                                            <View style={styles.content}>
                                                <View style={styles.nameContainer}>
                                                    <Text style={[styles.name, styles.fontFamily]}>{item.name}</Text>
                                                </View>
                                                <Text style={[styles.fontFamily, styles.education]}>{item.education}</Text>
                                                <Text style={[styles.fontFamily, styles.education]}>{item.dateOfBirth + " " + "Years"}</Text>
                                                <View style={styles.downRow}>
                                                    <Text style={[styles.workingTown, styles.fontFamily]}>{item.workingTown}</Text>
                                                    {/* <TouchableOpacity onPress={() => this.props.navigation.navigate("MatrimonyDetails", { matrimonyDetails: item.allDetails })}>
												<Text style={[styles.btn, styles.fontFamily]}>மேலும்</Text>
											</TouchableOpacity> */}
                                                </View>
                                                <View style={styles.detailsBtn}>
                                                    {this.state.isUser == true ?
                                                        <TouchableOpacity onPress={() => this.props.navigation.navigate("MatrimonyEdit", { matrimonyDetails: item.allDetails })}>
                                                            <Text style={[styles.btn, styles.btnEdit, styles.fontFamily]}>திருத்து</Text>
                                                        </TouchableOpacity> : null}
                                                    <TouchableOpacity onPress={() => this.props.navigation.navigate("MatrimonyDetails", { matrimonyDetails: item.allDetails })}>
                                                        <Text style={[styles.btn, styles.fontFamily]}>மேலும்</Text>
                                                    </TouchableOpacity>
                                                </View>
                                            </View>
                                        </View>
                                    }
                                /> : <View>
                                    <Text style={styles.noDataFound}>No data Found</Text>
                                </View>
                            }
                        </View>
                    }
                </View>
                {this.state.isUser == true ?
                    <TouchableOpacity style={styles.footer} onPress={() => this.props.navigation.navigate("MatrimonyRegister")}>
                        <Icon name="add" style={styles.plus} />
                        <Text style={styles.footerText}>திருமணப்பதிவுகள் உருவாக்கவும்</Text>
                    </TouchableOpacity>
                    : null}

            </React.Fragment>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 5
    },
    downRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        //paddingHorizontal: 5
    },
    detailsBtn: {
        flexDirection: 'row',
        justifyContent: 'flex-end'
    },
    radioContainer: {
        marginTop: 15
    },
    mt12: {
        marginTop: 12
    },
    textContainer: {
        paddingBottom: 4
    },
    textBox: {
        borderWidth: 1.5,
        borderRadius: 4,
        paddingBottom: 6,
        textAlignVertical: "top",
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray
    },
    textarea: {
        borderWidth: 1.5,
        borderRadius: 4,
        paddingBottom: 6,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray
    },
    smallTextBox: {
        borderWidth: 1.5,
        borderRadius: 4,
        paddingBottom: 6,
        marginRight: 15,
        width: '90%',
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray
    },
    lable: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 15,
        position: 'relative'
    },
    photoText: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        paddingTop: 45,
        fontSize: 15,
        position: 'relative'
    },
    bold: {
        fontWeight: 'bold'
    },

    text: {
        color: defaultTheme.colors.white
    },
    radioBtn: {
        fontFamily: 'MeeraInimai-Regular',
        marginRight: 20,
        paddingTop: 5
    },
    datePicker: {
        flexDirection: 'row',
        alignItems: 'center',
        borderBottomWidth: 1.5,
        marginVertical: 10,
        borderRadius: 4,
        borderWidth: 1,
        borderColor: defaultTheme.colors.lighterGray,
        height: 45,
    },
    icons: {
        color: defaultTheme.colors.lighterGray,
        right: 7,
        position: 'absolute'
    },
    dateTime: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 14,
        left: 15,
        color: defaultTheme.colors.gray,
        position: 'relative'
    },
    datePlaceholder: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 14,
        left: 15,
        color: defaultTheme.colors.lighterGray,
        position: 'relative'
    },
    mandatory: {
        color: defaultTheme.colors.red,
    },
    familyInfo: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingTop: 5,
    },
    oneHalf: {
        flex: 1,
        alignItems: 'flex-start'
    },
    twoHalf: {
        flex: 1,
        alignItems: 'flex-start',
    },
    imageplaceholder: {
        width: 80,
        height: 80,
        margin: 10,
        borderWidth: 1,
        borderColor: defaultTheme.colors.lighterGray,
        borderRadius: 4,
        justifyContent: 'center'
    },
    plus: {
        paddingLeft: 20,
        justifyContent: 'center',
        fontSize: 40,
        color: defaultTheme.colors.gray
    },
    button: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        width: '100%',
        fontFamily: 'MeeraInimai-Regular',
    },
    errMsg: {
        color: defaultTheme.colors.red,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 10,
        height: 15,
    },
    footer: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: defaultTheme.colors.white,
        paddingVertical: 10
    },
    footerText: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 15,
        paddingLeft: 10
    },
    plus: {
        paddingLeft: 50,
        fontSize: 35,
        justifyContent: 'center',
        alignItems: 'center',
        color: defaultTheme.colors.gray
    },
    tabStyle: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.primary,
        fontFamily: 'MeeraInimai-Regular',
        borderColor: defaultTheme.colors.primary,
        borderWidth: 1,
        borderRadius: 0,
        height: 50,
    },
    tabActive: {
        backgroundColor: defaultTheme.colors.secondory,
        color: defaultTheme.colors.secondory,
    },
    tabText: {
        fontSize: 13,
        color: defaultTheme.colors.white,
        fontFamily: 'MeeraInimai-Regular',
    },

    card: {
        borderWidth: 1,
        borderRadius: 5,
        borderColor: defaultTheme.colors.lighterGray,
        paddingVertical: 10,
        paddingHorizontal: 10,
        marginVertical: 10,
    },
    userPic: {
        width: 90,
        height: 90,
        paddingLeft: 15
    },
    profile: {
        width: '100%',
        height: '100%',
    },
    content: {
        paddingLeft: 10,
        width: '60%',
        // paddingTop: 12
    },
    nameContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    name: {
        fontSize: 16,
        fontWeight: 'bold',
        color: defaultTheme.colors.gray
    },
    education: {
        fontSize: 12,
        paddingTop: 2,
        color: defaultTheme.colors.gray
    },
    workingTown: {
        fontSize: 12,
        paddingTop: 2,
        color: defaultTheme.colors.gray
    },
    dob: {
        fontSize: 12,
        color: defaultTheme.colors.gray
    },
    btn: {
        backgroundColor: defaultTheme.colors.primary,
        paddingVertical: 5,
        paddingHorizontal: 10,
        width: 100,
        borderRadius: 50,
        fontSize: 12,
        textAlign: 'center',
        color: defaultTheme.colors.white
    },
    btnEdit: {
        marginRight: 10
    },
    fontFamily: {
        fontFamily: 'MeeraInimai-Regular',
    },
    deleteIcon: {
        right: 12
    },
    horoscopePicDesign: {
        width: 85,
        height: 100,
        borderWidth: 0.5,
        borderColor: defaultTheme.colors.gray,
        marginTop: 10,
        marginLeft: 50
    },
    registrProfileDesign: {
        width: 85,
        height: 100,
        borderWidth: 0.5,
        borderColor: defaultTheme.colors.gray,
        marginTop: 10,
        marginLeft: 35,
        marginBottom: 10
    },  noDataFound: {
        marginTop: 30,
        textAlign: 'center'
    }

});
function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(matrimonyList);
