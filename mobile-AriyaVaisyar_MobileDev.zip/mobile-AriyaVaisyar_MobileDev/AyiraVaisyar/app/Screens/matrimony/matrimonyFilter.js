/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    FlatList,
    Image,
    ActivityIndicator
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
import { ScrollView } from "react-native-gesture-handler";
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import { getPixelSizeForLayoutSize } from "react-native/Libraries/Utilities/PixelRatio";

class MatrimonyFilter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            sect: [],
            gender: [],
            horoscopeDescription: [],
            otherDetails: [],
            isLoading: false,
            genderValue:null,
            sectValue:null,
            horoscopeDescriptionValue:null,
            otherDetailsValue:null,
        }
    }

    componentDidMount() {
        this.FormList();
    }

    FormList() {
        FormList((FormList) => {
            this.setState({
                sect: FormList.data.sect
            });


        });

        this.state.gender.push({ label: 'ஆண் (Male)', value: "Male" },
            { label: 'பெண் (Female)', value: "Female" })

        this.state.horoscopeDescription.push({
            label: 'சுத்த ஜாதகம்', value: "சுத்த ஜாதகம்"
        },
            { label: 'செவாய் தோஷம்', value: "செவாய் தோஷம்" },
            { label: 'ராகு கேது', value: "ராகு கேது" },
            { label: 'செவாய் + ராகு கேது', value: "செவாய் + ராகு கேது" }
        )

        this.state.otherDetails.push({
            label: 'முதல் திருமணம்', value: "முதல் திருமணம்"
        },
            { label: 'மறுமணம்', value: "மறுமணம்" },
            { label: 'விவகாரத்தானவர்', value: "விவகாரத்தானவர்" },
            { label: 'குழந்தைகள் உண்டு', value: "குழந்தைகள் உண்டு" },
        )

    }

    selectGender = (value) => {
      this.setState({genderValue:value,genderErr:""});
    }

    gotoMatrimonyFilter = () => {
        if (this.validation()) {
            this.props.navigation.navigate("MatrimonyList", { gender: this.state.genderValue, sect: this.state.sectValue,horoscopeDescription: this.state.horoscopeDescriptionValue,otherDetails: this.state.otherDetailsValue,isUser:false })
        } 
    }

    gotoFilterClear = () => {
        console.log("test")
        this.setState({defaultgender:null,defaulthoroscopeDescription:null,defaultSect:null,defaultotherDetails:null,genderValue:null,sectValue:null,horoscopeDescriptionValue:null,otherDetailsValue:null  })
    }

    validation = () => {
        const { genderValue } = this.state;
        var valid = true
        this.setState({ genderErr: this.state.genderValue != "" ? "" : this.state.genderErr });
        if (genderValue == "" || genderValue == null) {
            this.setState({ genderErr: "Please select gender" })
            valid = false;
        }
        return valid;
    }

    render() {
        return (
            <React.Fragment>
                <Header title="திருமணப்பதிவுகள் தேடல்" navigation={this.props.navigation} />
                <View style={styles.container}>
                    <View style={styles.placeContainer}>
                        <Text style={styles.lable}>பாலினம் (Gender) <Text style={styles.mandatory}>*</Text></Text>
                        <View style={styles.mt12}>
                            <DropDownPicker
                                items={this.state.gender}
                                defaultValue={this.state.defaultgender}
                                containerStyle={{ height: 50 }}
                                placeholder="பாலினம்"
                                style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                itemStyle={{ justifyContent: 'flex-start' }}
                                placeholderStyle={{ color: defaultTheme.colors.gray }}
                                selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                dropDownStyle={{ backgroundColor: '#fafafa' }}
                                onChangeItem={item => this.setState({ genderValue: item.value,defaultgender:item.value,genderErr:""})}
                            />
                        </View>

                        <Text style={styles.lable}>ஆயிரவைசியர் உட்ப்பிரிவு (Sect)</Text>
                        <View style={styles.mt12}>
                            <DropDownPicker
                                items={this.state.sect}
                                defaultValue={this.state.defaultSect}
                                containerStyle={{ height: 50 }}
                                placeholder="ஆயிரவைசியர் உட்ப்பிரிவு"
                                style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                itemStyle={{ justifyContent: 'flex-start' }}
                                placeholderStyle={{ color: defaultTheme.colors.gray }}
                                selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                dropDownStyle={{ backgroundColor: '#fafafa' }}
                                onChangeItem={item => this.setState({ sectValue: item.label,defaultSect:item.value})}
                            />
                        </View>

                        <Text style={styles.lable}>ஜாதக விவரம் (Horoscope Description) </Text>
                        <View style={styles.district}>
                            <DropDownPicker
                                dropDownMaxHeight={100}
                                items={this.state.horoscopeDescription}
                                defaultValue={this.state.defaulthoroscopeDescription}
                                containerStyle={{ height: 50 }}
                                placeholder="ஜாதக விவரம்"
                                style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                itemStyle={{ justifyContent: 'flex-start' }}
                                max={3}
                                placeholderStyle={{ color: defaultTheme.colors.gray }}
                                selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                dropDownStyle={{ backgroundColor: '#fafafa' }}
                                onChangeItem={item => this.setState({ horoscopeDescriptionValue: item.value,defaulthoroscopeDescription:item.value})}
                            />

                        </View>
                        <Text style={styles.lable}>இதர விவரங்கள் (Other Details) </Text>
                        <View style={styles.taluk}>
                            <DropDownPicker
                                dropDownMaxHeight={100}
                                items={this.state.otherDetails}
                                defaultValue={this.state.defaultotherDetails}
                                containerStyle={{ height: 50 }}
                                placeholder="இதர விவரங்கள்"
                                style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                itemStyle={{ justifyContent: 'flex-start' }}
                                max={3}
                                placeholderStyle={{ color: defaultTheme.colors.gray }}
                                selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                dropDownStyle={{ backgroundColor: '#fafafa' }}
                                onChangeItem={item => this.setState({ otherDetailsValue: item.value,defaultotherDetails:item.value})}
                            />
                        </View>
                        <Text style={styles.errMsg}>{this.state.genderErr}</Text>
                    </View>

                    <View style={styles.popupbtn}>
                        <TouchableOpacity style={styles.popbtn}>
                            <Text style={styles.popUpCancel} onPress={() => this.gotoFilterClear()}>நீக்கு</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.popbtn} onPress={() => this.gotoMatrimonyFilter()}>
                            <Text style={styles.popUpbtnText}>தேடல்</Text>
                        </TouchableOpacity>
                    </View>
                </View>


            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    btncontainer: {
        flex: 1,
        padding: 20
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 10,
        marginBottom: 15
    },
    placeContainer: {
        // backgroundColor: defaultTheme.colors.primary,
        // minHeight: 460,
        // zIndex: 10
    },
    head: {
        flexDirection: 'row',
        height: 32,
        paddingLeft: 5
    },
    headBorder: {
        borderBottomColor: defaultTheme.colors.liteBorder,
        borderBottomWidth: 1,
    },
    iconContainer: {
        paddingTop: 10,
        width: 40
    },
    mt12: {
        margin: 10,
    },
    district: {
        margin: 10,
    },
    taluk: {
        margin: 10,
        // paddingBottom:15
    },
    card: {
        borderWidth: 0.5,
        borderColor: defaultTheme.colors.lighterGray,
        borderRadius: 4,
        flexDirection: 'row',
        paddingVertical: 5,
        paddingHorizontal: 10,
        marginBottom: 20
    },
    userPic: {
        width: 70,
        height: 70,
    },
    profile: {
        width: '100%',
        height: '100%'
    },
    mainContainer: {
        position: 'relative',
        zIndex: 0,
        padding: 10,
        marginTop: 20,
        marginBottom: 365
    },
    content: {
        // paddingLeft: 5,
    },
    bottomText: {
        paddingLeft: 20
    },
    name: {
        marginTop: 15,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontWeight: 'bold'
    },
    detailsHead: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        paddingTop: 10,
        fontSize: 16,
        fontWeight: 'bold'
    },
    details: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        paddingTop: 4
    },
    salaryHead: {
        flexDirection: 'row',
    },
    detailsHeadSalary: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 16,
        fontWeight: 'bold'
    },
    bloodGrp: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.white,
        width: 60,
        borderRadius: 30,
        paddingTop: 7,
        justifyContent: 'center',
        textAlign: 'center',
        backgroundColor: defaultTheme.colors.primary,
    },
    donorTitle: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.white,
        paddingLeft: 10,
        paddingTop: 20,
        textAlign: 'center',
        fontSize: 16
    },
    lable: {
        fontFamily: 'MeeraInimai-Regular',
        // color: defaultTheme.colors.white,
        fontSize: 15,
        top: 8,
        paddingLeft: 12,
        position: 'relative'
    },
    mandatory: {
        color: defaultTheme.colors.red,
    },
    noDataFound: {
        marginTop: 30,
        textAlign: 'center'
    },

    popupbtn: {
        // backgroundColor: defaultTheme.colors.white,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 15
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    errMsg: {
        textAlign: 'center',
        color: defaultTheme.colors.red,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 12,
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    }
});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(MatrimonyFilter);
