/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    FlatList,
    Image,
    ScrollView,
} from "react-native";
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from '../../actions/loginAction';
/* Project Import will lives here */
import { Header, TextBox, Button } from "../../components";
import defaultTheme from "../../config/theme/default";
import { SvgImages } from '../../assets/svgImges/svgImges';

class Menu extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false
        }
    }

    render() {
        return (
            <React.Fragment>
                <Header title="முகப்பு" navigation={this.props.navigation} />
                <ScrollView>
                    <View style={styles.container}>
                        <View style={styles.container}>
                            <View style={styles.row}>
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("FamilyMembers")}>
                                    {SvgImages.family(60, 60)}
                                    <Text style={styles.menuTitle}>குடும்பத்தினர்</Text>
                                </TouchableOpacity>

                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("Profile")}>
                                    {SvgImages.friends(60, 60)}
                                    <Text style={styles.menuTitle}>சுயவிவரம்</Text>
                                </TouchableOpacity>
                            </View>
                            <View style={styles.row}>
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("Friends")}>
                                    {SvgImages.friendsMenu(60, 60)}
                                    <Text style={styles.menuTitle}>நண்பர்</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("MatrimonyMenu")}>
                                    {SvgImages.martimony(60, 60)}
                                    <Text style={styles.menuTitle}>திருமணம்</Text>
                                </TouchableOpacity>
                            </View>

                            <View style={styles.row}>
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("Festival")}>
                                    {SvgImages.festivel(60, 60)}
                                    <Text style={styles.menuTitle}>திருவிழாக்கள்</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("Calendar")}>
                                    {SvgImages.calender(60, 60)}
                                    <Text style={styles.menuTitle}>நாட்காட்டி</Text>
                                </TouchableOpacity>
                            </View>
                            <View style={styles.row}>
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("AnnouncementMenu")}>
                                    {SvgImages.announcement(60, 60)}
                                    <Text style={styles.menuTitle}>அறிவிப்புகள்</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("BloodDonor")}>
                                    {SvgImages.bloodDonor(60, 60)}
                                    <Text style={styles.menuTitle}>இரத்த தானம்</Text>
                                </TouchableOpacity>
                            </View>
                            <View style={styles.row}>
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("EmploymentMenu")}>
                                    {SvgImages.employement(60, 60)}
                                    <Text style={styles.menuTitle}>வேலைவாய்ப்பு</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("BusinessMenu")}>
                                    {SvgImages.business(60, 60)}
                                    <Text style={styles.menuTitle}>வணிகம்</Text>
                                </TouchableOpacity>
                            </View>

                            <View style={styles.row}>
                                {(this.props.user.data.USERTYPE === 2) ?
                                    <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("MembersApprove")}>
                                        {SvgImages.admin(60, 60)}
                                        <Text style={styles.menuTitle}>கணினி நிர்வாகி</Text>
                                    </TouchableOpacity> : this.props.user.data.USERTYPE === 3 ?
                                        <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("MembersApprove")}>
                                            {SvgImages.admin(60, 60)}
                                            <Text style={styles.menuTitle}> மாவட்ட நிர்வாகி </Text>
                                        </TouchableOpacity> : null}
                                <TouchableOpacity style={styles.memuBorder} onPress={() => this.props.navigation.navigate("Payment")}>

                                    {SvgImages.money(60, 60)}
                                    <Text style={styles.menuTitle}>கட்டணம்</Text>
                                </TouchableOpacity>
                            </View>
                            {/* <View style={styles.row}>
                     
                       {(this.props.user.data.USERTYPE === 2 ) ?
                         <TouchableOpacity style={styles.memuBorder} onPress={()=>this.props.navigation.navigate("MembersApprove")}>
                              {SvgImages.admin(60, 60)}
                              <Text style={styles.menuTitle}>கணினி நிர்வாகி</Text>
                         </TouchableOpacity>: this.props.user.data.USERTYPE === 3 ?
                          <TouchableOpacity style={styles.memuBorder} onPress={()=>this.props.navigation.navigate("MembersApprove")}>
                          {SvgImages.admin(60, 60)}
                          <Text style={styles.menuTitle}> மாவட்ட நிர்வாகி </Text>
                     </TouchableOpacity> : null}
                    </View>	 */}
                        </View>
                    </View>
                </ScrollView>
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 10
    },
    menuTitle: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 13,
        textAlign: 'center',
        paddingTop: 5,
        color: defaultTheme.colors.gray
    },
    memuBorder: {
        width: 130,
        borderWidth: 0.5,
        paddingVertical: 10,
        paddingHorizontal: 15,
        justifyContent: 'center',
        alignItems: 'center'
    }
});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(
        Object.assign(
            {},
            actions,
        ), dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Menu);
