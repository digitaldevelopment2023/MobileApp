/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,
	TouchableOpacity,
	Linking,
	Animated,
	ImageBackground,
	Image,
	ActivityIndicator
} from "react-native";
import Toast from 'react-native-simple-toast';
import AsyncStorage from '@react-native-community/async-storage';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from '../../actions/loginAction';
/* Project Import will lives here */
import { Header, TextBox, Button } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import axios from 'axios';
import FUI from '../../assets/fui/fui';

class Login extends Component {
	constructor(props) {
		super(props);
		this.state = {
			mobileNo: '',
			isLoading: false
		}
	}

	async componentDidMount() {
		var mobileNo = await AsyncStorage.getItem("mobileNo");
		if (mobileNo !== null) {
			this.setState({
				mobileNo: mobileNo,
			}, function () { this.handleSubmit() });
		}
	}

	handleSubmit = () => {
		if (this.validation()) {
			this.setState({ isLoading: true });
			apiService(`/unsecure/mobile/login`, 'post', { phone: this.state.mobileNo }, false, '',
				(result) => {
					if (result.data.SUCCESS === true) {
						this.setStorage(this.state.mobileNo);
						this.setLocalStorage(JSON.stringify(result.data));
						this.setState({
							mobileNo: '',
							isLoading: false
						}, function () {
							this.props.login(result.data);
						});
						if (result.data.DATA.isUserRegister == "Y") {
							this.props.navigation.navigate("Menu");
						}
						else {
							this.props.navigation.navigate("Register");
						}
						Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
					}
					else {
						this.props.navigation.navigate("Acknowledgement");
						this.setState({ isLoading: false })
					}
				},
				(error) => {
					this.props.navigation.navigate("ErrorPage",{ error: 'NetworkError' });
					this.setState({ isLoading: false });
				});
		}
	}

	async setStorage(mobileNo) {
		await AsyncStorage.setItem("mobileNo", mobileNo);
	}
	async setLocalStorage(loginData){
		await AsyncStorage.setItem("loginData", loginData);
	}

	validation = () => {
		var mobileNoReg = /^[1-9][0-9]{9}$/;
		const { mobileNo, password } = this.state;
		var valid = true
		this.setState({ error: this.state.mobileNo != "" ? "" : this.state.error });
		// if(mobileNo == "" && password ==""){
		// 	this.setState({error: "Please enter registered mobile number and passord"})
		// 	valid = false;	
		// }
		if (mobileNoReg.test(mobileNo) === false) {
			this.setState({ error: "Please enter registered Mobile number" })
			valid = false;
		}
		// else if(password == ""){
		// 	this.setState({error: "Please enter your Password"})
		// 	valid = false;
		// }
		return valid;
	}

	checkValidation = (param, type) => {
		var valid = true;
		var mobileNoReg = /^[1-9][0-9]{9}$/;
		this.setState({ error: this.state.mobileNo != "" ? "" : this.state.error });
		switch (type) {
			case "MOBILENUMBER":
				if (mobileNoReg.test(param) === false) {
					this.setState({ error: "Please enter your mobile Number" })
					valid = false;
				}
				break;

			default:
			// Alert.alert("err");

		}
	}

	render() {
		return (
			<React.Fragment>
				<Header title="Login" navigation={this.props.navigation} />
				<View style={styles.overlay}>
					<View style={styles.container}>
						<View style={styles.logoContainer}>
							<Image
								style={styles.logo}
								source={require("../../assets/images/logo.png")}
							/>
						</View>
						<View style={styles.textContainer}>
							<Text style={styles.lable}>கைபேசி எண் (Mobile Number)</Text>
							<TextBox
								style={styles.textBox}
								placeholder="கைபேசி எண்"
								borderWidth={1}
								placeholderTextColor={defaultTheme.colors.white}
								value={this.state.mobileNo}
								keyboardType={"number"}
								onChange={mobileNo => { this.setState({ mobileNo: mobileNo }, this.checkValidation(mobileNo, "MOBILENUMBER")) }}
							/>
						</View>
						<Text style={styles.errMsg}>{this.state.error}</Text>
						{/* <View>
							<Text style={styles.lable}>கடவுச்சொல் (Password)</Text>
							<TextBox
								style={styles.textBox}
								placeholder="கடவுச்சொல்"							      
								borderWidth={1}
								isPassword={true}
								placeholderTextColor={ defaultTheme.colors.white}
								value= {this.state.password}
								onChange={password =>{this.setState({password:password})}}								
							/>
						</View> */}
						<Button
							style={styles.button}
							btnName="உள்நுழைய"
							color={defaultTheme.colors.lighterGray}
							size={16}
							onPress={() => this.handleSubmit()}
						/>
					</View>
				</View>
			</React.Fragment>
		)
	}
}
const styles = StyleSheet.create({
	overlay: {
		backgroundColor: defaultTheme.colors.primary,
		top: 0,
		bottom: 0,
		left: 0,
		right: 0,
		position: 'absolute'
	},
	container: {
		flex: 1,
		padding: 10
	},
	row: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		paddingHorizontal: 5
	},
	textBox: {
		borderBottomWidth: 1.5,
		marginVertical: 10,
		fontFamily: 'MeeraInimai-Regular',
		borderColor: defaultTheme.colors.white
	},
	lable: {
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.white,
		fontSize: 15,
		top: 8,
		position: 'relative'
	},
	text: {
		color: defaultTheme.colors.white
	},
	logoContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		marginTop: 100
	},
	textContainer: {
		marginTop: 30
	},
	logo: {
		height: 200,
		width: 200
	},
	button: {
		backgroundColor: defaultTheme.colors.white,
		color: defaultTheme.colors.gray,
		width: '100%',
		fontFamily: 'MeeraInimai-Regular',
	},
	center: {
		textAlign: 'center',
		justifyContent: 'center',
		fontSize: 13,
		marginTop: 6,
		color: defaultTheme.colors.white,
		fontFamily: 'MeeraInimai-Regular',
	},
	errMsg: {
		color: defaultTheme.colors.red,
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 10,
		height: 15,
	}
});

function mapStateToProps(state) {
	return {
		user: state.loginReducer.user,
	};
}

function mapDispatchToProps(dispatch) {
	return bindActionCreators(
		Object.assign(
			{},
			actions,
		), dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Login)
