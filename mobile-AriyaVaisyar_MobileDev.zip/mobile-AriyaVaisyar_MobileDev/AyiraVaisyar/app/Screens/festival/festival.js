/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,	
	TouchableOpacity,
	FlatList,
	Image,
	ActivityIndicator
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
import moment from 'moment';
/* Project Import will lives here */
import {Header, TextBox, Button, Loader} from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';

class Festival extends Component {
	constructor(props) {
		super(props);
		this.state = {
			country:[],
			festival:[],
			pageNo: 1,
			pageSize:50,
			totalPageSize: 0,
			totalPage: 0,	
			isLoading: false
		}
	}

	componentDidMount(){
		this.FormList();
	}

	FormList() {
		this.setState({ isLoading: true});
		FormList((FormList)=>{
			this.setState({	
				country: FormList.data.country,
				isLoading: false,
			 });
			 
			if(FormList.data.country !=  ""){
				FormList.data.country.map(val => {
					var CountryID ;
					if((val.label === "India") || (val.label === "இந்தியா") || (val.label === "india") || (val.label === "INDIA")){
						CountryID = val.value;
						this.setState({defaultCountry: val.value, countryId:  val.value,isLoading: false})

						apiService(`/api/festivalList/countryId/${CountryID}/${this.state.pageNo}/${this.state.pageSize}`, 'get', '','',this.props.user.data.JWT,	
						(result) => {
							if(result.status === 200 ){
								this.setState({festival: result.data.totalFestival,
								totalPageSize:  result.data.totalCount,
								totalPage:  result.data.totalPages,
								isLoading: false});
							}
							else {  
								this.setState({isLoading: false}); 				
							}
						},
						(error) => {
							// this.setState({isLoading: false});
						});
					}
				})

			}		 
		 });
	 }
	

	country =(id)=>{
		apiService(`/api/festivalList/countryId/${id}/${this.state.pageNo}/${this.state.pageSize}`, 'get', '','',this.props.user.data.JWT,
		(result) => { 
			if(result.status === 200 ){
				this.setState({festival: result.data.totalFestival,
				totalPageSize:  result.data.totalCount,
				totalPage:  result.data.totalPages,
				isLoading: false});
			}
			else {  
				this.setState({isLoading: false}); 				
			}
		},
		(error) => {
			this.setState({isLoading: false});
		});
	}

	render() {
		return (			
			<React.Fragment>
				<Header title="திருவிழாக்கள்" navigation={this.props.navigation}/>
				{this.state.isLoading == true? 
				<Loader/>:
				<View style={styles.container}>	
					<View style={styles.countryContainer}>
						<Text style={styles.lable}>நாடு (Country)</Text>
						<View style={styles.mt12}/>
							<DropDownPicker
									// searchable={true}
									// searchablePlaceholder="Search for an item"
									items={this.state.country}
									defaultValue={this.state.defaultCountry}
									dropDownMaxHeight={80}
									containerStyle={{height: 50}}
									placeholder="நாடு"
									style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
									itemStyle={{ justifyContent: 'flex-start'}}
									placeholderStyle={{color: defaultTheme.colors.gray}}
									selectedLabelStyle={{color: defaultTheme.colors.gray}}
									dropDownStyle={{backgroundColor: '#fafafa'}}
									onChangeItem={item =>this.country(item.value)}
								/>
						</View>
						<View style={styles.p10}>
						<FlatList
						data={this.state.festival}
						extraData={this.state}
						onEndReachedThreshold={0}
						keyExtractor={(item) => item.id.toString()}
						onEndReached={this.pagination}
						renderItem={({item}) =>	
							<View style={styles.mainContainer}>
								<View style={styles.imgContainer}>
									<Image style={styles.img} source={{uri: `${ApiUrls.apiEnvironment}`+ item.festivalImage}} />
								</View>
								<Text style={styles.festivel}>{item.festivalName}</Text>
								<View style={styles.details}>
									<Text>{moment(item.date).format("dddd, DD MMMM")}</Text>
									<Text>{item.tamilMonth} {item.tamilDate}</Text>
								</View>
							</View>
						}/>
						</View>
					</View>
	         }
			</React.Fragment>
		)}
	}
	const styles = StyleSheet.create({	
		container:{
			flex: 1,
        },
        row:{
            flexDirection: 'row',
		},
		lable:{
			paddingHorizontal:10,
			color: defaultTheme.colors.white
		},
		mt12:{
			padding: 10
		},
		countryContainer:{
			backgroundColor: defaultTheme.colors.primary,
			paddingBottom: 60,
			paddingHorizontal: 10,
			height: 180,
		},
		p10:{
			padding: 10,
			marginBottom: 180
		},
		imgContainer:{
			width:'100%',
			height:400 
		},
		img:{
			width:'100%',
			height:400
		},
		mainContainer:{
			borderWidth: 0.5,
			borderColor:  defaultTheme.colors.gray,
			marginBottom: 20
		},
		festivel:{
			paddingHorizontal: 10,
			fontWeight:'bold',
			paddingTop: 10
		},
		details:{
			flexDirection: 'row',
			justifyContent:'space-between',
			paddingHorizontal: 10,
			paddingBottom:  15,
			paddingTop: 6
		}
	});

	function mapStateToProps(state) {
		return {
			user: state.loginReducer.user,
		};
	}	
export default connect(mapStateToProps)(Festival);
