/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image,
    ScrollView,
    TextInput,
    FlatList,
    Share
} from "react-native";
import { connect } from 'react-redux';
import ImageModal from 'react-native-image-modal';
import moment from 'moment';
import {
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger,
} from 'react-native-popup-menu';
import Toast from 'react-native-simple-toast';
import Modal from 'react-native-modal';
import Icon from 'react-native-vector-icons/MaterialIcons';
import ImagePicker from 'react-native-image-picker';
import { ApiUrls } from '../../api/apiUrls';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { SvgImages } from '../../assets/svgImges/svgImges';

class Friends extends Component {
    constructor(props) {
        super(props);
        this.state = {
            description: ''

        }
    }

    onShare = async () => {
        try {
            const result = await Share.share({
                message: "https://play.google.com/store/apps/details?id=com.ayiravaisiyarnew&showAllReviews=true",
            });
            if (result.action === Share.sharedAction) {
                if (result.activityType) {
                    // shared with activity type of result.activityType
                } else {
                    // shared
                }
            } else if (result.action === Share.dismissedAction) {
                // dismissed
            }
        } catch (error) {
            alert(error.message);
        }
    };






    render() {
        return (
            <React.Fragment>
                <Header title="நண்பர்களை இணைக்கவும்" navigation={this.props.navigation} />
                <View style={styles.container}>
                    <View style={styles.row}>
                        <View style={styles.memuBorder}>
                            {SvgImages.andriodImage(200, 100)}
                        </View>
                        <TouchableOpacity style={styles.shareBtn} onPress={this.onShare}>
                            <Text style={[styles.shareText]}>Share</Text>
                        </TouchableOpacity>
                    </View>
                    {/* <View style={styles.row}>
                        <View style={[styles.memuBorder, styles.iosImage]}>
                            {SvgImages.iosImage(200, 100)}
                        </View>
                        <TouchableOpacity style={styles.shareBtn} onPress={this.onShare}>
                            <Text style={[styles.shareText]}>Share</Text>
                        </TouchableOpacity>
                    </View> */}
                </View>
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        margin: 10
    },
    iosImage: {

    },
    shareBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },

    shareText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        paddingTop: 10,
        paddingHorizontal: 25,
        paddingVertical:8,
        borderRadius: 4,
        marginHorizontal: 15,
        fontFamily: 'MeeraInimai-Regular',
    }


});

export default (Friends);
