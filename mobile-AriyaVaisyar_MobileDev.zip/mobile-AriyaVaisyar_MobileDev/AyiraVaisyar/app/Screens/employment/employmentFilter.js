/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    FlatList,
    Image,
    ActivityIndicator
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
import { ScrollView } from "react-native-gesture-handler";
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';

class EmploymentFilter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            defaultCountry: '',
            defaultState: '',
            country: [],
            stateList: [],
            districtList: [],
            talukList: [],
            bloodDonorList: [],
            pageNo: 1,
            pageSize: 50,
            totalPageSize: 0,
            totalPage: 0,
            isLoading: false,
            districtId: '',
            talukId: '',
            selectedIndex: 0,
            isSuperAdminDelete: props.route.params.isSuperAdminDelete,
        }
    }

    componentDidMount() {
        this.FormList();
    }

    FormList() {
        this.setState({ isLoading: true });
        FormList((FormList) => {
            this.setState({
                education: FormList.data.education,
                occupation: FormList.data.occupation,
                country: FormList.data.country,
                bloodGroup: FormList.data.bloodGroup,
                sect: FormList.data.sect,
                isLoading: false
            });

            if (FormList.data.country != "") {
                FormList.data.country.map(val => {
                    var CountryID;
                    if ((val.label === "India") || (val.label === "இந்தியா") || (val.label === "india") || (val.label === "INDIA")) {
                        // console.error(val.value)
                        CountryID = val.value;
                        this.setState({ defaultCountry: val.value, countryId: val.value })
                        apiService(`/unsecure/mobile/statelist/${CountryID}`, 'get', '', false, '',
                            (result) => {
                                if (result.status === 200) {
                                    this.setState({ stateList: result.data, });
                                    if (result.data != "") {
                                        result.data.map(val => {
                                            // var stateID ;
                                            if ((val.label === "தமிழ்நாடு") || (val.label === "Tamilnadu") || (val.label === "Tamil Nadu") || (val.label === "TAMILNADU") || (val.label === "TAMIL NADU")) {
                                                this.setState({ defaultState: val.value, stateId: val.value, stateList: result.data, isLoading: false, })
                                                stateID = val.value;
                                                // DISTRICT API
                                                apiService(`/unsecure/mobile/districtlist/${stateID}`, 'get', '', false, '',
                                                    (response) => {
                                                        if (response.status === 200) {
                                                            this.setState({ districtList: response.data, });
                                                        }
                                                    },
                                                    (error) => {
                                                        // this.setState({isLoading: false});
                                                    });
                                            }
                                        })
                                    }
                                }
                            },
                            (error) => {
                                // this.setState({isLoading: false});
                            });
                    }
                })

            }
        });
    }

    states = (id) => {
        this.setState({ countryId: id, stateLoader: true, stateList: [], defaultState: null, defaultCountry: null, stateId: '' });
        apiService(`/unsecure/mobile/statelist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    this.setState({ stateList: result.data, stateLoader: false });
                }
            },
            (error) => {
                this.setState({ stateLoader: false });
            });
    }

    district = (id) => {
        this.setState({ stateId: id });
        apiService(`/unsecure/mobile/districtlist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    this.setState({ districtList: result.data });
                }
            },
            (error) => {
                // this.setState({isLoading: false});
            });
    }

    taluk = (id, name) => {
        this.setState({ districtId: id, district: name, taluk: null, isDistrictLoading: true, defaultTaluk: null, errMessage: '' });
        apiService(`/unsecure/mobile/taluklist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    this.setState({ talukList: result.data });
                }
            },
            (error) => {
                this.setState({ isLoading: false });
            });
    }


    pagination = () => {
        if (this.state.totalPage > this.state.pageNo) {
            this.setState({
                pageNo: this.state.pageNo + 1
            }, () => this.taluk())
        }
    }

    gotoEmploymentList = (num) => {
        if (num == 1) {
            if (this.validation()) {
                if(this.state.isSuperAdminDelete == true){
                    this.props.navigation.navigate("EmploymentList", { taluk: this.state.taluk, district: this.state.district ,isSuperAdminDelete:true})
                }else{
                    this.props.navigation.navigate("EmploymentList", { taluk: this.state.taluk, district: this.state.district ,isSuperAdminDelete:false})
                }
            }
        } else {
            this.props.navigation.navigate("EmploymentList", { taluk: this.state.taluk, district: null })
        }

    }
    searchPage = (num) => {
        if (num == 0) {
            this.setState({ selectedIndex: 1 })

        } else {
            this.setState({ selectedIndex: 0 })

        }
    }

    validation = () => {
        const { districtId, talukId, isChecked } = this.state;
        var valid = true
        this.setState({ errMessage: this.state.districtId != "" ? "" : this.state.errMessage, errMessage: this.state.talukId != "" ? "" : this.state.errMessage });
        if (districtId == "") {
            this.setState({ errMessage: "Please select your district" })
            valid = false;
        }
        // else if(talukId ==""){
        //     this.setState({errMessage: "Please select your taluk"})
        //     valid = false;
        // }
        return valid;
    }

    render() {
        return (
            <React.Fragment>
                <Header title="வேலைவாய்ப்பு" navigation={this.props.navigation} />
                    <View style={styles.container}>
                        <View style={styles.placeContainer}>
                            <Text style={styles.lable}>நாடு (Country) <Text style={styles.mandatory}>*</Text></Text>
                            <View style={styles.mt12}>
                                <DropDownPicker
                                    items={this.state.country}
                                    defaultValue={this.state.defaultCountry}
                                    containerStyle={{ height: 50 }}
                                    placeholder="நாடு"
                                    style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                    itemStyle={{ justifyContent: 'flex-start' }}
                                    placeholderStyle={{ color: defaultTheme.colors.gray }}
                                    selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                    dropDownStyle={{ backgroundColor: '#fafafa' }}
                                    onChangeItem={item => this.states(item.value)}
                                />
                            </View>

                            <Text style={styles.lable}>மாநிலம் (State) <Text style={styles.mandatory}>*</Text> </Text>
                            <View style={styles.mt12}>
                                <DropDownPicker
                                    items={this.state.stateList}
                                    defaultValue={this.state.defaultState}
                                    containerStyle={{ height: 50 }}
                                    placeholder="மாநிலம்"
                                    style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                    itemStyle={{ justifyContent: 'flex-start' }}
                                    placeholderStyle={{ color: defaultTheme.colors.gray }}
                                    selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                    dropDownStyle={{ backgroundColor: '#fafafa' }}
                                    onChangeItem={item => this.district(item.value)}
                                />
                            </View>

                            <Text style={styles.lable}>மாவட்டம் (District) <Text style={styles.mandatory}>*</Text> </Text>
                            <View style={styles.district}>
                                <DropDownPicker
                                    dropDownMaxHeight={100}
                                    items={this.state.districtList}
                                    containerStyle={{ height: 50 }}
                                    placeholder="மாவட்டம்"
                                    style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                    itemStyle={{ justifyContent: 'flex-start' }}
                                    max={3}
                                    placeholderStyle={{ color: defaultTheme.colors.gray }}
                                    selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                    dropDownStyle={{ backgroundColor: '#fafafa' }}
                                    onChangeItem={item => this.taluk(item.value, item.label)}
                                />

                            </View>
                            <Text style={styles.lable}>தாலுகா (Taluk) </Text>
                            <View style={styles.taluk}>
                                <DropDownPicker
                                    dropDownMaxHeight={100}
                                    items={this.state.talukList}
                                    defaultValue={this.state.defaultTaluk}
                                    containerStyle={{ height: 50 }}
                                    placeholder="தாலுகா"
                                    style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                    itemStyle={{ justifyContent: 'flex-start' }}
                                    max={3}
                                    placeholderStyle={{ color: defaultTheme.colors.gray }}
                                    selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                    dropDownStyle={{ backgroundColor: '#fafafa' }}
                                    onChangeItem={item => this.setState({ talukId: item.value, taluk: item.label, defaultTaluk: item.value, errMessage: '' })}
                                />
                            </View>
                            <Text style={styles.errMsg}>{this.state.errMessage}</Text>
                        </View>

                        <View style={styles.popupbtn}>
                            <TouchableOpacity style={styles.popbtn}>
                                <Text style={styles.popUpCancel} onPress={() => this.props.navigation.navigate("EmploymentMenu")}>ரத்து</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.popbtn} onPress={() => this.gotoEmploymentList(1)}>
                                <Text style={styles.popUpbtnText}>தேடல்</Text>
                            </TouchableOpacity>
                        </View>
                    </View>

                
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    btncontainer: {
        flex: 1,
        padding: 20
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 10,
        marginBottom: 15
    },
    placeContainer: {
        // backgroundColor: defaultTheme.colors.primary,
        // minHeight: 460,
        // zIndex: 10
    },
    head: {
        flexDirection: 'row',
        height: 32,
        paddingLeft: 5
    },
    headBorder: {
        borderBottomColor: defaultTheme.colors.liteBorder,
        borderBottomWidth: 1,
    },
    iconContainer: {
        paddingTop: 10,
        width: 40
    },
    mt12: {
        margin: 10,
    },
    district: {
        margin: 10,
    },
    taluk: {
        margin: 10,
        // paddingBottom:15
    },
    card: {
        borderWidth: 0.5,
        borderColor: defaultTheme.colors.lighterGray,
        borderRadius: 4,
        flexDirection: 'row',
        paddingVertical: 5,
        paddingHorizontal: 10,
        marginBottom: 20
    },
    userPic: {
        width: 70,
        height: 70,
    },
    profile: {
        width: '100%',
        height: '100%'
    },
    mainContainer: {
        position: 'relative',
        zIndex: 0,
        padding: 10,
        marginTop: 20,
        marginBottom: 365
    },
    content: {
        // paddingLeft: 5,
    },
    bottomText: {
        paddingLeft: 20
    },
    name: {
        marginTop: 15,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontWeight: 'bold'
    },
    detailsHead: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        paddingTop: 10,
        fontSize: 16,
        fontWeight: 'bold'
    },
    details: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        paddingTop: 4
    },
    salaryHead: {
        flexDirection: 'row',
    },
    detailsHeadSalary: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 16,
        fontWeight: 'bold'
    },
    bloodGrp: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.white,
        width: 60,
        borderRadius: 30,
        paddingTop: 7,
        justifyContent: 'center',
        textAlign: 'center',
        backgroundColor: defaultTheme.colors.primary,
    },
    donorTitle: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.white,
        paddingLeft: 10,
        paddingTop: 20,
        textAlign: 'center',
        fontSize: 16
    },
    lable: {
        fontFamily: 'MeeraInimai-Regular',
        // color: defaultTheme.colors.white,
        fontSize: 15,
        top: 8,
        paddingLeft: 12,
        position: 'relative'
    },
    mandatory: {
        color: defaultTheme.colors.red,
    },
    noDataFound: {
        marginTop: 30,
        textAlign: 'center'
    },

    popupbtn: {
        // backgroundColor: defaultTheme.colors.white,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 15
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    errMsg: {
        textAlign: 'center',
        color: defaultTheme.colors.red,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 12,
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    }
});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(EmploymentFilter);
