/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    FlatList,
    Image,
    ActivityIndicator,
    TextInput,
    ScrollView,
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import Toast from 'react-native-simple-toast';

class EmploymentAdd extends Component {
    constructor(props) {
        super(props);
        this.state = {
            defaultCountry: '',
            defaultState: '',
            country: [],
            stateList: [],
            districtList: [],
            talukList: [],
            bloodDonorList: [],
            occupation: [],
            pageNo: 1,
            pageSize: 50,
            totalPageSize: 0,
            totalPage: 0,
            isLoading: true,
            districtId: '',
            occupationID: '',
            talukId: '',
            description: '',
            qualification: '',
            salary: '',
            contact: '',
            countryName: '',
            stateName: ''
        }
    }

    componentDidMount() {
        this.FormList();
    }

    FormList() {
        FormList((FormList) => {
            this.setState({
                occupation: FormList.data.occupation,
                country: FormList.data.country,
            });

            if (FormList.data.country != "") {
                FormList.data.country.map(val => {
                    var CountryID;
                    if ((val.label === "India") || (val.label === "இந்தியா") || (val.label === "india") || (val.label === "INDIA")) {
                        // console.error(val.value)
                        CountryID = val.value;
                        this.setState({ defaultCountry: val.value, countryId: val.value, countryName: val.label })
                        apiService(`/unsecure/mobile/statelist/${CountryID}`, 'get', '', false, '',
                            (result) => {
                                if (result.status === 200) {
                                    this.setState({ stateList: result.data, });
                                    if (result.data != "") {
                                        result.data.map(val => {
                                            // var stateID ;
                                            if ((val.label === "தமிழ்நாடு") || (val.label === "Tamilnadu") || (val.label === "Tamil Nadu") || (val.label === "TAMILNADU") || (val.label === "TAMIL NADU")) {
                                                this.setState({ defaultState: val.value, stateId: val.value, stateList: result.data, stateName: val.label })
                                                stateID = val.value;
                                                // DISTRICT API
                                                apiService(`/unsecure/mobile/districtlist/${stateID}`, 'get', '', false, '',
                                                    (response) => {
                                                        if (response.status === 200) {
                                                            this.setState({ districtList: response.data, isLoading: false });
                                                        }
                                                    },
                                                    (error) => {
                                                    });
                                            }
                                        })
                                    }
                                }
                            },
                            (error) => {
                            });
                    }
                })

            }
        });
    }

    states = (id, name) => {
        this.setState({
            countryId: id, countryName: name, stateLoader: true, stateList: [], defaultState: null, stateId: '',
            defaultTaluk: null, defaultDistrict: null, districtId: '', talukId: '', districtList: [], talukList: [],
        });
        apiService(`/unsecure/mobile/statelist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    this.setState({ stateList: result.data, stateLoader: false });
                }
            },
            (error) => {
                this.setState({ stateLoader: false });
            });
    }

    district = (id, name) => {
        this.setState({ stateId: id, stateName: name, errMessage: '', defaultTaluk: null, defaultDistrict: null, districtId: '', talukId: '', districtList: [], talukList: [] });
        apiService(`/unsecure/mobile/districtlist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    this.setState({ districtList: result.data });
                }
            },
            (error) => {
            });
    }

    taluk = (id, name) => {
        this.setState({ districtId: id, district: name, isDistrictLoading: true, defaultTaluk: null, errMessage: '' });
        apiService(`/unsecure/mobile/taluklist/${id}`, 'get', '', false, '',
            (result) => {
                if (result.status === 200) {
                    this.setState({ talukList: result.data });
                }
            },
            (error) => {
            });
    }

    occupation = (id) => {
        // this.checkValidation(id,"OCCUPATION")
        this.setState({ occupationID: id, errMessage: '' });
    }
    checkValidation = (param, type) => {
        var valid = true;
        this.setState({
            errMessage: this.state.districtId != "" ? "" : this.state.errMessage, errMessage: this.state.talukId != "" ? "" : this.state.errMessage,
            errMessage: this.state.occupationID != "" ? "" : this.state.errMessage,
            errMessage: this.state.contact != "" ? "" : this.state.errMessage,
            errMessage: this.state.salary != "" ? "" : this.state.errMessage,
            errMessage: this.state.qualification != "" ? "" : this.state.errMessage,
            errMessage: this.state.description != "" ? "" : this.state.errMessage,
        })
        switch (type) {
            case "salary":
                if (param.length < 3) {
                    this.setState({ errMessage: "Please enter salary" })
                    valid = false;
                }
                break;

            case "contact":
                if (param.length < 3) {
                    this.setState({ errMessage: "Please enter phone or email" })
                    valid = false;
                }
                break;
            case "qualification":
                if (param.length < 3) {
                    this.setState({ errMessage: "Please enter qualification" })
                    valid = false;
                }
                break;
            case "description":
                if (param.length < 3) {
                    this.setState({ errMessage: "Please enter description" })
                    valid = false;
                }
                break;

            default:
        }

    }

    submitEmployment = () => {
        if (this.validation()) {
            this.setState({ isLoading: true });
            apiService(`/api/employment`, 'post', {
                occupation: this.state.occupationID,
                salary: this.state.salary,
                country: this.state.countryName,
                state: this.state.stateName,
                district: this.state.district,
                taluk: this.state.taluk,
                contact: this.state.contact,
                qualification: this.state.qualification,
                description: this.state.description,
            }, '', this.props.user.data.JWT,
                (result) => {
                    if (result.status === 200) {
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                        this.setState({ isLoading: false });
                        this.props.navigation.navigate("EmploymentList", { taluk: null, district: null, refresh: true })
                    }
                    else {
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                    }
                },
                (error) => {
                    Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
                });

        }
    }

    validation = () => {
        const { districtId, talukId, stateId, occupationID, salary, qualification, description, contact, isChecked } = this.state;
        var valid = true
        this.setState({
            errMessage: this.state.districtId != "" ? "" : this.state.errMessage, errMessage: this.state.talukId != "" ? "" : this.state.errMessage,
            errMessage: this.state.occupationID != "" ? "" : this.state.errMessage,
            errMessage: this.state.contact != "" ? "" : this.state.errMessage,
            errMessage: this.state.salary != "" ? "" : this.state.errMessage,
            errMessage: this.state.qualification != "" ? "" : this.state.errMessage,
            errMessage: this.state.description != "" ? "" : this.state.errMessage,
            errMessage: this.state.stateId != "" ? "" : this.state.errMessage,
        });
        if (occupationID == "") {
            this.setState({ errMessage: "Please select Occupation" })
            valid = false;
        }
        else if (stateId == "") {
            this.setState({ errMessage: "Please select your state" })
            valid = false;
        }
        else if (districtId == "") {
            this.setState({ errMessage: "Please select your district" })
            valid = false;
        }
        else if (talukId == "") {
            this.setState({ errMessage: "Please select your taluk" })
            valid = false;
        }
        else if (contact == "") {
            this.setState({ errMessage: "Please enter phone or email" })
            valid = false;
        }
        else if (salary == "") {
            this.setState({ errMessage: "Please enter salary" })
            valid = false;
        }
        else if (qualification == "") {
            this.setState({ errMessage: "Please enter qualification" })
            valid = false;
        }
        else if (description == "") {
            this.setState({ errMessage: "Please enter description" })
            valid = false;
        }
        return valid;
    }


    render() {
        return (
            <React.Fragment>
                <Header title="வேலைவாய்ப்புகளை உருவாக்கவும்" navigation={this.props.navigation} />
                <ScrollView>
                    {this.state.isLoading === true ?
                        <Loader /> :
                        <View style={styles.container}>
                            <View style={styles.placeContainer}>
                                <Text style={styles.lable}>தொழில் (Occupation) <Text style={styles.mandatory}>*</Text> </Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.occupation}
                                        containerStyle={{ height: 50 }}
                                        placeholder="தொழில்"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.lighterGray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.occupation(item.label)}
                                    />
                                </View>
                                <Text style={styles.lable}>நாடு (Country) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.country}
                                        defaultValue={this.state.defaultCountry}
                                        containerStyle={{ height: 50 }}
                                        placeholder="நாடு"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.states(item.value, item.label)}
                                    />
                                </View>

                                <Text style={styles.lable}>மாநிலம் (State) <Text style={styles.mandatory}>*</Text> </Text>
                                <View style={styles.mt12}>
                                    <DropDownPicker
                                        items={this.state.stateList}
                                        defaultValue={this.state.defaultState}
                                        containerStyle={{ height: 50 }}
                                        placeholder="மாநிலம்"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.district(item.value, item.label)}
                                    />
                                </View>

                                <Text style={styles.lable}>மாவட்டம் (District) <Text style={styles.mandatory}>*</Text> </Text>
                                <View style={styles.district}>
                                    <DropDownPicker
                                        dropDownMaxHeight={100}
                                        items={this.state.districtList}
                                        defaultValue={this.state.defaultDistrict}
                                        containerStyle={{ height: 50 }}
                                        placeholder="மாவட்டம்"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        max={3}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.taluk(item.value, item.label)}
                                    />

                                </View>
                                <Text style={styles.lable}>தாலுகா (Taluk) <Text style={styles.mandatory}>*</Text> </Text>
                                <View style={styles.taluk}>
                                    <DropDownPicker
                                        dropDownMaxHeight={100}
                                        items={this.state.talukList}
                                        defaultValue={this.state.defaultTaluk}
                                        containerStyle={{ height: 50 }}
                                        placeholder="தாலுகா"
                                        style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                        itemStyle={{ justifyContent: 'flex-start' }}
                                        max={3}
                                        placeholderStyle={{ color: defaultTheme.colors.gray }}
                                        selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                        dropDownStyle={{ backgroundColor: '#fafafa' }}
                                        onChangeItem={item => this.setState({ talukId: item.value, taluk: item.label, defaultTaluk: item.value, errMessage: '' })}
                                    />
                                </View>
                                <Text style={styles.lable}>தொடர்புகொள்ள (Phone or Email) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.textContainer}>
                                    <TextBox
                                        style={styles.textBox}
                                        placeholder="தொடர்புகொள்ள (Phone or Email)"
                                        borderWidth={1}
                                        placeholderTextColor={defaultTheme.colors.lighterGray}
                                        value={this.state.contact}
                                        onChange={contact => { this.setState({ contact: contact }, this.checkValidation(contact, "contact")) }}
                                    />
                                </View>

                                <Text style={styles.lable}>மாத சம்பளம் (Salary) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.textContainer}>
                                    <TextBox
                                        style={styles.textBox}
                                        placeholder="மாத சம்பளம் (Salary)"
                                        borderWidth={1}
                                        placeholderTextColor={defaultTheme.colors.lighterGray}
                                        value={this.state.salary}
                                        onChange={salary => { this.setState({ salary: salary }, this.checkValidation(salary, "salary")) }}
                                    />
                                </View>
                                <Text style={styles.lable}>தகுதி (Qualification) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.textContainer}>
                                    <TextInput
                                        style={styles.textarea}
                                        numberOfLines={3} maxLength={250} multiline={true} onChangeText={(qualification) => this.setState({ qualification: qualification }, this.checkValidation(qualification, "qualification"))} />
                                    <Text>{250 - this.state.qualification.length}/250 Characters</Text>
                                </View>

                                <Text style={styles.lable}>தொழில் விவரம் (Description) <Text style={styles.mandatory}>*</Text></Text>
                                <View style={styles.textContainer}>
                                    <TextInput
                                        style={styles.textarea}
                                        numberOfLines={3} maxLength={250} multiline={true} onChangeText={(description) => this.setState({ description: description }, this.checkValidation(description, "description"))} />
                                    <Text>{250 - this.state.description.length}/250 Characters</Text>
                                </View>
                                <Text style={styles.errMsg}>{this.state.errMessage}</Text>
                            </View>

                            <View style={styles.popupbtn}>
                                <TouchableOpacity style={styles.popbtn}>
                                    <Text style={styles.popUpCancel} onPress={() =>   this.props.navigation.navigate("EmploymentList", { taluk: null, district: null, refresh: true })}>ரத்து</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.popbtn} onPress={() => this.submitEmployment()}>
                                    <Text style={styles.popUpbtnText}>சமர்ப்பிக்கவும்</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    }
                </ScrollView>
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        // padding: 10
    },
    textContainer: {
        margin: 10,
    },
    textBox: {
        fontFamily: 'MeeraInimai-Regular',
        borderWidth: 1,
        borderRadius: 4,
        fontSize: 15,
        top: 8,
        paddingLeft: 12,
        position: 'relative',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray

    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        // margin: 10,
        marginBottom: 15
    },
    mt12: {
        margin: 10,
    },
    district: {
        margin: 10,
    },
    taluk: {
        margin: 10,
    },

    mainContainer: {
        position: 'relative',
        zIndex: 0,
        // padding: 10,
        marginTop: 20,
        marginBottom: 365
    },
    bottomText: {
        paddingLeft: 20
    },
    name: {
        marginTop: 15,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontWeight: 'bold'
    },

    lable: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 15,
        top: 8,
        paddingLeft: 12,
        position: 'relative'
    },
    mandatory: {
        color: defaultTheme.colors.red,
    },

    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 15,
        paddingBottom: 20
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    errMsg: {
        textAlign: 'center',
        color: defaultTheme.colors.red,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 12,
    },
    textarea: {
        borderWidth: 1,
        borderRadius: 4,
        paddingBottom: 60,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray,
        textAlignVertical: 'top'
    },
});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(EmploymentAdd);
