/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,	
	TouchableOpacity,
	Animated,
	ImageBackground,
	Image,
	ActivityIndicator
} from "react-native";
import Toast from 'react-native-simple-toast';
/* Project Import will lives here */
import {Header, TextBox, Button} from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import AsyncStorage from '@react-native-community/async-storage';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from '../../actions/loginAction';

class Thirukural extends Component {
	constructor(props) {
		super(props);
		this.state = {
			kural:'',
			result:null,			
			isLoading: true
		}
	}

	async componentDidMount(){
		this.dailyThiruKural();
		var loginData =await AsyncStorage.getItem("loginData");
		var localData = JSON.parse(loginData);
		this.setState({
			result: localData});
	}

	dailyThiruKural =()=>{
		this.setState({isLoading: true}); 
		apiService(`/unsecure/thirukural`, 'get', '','','',
			(result) => { 
				if(result.status === 200 ){
					this.setState({
						kural: result.data,
						isLoading: false});
					this.goToLogin();
				}
				else {  
					this.setState({isLoading: false}); 
					this.props.navigation.navigate("Login");				
				}
			},
			(error) => {
				this.setState({isLoading: false});
				this.props.navigation.navigate("Login");
			});
	    }

	goToLogin = ()=> {
		setTimeout(this.loadProgress, 2000);
	  }

	loadProgress = () => {
		if(this.state.result != null){
		if (this.state.result.SUCCESS === true) {
			this.props.login(this.state.result);
			if (this.state.result.DATA.isUserRegister == "Y") {
				this.props.navigation.navigate("Menu");
			}
			else {
				this.props.navigation.navigate("Register");
			}
			Toast.showWithGravity(this.state.result.MESSAGE, Toast.LONG, Toast.TOP)
		}
		else {
			this.props.navigation.navigate("Acknowledgement");
			this.setState({ isLoading: false })
		}
	}else{
		this.props.navigation.navigate("Login");
	}
	}

 
	render() {
		return (			
			<React.Fragment>
					<Header title="Thirukural" navigation={this.props.navigation}/>
					<View style={styles.overlay}>
						<View style={styles.logoContainer}>
							<ImageBackground
								style={{width: 220, height: 270}}
								source={require("../../assets/images/ThiruValuvar.png")}
							/>
							<Text>{this.state.kural.kuralEn}</Text>
						</View>
						{this.state.isLoading ? <ActivityIndicator  size="large" style={styles.loader} color={defaultTheme.colors.white} /> :
						<View style={styles.container}>  
							<Text style={[styles.kural, styles.athikaram]}>{this.state.kural.athigaram} </Text>
							<Text style={styles.kural}>{this.state.kural.firstLine}</Text>
							<Text style={styles.kural}>{this.state.kural.secondLine}</Text>

							<View style={styles.title}>
								<Text style={styles.kural}>விளக்கம்  :</Text>
								<Text style={styles.description}>{this.state.kural.kuralPorul}</Text>
							</View>
						</View>}
					</View>
			</React.Fragment>
		)}
	}
	const styles = StyleSheet.create({	
		overlay: {
			backgroundColor: defaultTheme.colors.primary,
			top:0,
			bottom: 0,
			left:0,
			right:0,
			position:'absolute'
		},
		logoContainer:{
			flexDirection:'row',
			justifyContent:'center',
			marginTop: 50,
			height: 200
		},
		container:{
			marginTop: 100,
			padding: 15
		},
		kural:{
			fontFamily: 'MeeraInimai-Regular',
			fontSize: 14,
			color: defaultTheme.colors.white,
			paddingVertical: 4,
			fontWeight:'bold',
			textAlign:'center'
		},
		title:{
			marginTop: 30
		},
		description:{
			fontFamily: 'MeeraInimai-Regular',
			color: defaultTheme.colors.white,
			paddingVertical: 4,
			fontWeight:'bold',
			textAlign:'center'
		},
		athikaram:{
			marginBottom: 10
		},
		loader:{
		marginTop: 200,
		}

		
	});

	function mapStateToProps(state) {
		return {
			user: state.loginReducer.user,
		};
	}
	
	function mapDispatchToProps(dispatch) {
		return bindActionCreators(
			Object.assign(
				{},
				actions,
			), dispatch);
	}

	
export default connect(mapStateToProps, mapDispatchToProps)(Thirukural)
