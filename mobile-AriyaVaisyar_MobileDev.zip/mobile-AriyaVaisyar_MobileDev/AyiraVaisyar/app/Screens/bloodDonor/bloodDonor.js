/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,	
	TouchableOpacity,
	FlatList,
	Image,
	ActivityIndicator
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
import { ScrollView } from "react-native-gesture-handler";
/* Project Import will lives here */
import {Header, TextBox, Button, Loader} from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';

class BloodDonor extends Component {
	constructor(props) {
		super(props);
		this.state = {
			defaultCountry: '',
			defaultState:'',
			country:[],
			stateList:[],
			districtList:[],
			bloodDonorList:[],
			pageNo: 1,
			pageSize:50,
			totalPageSize: 0,
			totalPage: 0,
			isLoading: false
		}
	}

	componentDidMount(){
		this.FormList();
	}

	FormList() {
		this.setState({isLoading: true});
		FormList((FormList)=>{
			this.setState({				 
				education: FormList.data.education,
				occupation: FormList.data.occupation,
				country: FormList.data.country,
				bloodGroup: FormList.data.bloodGroup,
				sect: FormList.data.sect,
				isLoading: false
			 });
			 
			if(FormList.data.country !=  ""){
				FormList.data.country.map(val => {
					var CountryID ;
					if((val.label === "India") || (val.label === "இந்தியா") || (val.label === "india") || (val.label === "INDIA")){
						// console.error(val.value)
						CountryID = val.value;
						this.setState({defaultCountry: val.value, countryId:  val.value})
						apiService(`/unsecure/mobile/statelist/${CountryID}`, 'get', '',false, '',	
						(result) => {
							if(result.status === 200){
								this.setState({stateList: result.data,});
								if(result.data !=  ""){
									result.data.map(val => {
										// var stateID ;
										if((val.label === "தமிழ்நாடு") || (val.label === "Tamilnadu") || (val.label === "Tamil Nadu") || (val.label === "TAMILNADU") ||  (val.label === "TAMIL NADU")){
											this.setState({defaultState: val.value,stateId: val.value, stateList: result.data ,isLoading: false,})
											stateID = val.value;
											// DISTRICT API
											apiService(`/unsecure/mobile/districtlist/${stateID}`, 'get', '',false, '',	
											(response) => {
												if(response.status === 200){
													this.setState({districtList: response.data,});
												}
											},
											(error) => {
												// this.setState({isLoading: false});
											});
										}
									})
								}
							}
						},
						(error) => {
							// this.setState({isLoading: false});
						});
					}
				})

			}		 
		 });
	 }

	states =(id)=>{
		this.setState({countryId: id, stateLoader: true, stateList:[],defaultState:null, defaultCountry:null, stateId:''});
		apiService(`/unsecure/mobile/statelist/${id}`, 'get', '',false, '',	
		(result) => {
			if(result.status === 200){
				this.setState({stateList: result.data,stateLoader: false});
			}
		},
		(error) => {
			this.setState({stateLoader: false});
		});
	 }

	 district=(id)=>{
		this.setState({stateId: id});
		apiService(`/unsecure/mobile/districtlist/${id}`, 'get', '',false, '',	
			(result) => {
				if(result.status === 200){
					this.setState({districtList: result.data});
				}
			},
			(error) => {
				// this.setState({isLoading: false});
		});
	 }

	 taluk = (id)=>{
		this.setState({districtId: id, isDistrictLoading: true});
		apiService(`/unsecure/mobile/taluklist/${id}`, 'get', '',false, '',	
			(result) => {
				if(result.status === 200){
					this.setState({talukList: result.data});
					apiService(`/api/users/blooddonate/filter/${this.state.pageNo}/${this.state.pageSize}`, 'post', {
					stateId: this.state.stateId,
					districtId: id
					},'',this.props.user.data.JWT,
				(result) => {
					if(result.status === 200){
						this.setState({
							// isLoading: false,
							bloodDonorList: result.data.totalUsers,
							totalPageSize:  result.data.totalCount,
							totalPage:  result.data.totalPages,
							isDistrictLoading: false
						});
					}
				},
				(error) => {
					this.setState({isLoading: false});
		});

				}
			},
			(error) => {
				this.setState({isLoading: false});
		});
	}


	pagination = () =>{
		if(this.state.totalPage > this.state.pageNo ){
		  this.setState({
			  pageNo:this.state.pageNo + 1			
		  },()=>this.taluk())
		}
	  }

	render() {
		return (			
			<React.Fragment>
				<Header title="இரத்ததானம் செய்பவர்" navigation={this.props.navigation}/>
				{this.state.isLoading == true? 
				<Loader/>:
				<View style={styles.container}>	
					<View style={styles.placeContainer}>
						<Text style={styles.lable}>நாடு (Country) <Text  style={styles.mandatory}>*</Text></Text>
						<View  style={styles.mt12}>
							<DropDownPicker
								items={this.state.country}
								defaultValue={this.state.defaultCountry}
								containerStyle={{height: 50}}
								placeholder="நாடு"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.gray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.states(item.value)}
							/>
						</View>

						<Text style={styles.lable}>மாநிலம் (State) <Text  style={styles.mandatory}>*</Text> </Text>
						<View  style={styles.mt12}>
							<DropDownPicker
								items={this.state.stateList}
								defaultValue={this.state.defaultState}
								containerStyle={{height: 50}}
								placeholder="மாநிலம்"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								placeholderStyle={{color: defaultTheme.colors.gray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.district(item.value)}
							/>
						</View>

						<Text style={styles.lable}>மாவட்டம் (District) <Text  style={styles.mandatory}>*</Text> </Text>
						<View  style={styles.district}>
							<DropDownPicker
							    dropDownMaxHeight={100}
								items={this.state.districtList}
								containerStyle={{height: 50}}
								placeholder="மாவட்டம்"
								style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
								itemStyle={{ justifyContent: 'flex-start'}}
								max={3}
								placeholderStyle={{color: defaultTheme.colors.gray}}
								selectedLabelStyle={{color: defaultTheme.colors.gray}}
								dropDownStyle={{backgroundColor: '#fafafa'}}
								onChangeItem={item =>this.taluk(item.value)}
							/>
						</View>
						<Text style={styles.donorTitle}>Blood Donor List</Text>
					</View>	
					{this.state.isDistrictLoading || this.state.stateLoader ? <ActivityIndicator size="small" color={defaultTheme.colors.primary} />  :				
					<View style={styles.mainContainer}>
						{this.state.bloodDonorList.length != 0 ?
						<FlatList
						data={this.state.bloodDonorList}
						extraData={this.state}
						onEndReachedThreshold={0}
						keyExtractor={(item) => item.id.toString()}
						onEndReached={this.pagination}
						renderItem={({item}) =>	
							<View  style={styles.card}>
								{/* <View style={styles.userPic}>
									<Image style={styles.profile} source={{uri: `${ApiUrls.apiEnvironment}`+ item.profileImage}} />
								</View> */}
								<View style={styles.content}>
									<Text style={styles.name}>{item.name}</Text>
									<View style={styles.bottomText}>
										<Text style={styles.mobileNo}>{item.phone}</Text>
										<Text style={styles.bloodGrp}>{item.bloodGroup.bloodGroup}</Text>
									</View>
								</View>
							</View>
						}/>: <View>
							<Text style={styles.noDataFound}>No data Found</Text>
							</View>}
						</View>
					}
				</View>
	         }
			</React.Fragment>
		)}
	}
	const styles = StyleSheet.create({	
		container:{
			flex: 1,
        },
        row:{
            flexDirection: 'row',
            justifyContent:'space-between',
			margin: 10,
			marginBottom: 15
		},
		placeContainer:{
			backgroundColor: defaultTheme.colors.primary,
			minHeight: 360,
			zIndex: 10
		},
		mt12:{
			margin: 10,
		},
		district:{
			margin: 10,
			// paddingBottom: 125
		},
		card:{
			borderWidth: 0.5,
			borderColor:defaultTheme.colors.lighterGray,
			borderRadius: 4,
			flexDirection:'row',
			paddingVertical:5,
			paddingHorizontal: 10,
			marginBottom: 20
		},
		userPic:{
			width: 70,
			height: 70,
		},
		profile:{
			width: '100%',
			height: '100%'
		},
		mainContainer:{
			position: 'relative',
			zIndex: 0,
			padding: 10,
			marginTop: 20,
			marginBottom:365
		},
		content:{
			paddingLeft: 20,
		},
		name:{
			marginTop: 15,
			fontFamily: 'MeeraInimai-Regular',
			color: defaultTheme.colors.gray,
			fontWeight:'bold'
		},
		mobileNo:{
			fontFamily: 'MeeraInimai-Regular',
			color: defaultTheme.colors.gray,
			paddingTop: 10
		},
		bloodGrp:{
			fontFamily: 'MeeraInimai-Regular',
			color: defaultTheme.colors.white,
			width: 60,
			borderRadius: 30,
			paddingTop: 7,
			justifyContent:'center',
			textAlign:'center',
			backgroundColor: defaultTheme.colors.primary,
		},
		bottomText:{
			flexDirection:'row',
			width: 260,
			justifyContent:'space-between'
		},
		donorTitle:{
			fontFamily: 'MeeraInimai-Regular',
			color: defaultTheme.colors.white,
			paddingLeft: 10,
			paddingTop: 20,
			textAlign:'center',
			fontSize: 16
		},
		lable:{
			fontFamily: 'MeeraInimai-Regular',
			color: defaultTheme.colors.white,
			fontSize:15,
			top: 8,
			paddingLeft: 12,
			position:'relative'
		},
		mandatory:{
			color: defaultTheme.colors.red,	
		},
		noDataFound:{
			marginTop: 30,
			textAlign:'center'
		}
	});

	function mapStateToProps(state) {
		return {
			user: state.loginReducer.user,
		};
	}	
export default connect(mapStateToProps)(BloodDonor);
