/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image,
    ScrollView,
    TextInput,
    FlatList
} from "react-native";;
import { connect } from 'react-redux';
/* Project Import will lives here */
import defaultTheme from "../../config/theme/default";
import { SvgImages } from '../../assets/svgImges/svgImges';
import ImageModal from 'react-native-image-modal';
import moment from 'moment';

import Toast from 'react-native-simple-toast';
import Modal from 'react-native-modal';
import Icon from 'react-native-vector-icons/MaterialIcons';
import ImagePicker from 'react-native-image-picker';
import { ApiUrls } from '../../api/apiUrls';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import apiService from "../../utils/apiService";

class AnnouncementAddEdit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pageControl: props.route.params.pageControl,
            data: props.route.params.data,
            title: props.route.params.title,
            description: '',
            imagesource: '',
            announcementType: props.route.params.type,
            profilePic: '',
            isLoading: false
        }

    }

    componentDidMount() {
        this.setState({ updateImg: new Date() }, this.getCalender)
        if (this.state.pageControl == 1) {
            this.setState({
                description: '',
                imagesource: '',
                announcementType: this.state.announcementType,
                profilePic: '',
                isLoading: false
            });
        } else {
            this.setState({
                description: this.state.data.description,
                dataId: this.state.data.id,
                imagesources: this.state.data.announcementPic,
                picId: this.state.data.picId,
            });
        }
    }

    selectPhotoTapped = () => {
        const options = {
            quality: 1.0,
            maxWidth: 500,
            maxHeight: 500,
            includeBase64: true,
            storageOptions: {
                skipBackup: true,
                privateDirectory: true
            }
        };

        ImagePicker.showImagePicker(options, (response) => {
            console.log('Response = ', response);
            if (response.didCancel) {
                console.log('User cancelled photo picker');
            }
            else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            }
            else if (response.customButton) {
                console.log('User tapped custom button: ', response.customButton);
            }
            else {
                var source = {
                    uri: response.uri,
                    type: response.type,
                    name: response.fileName,
                    height: response.height,
                    width: response.width,
                    // 	Platform.OS === "android" ? response.uri : response.uri.replace("file:/", "")
                };
                this.setState({
                    profilePic: source,
                    imagesources: null,
                    imagesource: `data:${source.type};base64,` + response.data,
                });
            }
        });
    }

    getAnnouncement = () => {
        apiService(`/api/announcements/filter`, 'post', {
            userId: null,
            announcementType: this.state.announcementType,

        }, '', this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    this.setState({
                        announcement: result.data
                    })
                }
                else {
                    this.setState({ isLoading: false });
                    Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
                }
            },
            (error) => {
                this.setState({ isLoading: false });
                Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
            });
    }


    editAnnouncement = () => {
        if (this.updateValidation()) {
            var currentDate = new Date();
            let formData = new FormData();
            {
                this.state.imagesource != "" ?
                formData.append('pic', this.state.profilePic) : null
            }
            formData.append('description', this.state.description)
            formData.append('announcementType', this.state.announcementType)
            formData.append('id', this.state.dataId)
            {
                this.state.picId != null ?
                formData.append('picId', this.state.picId) : null
            }

            apiService(`/api/announcement`, 'put', formData, true, this.props.user.data.JWT,
                (result) => {
                    if (result.data.SUCCESS = true) {
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP);
                        this.routingTypeCheck(this.state.announcementType);
                    }
                },
                (error) => {
                    Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
                });
        }
    }

    postData = () => {
        if (this.validation()) {
            let formData = new FormData();
            {
                this.state.profilePic != "" ?
                    formData.append('pic', this.state.profilePic) : null
            }
            // formData.append('pic', this.state.profilePic)
            formData.append('description', this.state.description)
            formData.append('announcementType', this.state.announcementType)
            apiService(`/api/announcement`, 'post', formData, true, this.props.user.data.JWT,
                (result) => {
                    if (result.data.SUCCESS = true) {
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP);
                        this.routingTypeCheck(this.state.announcementType);
                    }
                },
                (error) => {
                    Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
                });
        }
    }

    routingTypeCheck(type) {

        switch (type) {

            case 1:
                this.props.navigation.navigate('News', { refresh: true });
                break;
            case 2:
                this.props.navigation.navigate('Wishes', { refresh: true });
                break;
            case 3:
                this.props.navigation.navigate('Announcement', { refresh: true });
                break;
            case 4:
                this.props.navigation.navigate('Obituary', { refresh: true });
                break;


        }
    }


    removePhoto = (id) => {
        this.setState({ imagesource: "", imagesources: null, profilePic: '' });
        apiService(`/api/announcementPicture/delete/${id}`, 'delete', '', false, this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    if (result.data.SUCCESS = true) {
                        Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP);
                        // this.routingTypeCheck(this.state.announcementType);
                    }
                }
            },
            (error) => {
                this.setState({ stateLoader: false });
            });
    }

    validation = () => {
        const { description, imagesource } = this.state;
        var valid = true
        this.setState({ errdec: this.state.description != "" ? "" : this.state.errdec, errImg: this.state.errImg != "" ? "" : this.state.errImg });
        if (description == "") {
            this.setState({ errdec: "Please enter description" })
            valid = false;
        }

        // if(imagesource == ""){
        //     this.setState({errImg: "Please upload Image "})
        //     valid = false;	
        // }

        return valid;
    }

    updateValidation = () => {
        const { description, imagesource } = this.state;
        var valid = true
        this.setState({ errdec: this.state.description != "" ? "" : this.state.errdec });
        if (description == "") {
            this.setState({ errdec: "Please enter description" })
            valid = false;
        }
        return valid;
    }
    	  
	removePhotoAdd =()=>{
		this.setState({ imagesource: ""});
	}
    render() {
        return (
            <React.Fragment>
                {this.state.pageControl == 1 ?
                    <Header title={this.state.title} navigation={this.props.navigation} />
                    : <Header title={this.state.title} navigation={this.props.navigation} />
                }
                <ScrollView>
                    {this.state.pageControl == 1 ?
                        <View style={styles.popup}>
                            <View style={{ padding: 10 }}>
                                <View>
                                    <Text style={styles.title}>Description <Text style={styles.mandatory}>*</Text> </Text>
                                    <TextInput
                                        style={styles.textarea}
                                        numberOfLines={3} maxLength={2000} multiline={true} onChangeText={(description) => this.setState({ description: description })} />
                                    <Text>{2000 - this.state.description.length}/2000 Characters</Text>
                                </View>
                                <View><Text style={styles.error}>{this.state.errdec}</Text></View>
                                <View>
                                    <Text style={styles.title}>புகைப்படத்தைப் பதிவேற்றுக </Text>
                                    {this.state.imagesource == "" ?
                                        <TouchableOpacity style={styles.imageplaceholder} onPress={() => this.selectPhotoTapped()}>
                                            <Icon name="add" style={styles.plus} />
                                        </TouchableOpacity> :
                                        <View style={{ width: 108, height: 108 }}>
                                            <Image source={{ uri: this.state.imagesource }} style={{ width: '100%', height: '100%' }} />
                                        </View>}
                                </View>
                                {this.state.imagesource !="" ?
							<TouchableOpacity onPress={()=>this.removePhotoAdd()}>								
								<Text style={styles.error}>Remove</Text>
							</TouchableOpacity> : null }
                                <View><Text style={styles.error}>{this.state.errImg}</Text></View>
                            </View>
                            <View style={styles.popupbtn}>
                                <TouchableOpacity style={styles.popbtn} onPress={() => this.props.navigation.navigate("Announcement")}>
                                    <Text style={styles.popUpCancel}>ரத்து</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.popbtn} onPress={() => this.postData()}>
                                    <Text style={styles.popUpbtnText}>சமர்ப்பிக்கவும்</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                        : <View style={styles.popup}>
                            <View style={{ padding: 10 }}>
                                <View>
                                    <Text style={styles.title}>Description : </Text>
                                    <TextInput
                                        style={styles.textarea}
                                        numberOfLines={3}
                                        maxLength={2000}
                                        multiline={true}
                                        value={this.state.description}
                                        onChangeText={(description) => this.setState({ description: description })} />
                                    <Text>{2000 - this.state.description.length}/2000 Characters</Text>
                                </View>
                                <View><Text style={styles.error}>{this.state.errdec}</Text></View>
                                <View>
                                    <Text style={styles.title}>புகைப்படத்தைப் பதிவேற்றுக </Text>
                                    {(this.state.imagesources == null) && (this.state.imagesource == "") ?
                                        <TouchableOpacity style={styles.imageplaceholder} onPress={() => this.selectPhotoTapped()}>
                                            <Icon name="add" style={styles.plus} />
                                        </TouchableOpacity> :
                                        <View style={{ width: 108, height: 108 }}>
                                            {this.state.imagesources != null ?
                                                <Image key={454} source={{ uri: `${ApiUrls.apiEnvironment}` + this.state.imagesources + "?" + this.state.updateImg }} style={{ width: '100%', height: '100%' }} />
                                                : <Image key={581} source={{ uri: this.state.imagesource }} style={{ width: '100%', height: '100%' }} />}
                                        </View>}
                                    {(this.state.imagesources != null) || (this.state.imagesource != "") ?
                                        <TouchableOpacity onPress={() => this.removePhoto(this.state.dataId)}>
                                            <Text style={styles.deletePhoto}>Delete photo</Text>
                                        </TouchableOpacity>

                                        : null}
                                </View>
                            </View>
                            <View style={styles.popupbtn}>
                                <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                    <Text style={styles.popUpCancel}>ரத்து</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.popbtn} onPress={() => this.editAnnouncement()}>
                                    <Text style={styles.popUpbtnText}>சமர்ப்பிக்கவும்</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    }
                </ScrollView>
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        // padding: 10
    },
    mainContainer: {
        marginBottom: 10
    },
    row: {
        flexDirection: 'row',
    },
    newsContainer: {
        padding: 15
    },
    profileImg: {
        width: 50,
        height: 50,
        padding: 2,
        borderRadius: 25,
        marginLeft: 10
    },
    profilePic: {
        width: '100%',
        height: '100%',

    },
    header: {
        width: '75%',
        marginLeft: 10,
        marginTop: 4
    },
    name: {
        fontFamily: 'MeeraInimai-Regular',
        fontWeight: 'bold',
        paddingTop: 5
    },
    date: {
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 12,
        paddingTop: 4
    },
    imgPost: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    post: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    description: {
        paddingTop: 10,
        fontFamily: 'MeeraInimai-Regular',
        lineHeight: 22,
        color: defaultTheme.colors.gray
    },
    titleContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        // borderWidth: 1
    },
    moreIcon: {
        fontSize: 22,
        marginTop: 6,
        color: defaultTheme.colors.gray
    },
    edit: {
        paddingVertical: 6,
        paddingHorizontal: 4
    },
    delete: {
        paddingVertical: 6,
        paddingHorizontal: 4
    },
    plus: {
        paddingLeft: 30,
        fontSize: 40,
        justifyContent: 'center',
        alignItems: 'center',
        color: defaultTheme.colors.gray
    },
    footer: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        backgroundColor: defaultTheme.colors.white,
        paddingVertical: 10
    },
    footerText: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 15,
        paddingLeft: 10
    },
    popup: {
        paddingBottom: 20
    },
    confirmText: {
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.white,
        alignItems: 'center'
    },
    popbtn: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20
    },
    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popupHeader: {
        backgroundColor: defaultTheme.colors.primary,
        height: 40,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingLeft: 10
    },
    // textarea:{
    // 	borderWidth: 1,
    // 	borderRadius: 4,
    // 	borderColor: defaultTheme.colors.lighterGray,
    // 	paddingBottom: 6,
    // 	fontFamily: 'MeeraInimai-Regular',
    // 	color: defaultTheme.colors.gray,
    // },
    title: {
        fontFamily: 'MeeraInimai-Regular',
        fontWeight: 'bold',
        fontSize: 14,
        paddingVertical: 10,
        color: defaultTheme.colors.gray
    },
    imageplaceholder: {
        width: 108,
        height: 108,
        margin: 10,
        borderWidth: 1,
        borderColor: defaultTheme.colors.lighterGray,
        borderRadius: 4,
        justifyContent: 'center'
    },
    plus: {
        paddingLeft: 30,
        fontSize: 40,
        color: defaultTheme.colors.gray
    },
    textarea: {
        borderWidth: 1.5,
        borderRadius: 4,
        paddingBottom: 200,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray,
        textAlignVertical:'top'
    },
    deletePhoto: {
        fontFamily: 'MeeraInimai-Regular',
        textDecorationLine: "underline",
        textDecorationColor: defaultTheme.colors.red,
        color: defaultTheme.colors.red
    },
    error: {
        fontSize: 14,
        paddingTop: 4,
        color: defaultTheme.colors.red
    }

});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(AnnouncementAddEdit);
