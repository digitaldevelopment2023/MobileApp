/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,	
	TouchableOpacity,
} from "react-native";
import { connect } from 'react-redux';
/* Project Import will lives here */
import {Header, TextBox, Button, Loader} from "../../components";
import defaultTheme from "../../config/theme/default";
import { SvgImages } from '../../assets/svgImges/svgImges';

class AnnouncementMenu extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoading: false
		}
	}

	componentDidMount(){
	
	}
	render() {
		return (			
			<React.Fragment>
				<Header title="அறிவிப்புகள்" navigation={this.props.navigation}/>
				{this.state.isLoading == true? 
				<Loader/>:
				<View style={styles.container}>
					<TouchableOpacity style={[styles.card, styles.newsColor]} onPress={()=>this.props.navigation.navigate("News")}>
						<View style={styles.img}>{SvgImages.news(60, 60)}</View>
						<Text style={styles.text}>செய்திகள்</Text>
					</TouchableOpacity>
					<TouchableOpacity style={[styles.card,styles.wishesColor]} onPress={()=>this.props.navigation.navigate("Wishes")}>
						<View style={styles.img}>{SvgImages.wishes(60, 60)}</View>
						<Text style={styles.text}>வாழ்த்துக்கள்</Text>
					</TouchableOpacity>
					<TouchableOpacity style={[styles.card, styles.announcementColor]} onPress={()=>this.props.navigation.navigate("Announcement")}>
						<View style={styles.img}>{SvgImages.announcements(60, 60)}</View>
						<Text style={styles.text}>அறிவிப்புகள்</Text>
					</TouchableOpacity>
					<TouchableOpacity style={[styles.card, styles.obituary]} onPress={()=>this.props.navigation.navigate("Obituary")}>
						<View style={styles.img}>{SvgImages.flower(60, 60)}</View>
						<Text style={styles.text}>இரங்கல்கள்</Text>
					</TouchableOpacity>
				</View>
	         }
			</React.Fragment>
		)}
	}
	const styles = StyleSheet.create({	
		container:{
			flex: 1,
			padding: 10
        },
        row:{
            flexDirection: 'row',
		},
		card:{
			flexDirection:'row',
			// justifyContent:'center',
			alignItems:'center',
			backgroundColor: '#2196f3',
			paddingVertical: 25,
			borderRadius: 8,
			marginBottom:10
		},
		newsColor:{
			backgroundColor: defaultTheme.colors.lightBlue,
		},
		wishesColor:{
			backgroundColor:'#FF69B4'
		},
		obituary :{
			backgroundColor:'#ff5722'
		},
		announcementColor:{
			backgroundColor: defaultTheme.colors.yellow,
		},
		img:{
			paddingLeft: 10,
		},
		text:{
			fontFamily: 'MeeraInimai-Regular',
			fontSize: 18,
			paddingLeft: 20,
			color: defaultTheme.colors.white,
		},
		
	});

	function mapStateToProps(state) {
		return {
			user: state.loginReducer.user,
		};
	}	
export default connect(mapStateToProps)(AnnouncementMenu);
