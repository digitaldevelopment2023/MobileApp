/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,
	TouchableOpacity,
	Image,
	ScrollView,
	TextInput,
	FlatList
} from "react-native";
import { connect } from 'react-redux';
import ImageModal from 'react-native-image-modal';
import moment from 'moment';
import {
	Menu,
	MenuOptions,
	MenuOption,
	MenuTrigger,
} from 'react-native-popup-menu';
import Toast from 'react-native-simple-toast';
import Modal from 'react-native-modal';
import Icon from 'react-native-vector-icons/MaterialIcons';
import ImagePicker from 'react-native-image-picker';
import { ApiUrls } from '../../api/apiUrls';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";

class Announcement extends Component {
	constructor(props) {
		super(props);
		this.state = {
			description: '',
			imagesource: '',
			announcementType: 3,
			profilePic: '',
			isModalVisible: false,
			isEdit: false,
			isLoading: false,
		}
	}

	componentDidMount() {
		this.getAnnouncement();
		var currentDate = new Date();
		this.setState({ updateImg: currentDate }, this.getCalender)
	}

	componentDidUpdate(prevProps) {
		var params = this.props.route.params;
		if (params && params.refresh) {
			this.getAnnouncement();
			var currentDate = new Date();
			this.setState({ updateImg: currentDate }, this.getCalender)
			this.props.route.params.refresh = false;
		}
	}

	openModal = () => {
		this.setState({ isModalVisible: true });
	};

	editData = (data) => {
		// this.setState({
		// 	description: data.description,
		// 	dataId: data.id,
		// 	imagesources: data.announcementPic,
		// 	picId: data.picId,
		// });
		this.props.navigation.navigate("AnnouncementAddEdit", { pageControl: 2, data: data, title: "அறிவிப்புகளை திருத்து", type: 3 });

	};

	cancelModal = () => {
		this.setState({
			description: '',
			imagesource: '',
			profilePic: '',
			isModalVisible: false,
			isEdit: false
		});
	};

	selectPhotoTapped = () => {
		const options = {
			quality: 1.0,
			maxWidth: 500,
			maxHeight: 500,
			includeBase64: true,
			storageOptions: {
				skipBackup: true,
				privateDirectory: true
			}
		};

		ImagePicker.showImagePicker(options, (response) => {
			console.log('Response = ', response);
			if (response.didCancel) {
				console.log('User cancelled photo picker');
			}
			else if (response.error) {
				console.log('ImagePicker Error: ', response.error);
			}
			else if (response.customButton) {
				console.log('User tapped custom button: ', response.customButton);
			}
			else {
				var source = {
					uri: response.uri,
					type: response.type,
					name: response.fileName,
					height: response.height,
					width: response.width,
					// 	Platform.OS === "android" ? response.uri : response.uri.replace("file:/", "")
				};
				this.setState({
					profilePic: source,
					imagesources: null,
					imagesource: `data:${source.type};base64,` + response.data,
				});
			}
		});
	}

	getAnnouncement = () => {
		apiService(`/api/announcements/filter`, 'post', {
			userId: null,
			announcementType: this.state.announcementType,

		}, '', this.props.user.data.JWT,
			(result) => {
				if (result.status === 200) {
					this.setState({
						announcement: result.data
					})
				}
				else {
					this.setState({ isLoading: false });
					Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
				}
			},
			(error) => {
				this.setState({ isLoading: false });
				Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
			});
	}


	editAnnouncement = () => {
		if (this.updateValidation()) {
			var currentDate = new Date();
			let formData = new FormData();
			{
				this.state.imagesource != "" ?
					formData.append('pic', this.state.profilePic) : null
			}
			formData.append('description', this.state.description)
			formData.append('announcementType', this.state.announcementType)
			formData.append('id', this.state.dataId)
			formData.append('picId', this.state.picId)
			apiService(`/api/announcement`, 'put', formData, true, this.props.user.data.JWT,
				(result) => {
					if (result.data.SUCCESS = true) {
						this.setState({
							profilePic: '',
							description: '',
							imagesource: '',
							errdec: '',
							updateImg: currentDate,
							isEdit: false
						}, this.getAnnouncement())
						Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
					}
				},
				(error) => {
					Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
				});
		}
	}

	postData = () => {
		if (this.validation()) {
			let formData = new FormData();
			formData.append('pic', this.state.profilePic)
			formData.append('description', this.state.description)
			formData.append('announcementType', this.state.announcementType)
			apiService(`/api/announcement`, 'post', formData, true, this.props.user.data.JWT,
				(result) => {
					if (result.data.SUCCESS = true) {
						this.setState({
							profilePic: '',
							description: '',
							imagesource: '',
							errdec: '',
							errImg: '',
							isModalVisible: false,
						}, this.getAnnouncement())
						Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
					}
				},
				(error) => {
					Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
				});
		}
	}

	deletePost = (id) => {
		apiService(`/api/announcement/${id}`, 'delete', '', false, this.props.user.data.JWT,
			(result) => {
				if (result.data.SUCCESS = true) {
					this.getAnnouncement();
					Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
				}
			},
			(error) => {
				Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
			});
	}

	removePhoto = () => {
		this.setState({ imagesource: "", imagesources: null, profilePic: '' });
	}

	validation = () => {
		const { description, imagesource } = this.state;
		var valid = true
		this.setState({ errdec: this.state.description != "" ? "" : this.state.errdec, errImg: this.state.errImg != "" ? "" : this.state.errImg });
		if (description == "") {
			this.setState({ errdec: "Please enter description" })
			valid = false;
		}

		if (imagesource == "") {
			this.setState({ errImg: "Please upload Image " })
			valid = false;
		}

		return valid;
	}

	updateValidation = () => {
		const { description, imagesource } = this.state;
		var valid = true
		this.setState({ errdec: this.state.description != "" ? "" : this.state.errdec });
		if (description == "") {
			this.setState({ errdec: "Please enter description" })
			valid = false;
		}
		return valid;
	}


	render() {
		return (
			<React.Fragment>
				<Header title="அறிவிப்புகள்" navigation={this.props.navigation} />
				<View style={styles.container}>
					<FlatList
						data={this.state.announcement}
						extraData={this.state}
						onEndReachedThreshold={0}
						keyExtractor={(item) => item.id.toString()}
						onEndReached={this.pagination}
						renderItem={({ item }) =>
							<View style={styles.mainContainer}>
								<View style={styles.newsContainer}>
									<View style={styles.row}>
										<View style={styles.profileImg}>
											{(item.userImage !== null) ?
												<Image style={styles.profilePic} key={this.state.updateImg} source={{ uri: `${ApiUrls.apiEnvironment}` + item.userImage + "?" + this.state.updateImg }} /> :
												<Image style={styles.profilePic} source={require("../../assets/images/profilePic.png")} />
											}
										</View>
										<View style={styles.titleContainer}>
											<View style={styles.header}>
												<Text style={styles.name} >{item.userName}</Text>
												<Text style={styles.date}> {moment(item.createdAt).format('DD-MM-YYYY HH:MM A')}</Text>
											</View>
											<View>
												{this.props.user.data.DATA.id === item.createdBy ?
													<Menu>
														<MenuTrigger text={<Icon name="more-horiz" style={styles.moreIcon} />} />
														<MenuOptions>
															<MenuOption onSelect={() => this.editData(item)} >
																<Text style={styles.edit}>திருத்து</Text>
															</MenuOption>
															<MenuOption onSelect={() => this.deletePost(item.id)} >
																<Text style={styles.delete}>நீக்கு</Text>
															</MenuOption>
														</MenuOptions>
													</Menu> : null}
											</View>
										</View>
									</View>
									<Text style={styles.description}>{item.description}</Text>
								</View>
								{item.announcementPic != null ?
									<View>
										<View style={styles.imgPost}>
											<ImageModal
												resizeMode="contain"
												key={this.state.updateImg}
												imageBackgroundColor={defaultTheme.colors.white}
												style={{ width: 370, height: 290 }}
												source={{
													uri: `${ApiUrls.apiEnvironment}` + item.announcementPic + "?" + this.state.updateImg,
												}}
											/>
										</View>
									</View> : null}
							</View>} />
				</View>
				<Modal isVisible={this.state.isModalVisible}
					animationInTiming={1000}
					animationOutTiming={1000}
					backdropTransitionInTiming={800}
					backdropTransitionOutTiming={800}
				>
					<View style={styles.popup}>
						<View style={styles.popupHeader}>
							<Text style={styles.confirmText}>அறிவிப்புகளை உருவாக்குங்கள்</Text>
						</View>
						<View style={{ padding: 10 }}>
							<View>
								<Text style={styles.title}>Description : </Text>
								<TextInput
									style={styles.textarea}
									numberOfLines={3} maxLength={500} multiline={true} onChangeText={(description) => this.setState({ description: description })} />
								<Text>{500 - this.state.description.length}/500 Characters</Text>
							</View>
							<View><Text style={styles.error}>{this.state.errdec}</Text></View>
							<View>
								<Text style={styles.title}>புகைப்படத்தைப் பதிவேற்றுக </Text>
								{this.state.imagesource == "" ?
									<TouchableOpacity style={styles.imageplaceholder} onPress={() => this.selectPhotoTapped()}>
										<Icon name="add" style={styles.plus} />
									</TouchableOpacity> :
									<View style={{ width: 108, height: 108 }}>
										<Image source={{ uri: this.state.imagesource }} style={{ width: '100%', height: '100%' }} />
									</View>}
							</View>
							<View><Text style={styles.error}>{this.state.errImg}</Text></View>
						</View>
						<View style={styles.popupbtn}>
							<TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
								<Text style={styles.popUpCancel}>ரத்து</Text>
							</TouchableOpacity>
							<TouchableOpacity style={styles.popbtn} onPress={() => this.postData()}>
								<Text style={styles.popUpbtnText}>சமர்ப்பிக்கவும்</Text>
							</TouchableOpacity>
						</View>
					</View>
				</Modal>
				<Modal isVisible={this.state.isEdit}
					animationInTiming={1000}
					animationOutTiming={1000}
					backdropTransitionInTiming={800}
					backdropTransitionOutTiming={800}
				>
					<View style={styles.popup}>
						<View style={styles.popupHeader}>
							<Text style={styles.confirmText}>திருத்து</Text>
						</View>
						<View style={{ padding: 10 }}>
							<View>
								<Text style={styles.title}>Description : </Text>
								<TextInput
									style={styles.textarea}
									numberOfLines={3}
									maxLength={500}
									multiline={true}
									value={this.state.description}
									onChangeText={(description) => this.setState({ description: description })} />
								<Text>{500 - this.state.description.length}/500 Characters</Text>
							</View>
							<View><Text style={styles.error}>{this.state.errdec}</Text></View>
							<View>
								<Text style={styles.title}>புகைப்படத்தைப் பதிவேற்றுக </Text>
								{(this.state.imagesources == null) && (this.state.imagesource == "") ?
									<TouchableOpacity style={styles.imageplaceholder} onPress={() => this.selectPhotoTapped()}>
										<Icon name="add" style={styles.plus} />
									</TouchableOpacity> :
									<View style={{ width: 108, height: 108 }}>
										{this.state.imagesources != null ?
											<Image key={454} source={{ uri: `${ApiUrls.apiEnvironment}` + this.state.imagesources + "?" + this.state.updateImg }} style={{ width: '100%', height: '100%' }} />
											: <Image key={581} source={{ uri: this.state.imagesource }} style={{ width: '100%', height: '100%' }} />}
									</View>}
								{(this.state.imagesources != null) || (this.state.imagesource != "") ?
									<TouchableOpacity onPress={this.removePhoto}>
										<Text style={styles.deletePhoto}>Delete photo</Text>
									</TouchableOpacity>

									: null}
							</View>
						</View>
						<View style={styles.popupbtn}>
							<TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
								<Text style={styles.popUpCancel}>ரத்து</Text>
							</TouchableOpacity>
							<TouchableOpacity style={styles.popbtn} onPress={() => this.editAnnouncement()}>
								<Text style={styles.popUpbtnText}>சமர்ப்பிக்கவும்</Text>
							</TouchableOpacity>
						</View>
					</View>
				</Modal>
				<TouchableOpacity style={styles.footer} onPress={() => this.props.navigation.navigate("AnnouncementAddEdit", { pageControl: 1, title: "அறிவிப்புகளை உருவாக்குங்கள", type: 3 })}>
					<Icon name="add" style={styles.plus} />
					<Text style={styles.footerText}>அறிவிப்புகளை உருவாக்கவும்</Text>
				</TouchableOpacity>
			</React.Fragment>
		)
	}
}
const styles = StyleSheet.create({
	container: {
		flex: 1,
		// padding: 10
	},
	mainContainer: {
		marginBottom: 10,
		borderBottomWidth: 0.5,
		borderBottomColor: defaultTheme.colors.lighterGray
	},
	row: {
		flexDirection: 'row',
	},
	newsContainer: {
		padding: 15
	},
	profileImg: {
		width: 50,
		height: 50,
		padding: 2,
		borderRadius: 25,
		// marginLeft: 10
	},
	profilePic: {
		width: '100%',
		height: '100%',
		borderRadius: 25,

	},
	header: {
		width: '75%',
		marginLeft: 5,
		marginTop: 4
	},
	name: {
		marginLeft: 3,
		fontFamily: 'MeeraInimai-Regular',
		fontWeight: 'bold',
		// paddingTop: 5
	},
	date: {
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 12,
		paddingTop: 4
	},
	imgPost: {
		width: '100%',
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
		marginBottom: 10
	},
	post: {
		width: '100%',
		justifyContent: 'center',
		alignItems: 'center',
	},
	description: {
		paddingTop: 10,
		paddingLeft: 2,
		fontFamily: 'MeeraInimai-Regular',
		lineHeight: 22,
		color: defaultTheme.colors.gray
	},
	titleContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		// borderWidth: 1
	},
	moreIcon: {
		fontSize: 22,
		marginTop: 6,
		color: defaultTheme.colors.gray
	},
	edit: {
		paddingVertical: 6,
		paddingHorizontal: 4
	},
	delete: {
		paddingVertical: 6,
		paddingHorizontal: 4
	},
	plus: {
		paddingLeft: 30,
		fontSize: 40,
		justifyContent: 'center',
		alignItems: 'center',
		color: defaultTheme.colors.gray
	},
	footer: {
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		backgroundColor: defaultTheme.colors.white,
		paddingVertical: 10
	},
	footerText: {
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		fontSize: 15,
		paddingLeft: 10
	},
	popup: {
		backgroundColor: "#fff",
		paddingBottom: 20
	},
	confirmText: {
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.white,
		alignItems: 'center'
	},
	popbtn: {
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
		marginTop: 20
	},
	popupbtn: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'center',
		marginTop: 5
	},
	popUpbtnText: {
		backgroundColor: defaultTheme.colors.primary,
		color: defaultTheme.colors.white,
		borderWidth: 1,
		paddingTop: 10,
		paddingHorizontal: 8,
		borderRadius: 4,
		marginHorizontal: 15,
		height: 40,
		fontFamily: 'MeeraInimai-Regular',
	},
	popUpCancel: {
		borderWidth: 1,
		color: defaultTheme.colors.primary,
		paddingVertical: 7,
		paddingHorizontal: 8,
		paddingTop: 10,
		marginHorizontal: 15,
		borderRadius: 4,
		height: 40,
		fontFamily: 'MeeraInimai-Regular',
	},
	popupHeader: {
		backgroundColor: defaultTheme.colors.primary,
		height: 40,
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		paddingLeft: 10
	},
	textarea: {
		borderWidth: 1,
		borderRadius: 4,
		borderColor: defaultTheme.colors.lighterGray,
		paddingBottom: 6,
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
	},
	title: {
		fontFamily: 'MeeraInimai-Regular',
		fontWeight: 'bold',
		fontSize: 14,
		paddingVertical: 10,
		color: defaultTheme.colors.gray
	},
	imageplaceholder: {
		width: 108,
		height: 108,
		margin: 10,
		borderWidth: 1,
		borderColor: defaultTheme.colors.lighterGray,
		borderRadius: 4,
		justifyContent: 'center'
	},
	plus: {
		paddingLeft: 30,
		fontSize: 40,
		color: defaultTheme.colors.gray
	},
	textarea: {
		borderWidth: 1.5,
		borderRadius: 4,
		paddingBottom: 6,
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		borderColor: defaultTheme.colors.lighterGray
	},
	deletePhoto: {
		fontFamily: 'MeeraInimai-Regular',
		textDecorationLine: "underline",
		textDecorationColor: defaultTheme.colors.red,
		color: defaultTheme.colors.red
	},
	error: {
		fontSize: 14,
		paddingTop: 4,
		color: defaultTheme.colors.red
	}

});

function mapStateToProps(state) {
	return {
		user: state.loginReducer.user,
	};
}
export default connect(mapStateToProps)(Announcement);
