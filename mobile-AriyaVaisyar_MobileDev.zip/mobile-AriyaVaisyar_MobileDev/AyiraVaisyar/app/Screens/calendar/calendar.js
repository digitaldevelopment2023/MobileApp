/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,
	TouchableOpacity,
} from "react-native";
import { connect } from 'react-redux';
import DateTimePicker from "react-native-modal-datetime-picker";
import Icon from 'react-native-vector-icons/MaterialIcons';
import ImageModal from 'react-native-image-modal';
import moment from 'moment';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';

class Calendar extends Component {
	constructor(props) {
		super(props);
		this.state = {
			minDate: null,
			maximumDate: null,
			selectedDateShow: '',
			isLoading: false,
			minimumDate: '',
			maximumDate: '',
			calenderShow:false,
		}
	}
	componentDidMount() {
		var currentDate = new Date();
		var date = moment(currentDate).format('YYYY-MM-DD')
		var year = moment(date).format("YYYY");

		this.setState({ date: date, updateImg: currentDate, minimumDate: new Date(year, 0, 1), maximumDate: new Date(year, 11, 31) }, this.getCalender)
	}

	_showDateTimePicker = () => this.setState({ isDateTimePickerVisible: true });

	_hideDateTimePicker = () => this.setState({ isDateTimePickerVisible: false }, this.getCalender);

	_handleDatePicked = (date) => {
		var selectedDateShow = moment(date).format('DD-MM-YYYY')
		var selectedDate = moment(date).format('YYYY-MM-DD')
		var month = moment(date).format("MM");
		if (12 == month && this.state.calenderShow == false) {
			var addYear = moment(date).add(1, 'year').format("YYYY-MM-DD");
			var year = moment(addYear).format("YYYY");
			this.setState({ maximumDate: new Date(year, 11, 31),isDateTimePickerVisible: false ,calenderShow:true})
		}
		this.setState({ date: selectedDate, selectedDateShow: selectedDateShow,isDateTimePickerVisible: false })
		this.getCalender();
	};

	getCalender = () => {
		apiService(`/api/calendar/filter`, 'post', {
			date: this.state.date,
		}, '', this.props.user.data.JWT,
			(result) => {

				if (result.status === 200) {
					this.setState({
						calenderImg: result.data.calendarDateImage,
					})
				}
				else {
					this.setState({ isLoading: false });
				}
			},
			(error) => {
				this.setState({ isLoading: false });
			});
	}

	resetDate = () => {
		var currentDate = new Date();
		var date = moment(currentDate).format('YYYY-MM-DD')
		this.setState({ date: date, updateImg: currentDate, selectedDateShow: '' }, this.getCalender)
	}

	render() {
		return (
			<React.Fragment>
				<Header title="நாட்காட்டி" navigation={this.props.navigation} />
				{this.state.isLoading == true ?
					<Loader /> :
					<View style={styles.container}>
						<View style={styles.datePickerArea}>
							<View style={styles.p20}>
								<Text style={styles.lable}>தேதியைத் தேர்ந்தெடுக்கவும்</Text>
								<View style={styles.dateContainer}>
									<TouchableOpacity onPress={this._showDateTimePicker} style={styles.datePicker}>
										<Icon name="date-range" size={25} style={styles.icons} />
										{this.state.selectedDateShow == "" ?
											<Text style={styles.datePlaceholder}>நாட்காட்டி</Text> :
											<Text style={styles.dateTime}>{this.state.selectedDateShow} </Text>
										}
									</TouchableOpacity>
									<TouchableOpacity style={styles.btn} onPress={() => this.resetDate()}>
										<Text style={styles.reset}>மீட்டமைக்க</Text>
									</TouchableOpacity>
								</View>
							</View>
						</View>
						<View style={styles.textContainer}>
							<DateTimePicker
								isVisible={this.state.isDateTimePickerVisible}
								mode='date'
								date={moment(`${this.state.date}`).toDate()}
								minimumDate={this.state.minimumDate}
								maximumDate={this.state.maximumDate}
								onConfirm={this._handleDatePicked}
								onCancel={this._hideDateTimePicker}
							/>
							{this.state.calenderImg != null ?
								<View style={styles.calenderContainer}>
									<ImageModal
										resizeMode="contain"
										imageBackgroundColor={defaultTheme.colors.white}
										style={{ width: 340, height: 290 }}
										source={{
											uri: `${ApiUrls.apiEnvironment}` + this.state.calenderImg + "?" + this.state.updateImg,
										}}
									/>
								</View> : <View>
									<Text style={styles.noDataFound}>No data Found</Text>
								</View>}
						</View>
					</View>
				}
			</React.Fragment>
		)
	}
}
const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	row: {
		flexDirection: 'row',
	},
	calenderContainer: {
		backgroundColor: defaultTheme.colors.white,
		marginHorizontal: 10,
		// borderWidth: 1,
		borderColor: defaultTheme.colors.lighterGray
	},
	img: {
		width: '100%',
		height: 250
	},
	icons: {
		fontSize: 22
	},
	datePickerArea: {
		backgroundColor: defaultTheme.colors.primary
	},
	datePicker: {
		borderWidth: 1,
		borderRadius: 4,
		borderColor: defaultTheme.colors.white,
		flexDirection: 'row',
		width: 200,
		paddingVertical: 10,
	},
	lable: {
		color: defaultTheme.colors.lightGray,
		marginBottom: 15,
		fontFamily: 'MeeraInimai-Regular',
	},
	p20: {
		paddingHorizontal: 20
	},
	icons: {
		color: defaultTheme.colors.lightGray,
		paddingLeft: 5
	},
	datePlaceholder: {
		color: defaultTheme.colors.lightGray,
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 15,
		paddingLeft: 5,
		paddingTop: 2
	},
	dateTime: {
		color: defaultTheme.colors.white,
		fontFamily: 'MeeraInimai-Regular',
		paddingLeft: 5,
		paddingTop: 2
	},
	dateContainer: {
		flexDirection: 'row',
		marginBottom: 25
	},
	textContainer: {
		marginTop: 30
	},
	reset: {
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 15,
		color: defaultTheme.colors.gray
	},
	btn: {
		marginLeft: 20,
		borderRadius: 4,
		height: 45,
		paddingHorizontal: 10,
		justifyContent: 'center',
		backgroundColor: defaultTheme.colors.white
	},
	noDataFound: {
		marginTop: 30,
		textAlign: 'center'
	},
});

function mapStateToProps(state) {
	return {
		user: state.loginReducer.user,
	};
}
export default connect(mapStateToProps)(Calendar);
