/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,
	Image,	
	TouchableOpacity,
	PermissionsAndroid,
	ScrollView
} from "react-native";
import Toast from 'react-native-simple-toast';
import ImagePicker from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/MaterialIcons';
import moment from 'moment';
import { connect } from 'react-redux';
/* Project Import will lives here */
import {Header, TextBox, Button, Loader} from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';

class Profile extends Component {
	constructor(props) {
		super(props);
		this.state = {
			userInfo:'',
			profileImage:'',
			imagesource:'',
			maximumDate:null,
		}
	}

	componentDidMount(){
		this.userInfo();
		this.camerapermission();
		this.setState({ profileImage: ""});
	}

	componentDidUpdate(prevProps) {
        var params = this.props.route.params;
        if (params && params.refresh) {
            this.userInfo();
            this.props.route.params.refresh = false;
        }
	}
	
	async camerapermission(){
		try {
			const granted = await PermissionsAndroid.request(
			  PermissionsAndroid.PERMISSIONS.CAMERA
		
			);
			if (granted === PermissionsAndroid.RESULTS.GRANTED) {
			  console.log("You can use the camera");
			} else {
			//   console.log("Camera permission denied");
			}
		  } catch (err) {
			console.warn(err);
		  }
	  }

	  selectPhotoTapped =()=> {
		const options = {
			quality: 1.0,
			maxWidth: 500,
			maxHeight: 500,
			includeBase64: true,
			storageOptions: {
			skipBackup: true,
			privateDirectory: true 
			}
		};

		ImagePicker.showImagePicker(options, (response) => {
		console.log('Response = ', response);        
		if (response.didCancel) {
			console.log('User cancelled photo picker');
		}
		else if (response.error) {
			console.log('ImagePicker Error: ', response.error);
		}
		else if (response.customButton) {
			console.log('User tapped custom button: ', response.customButton);
		}
		else {
			var source = { 
				uri: response.uri,
				type:response.type,
				name:response.fileName,
				height: response.height,
				width: response.width,      			
				// 	Platform.OS === "android" ? response.uri : response.uri.replace("file:/", "")
			};
			this.setState({
				profilePic: source,
				imagesource: "data:image/jpeg;base64,"+ response.data,  
			},this.profilePicUpload(source));
		}
		});
	  }

	profilePicUpload =(source)=>{
		var time = new Date(); 
		let formData = new FormData();
			formData.append('file', source)
			apiService(`/api/file/profileImage/${this.props.user.data.DATA.id} `, 'put', formData, true , this.props.user.data.JWT,	
			(result) => {
				if(result.data.SUCCESS = true){
					Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP);
					this.setState({
						...this.state.userInfo,
						 profilePicId:result.data.id,
						  time:time});
					}
			},
			(error) => {
				Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
			});
	}

	userInfo =()=>{
		this.setState({isLoading: true});
		apiService(`/api/user/${this.props.user.data.DATA.id}`, 'get', '','',this.props.user.data.JWT,
		(result) => {
			var time = new Date(); 
			if(result.status === 200 ){
				this.setState({userInfo: result.data, profileImage:result.data.profileImage,time: time, isLoading: false});
			}
			else {  
				this.setState({isLoading: false}); 				
			}
		},
		(error) => {
			this.setState({isLoading: false});
		});
	}

	editProfile=()=>{
		this.props.navigation.navigate("ProfileEdit", {userInfo:this.state.userInfo})
	}

	render() {
				
		return (			
			<React.Fragment>
				<Header title="சுயவிவரம்" navigation={this.props.navigation}/>
				<ScrollView>
				{this.state.isLoading === true ?
				<Loader/>	:
					<View>
						<View>
							<Image style={styles.profile_bg} source={require("../../assets/images/profile_bg.png")}  />
							<View style={styles.userPic}>
								<View style={styles.img}>
									<Image  key={this.state.time} style={styles.profile} source={{uri: `${ApiUrls.apiEnvironment}`+ this.state.profileImage +"?" + this.state.time}} />
								</View>
								<View>
									<TouchableOpacity style={styles.camera}  onPress={()=>this.selectPhotoTapped()}>
										<Icon name ="camera-alt" size={24} style={styles.cameraIcon}/>	
									</TouchableOpacity>
									{/* <TouchableOpacity style={styles.edit} onPress={()=> this.props.navigation.navigate("ProfileEdit", {userInfo:this.state.userInfo})}>
										<Icon name ="edit" size={24} style={styles.editIcon}/>
									</TouchableOpacity> */}
								</View>
							</View>
						</View>
					<View style={styles.container}>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.user(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>பெயர்</Text>
								<Text style={styles.content}>{this.state.userInfo.name}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.gender(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>பாலினம்</Text>
								<Text style={styles.content}>{this.state.userInfo.gender}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.education(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>கல்வி</Text>
								<Text style={styles.content}>{this.state.userInfo && this.state.userInfo.education && this.state.userInfo.education.educationName} </Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.employement(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>தொழில்</Text>
								<Text style={styles.content}>{this.state.userInfo && this.state.userInfo.occupationId && this.state.userInfo.occupationId.occupationName}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.calender(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>பிறந்த தேதி</Text>
								<Text style={styles.content}>{moment(this.state.userInfo.dateOfBirth).format('DD-MM-YYYY')} </Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.parents(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>கணவன் (அ) மனைவியின் பெயர்</Text>
								<Text style={styles.content}>{(this.state.userInfo.spouseName == "")|| (this.state.userInfo.spouseName == null)? "-": this.state.userInfo.spouseName}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.father(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>தந்தையின் பெயர்</Text>
								<Text style={styles.content}>{this.state.userInfo.fatherName}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.country(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>நாடு</Text>
								<Text style={styles.content}>{this.state.userInfo && this.state.userInfo.country && this.state.userInfo.country.countryName}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.state(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>மாநிலம்</Text>
								<Text style={styles.content}>{this.state.userInfo && this.state.userInfo.state && this.state.userInfo.state.stateName}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.city(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>மாவட்டம்</Text>
								<Text style={styles.content}>{this.state.userInfo && this.state.userInfo.district && this.state.userInfo.district.districtName}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.taluk(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>தாலுகா</Text>
								<Text style={styles.content}>{this.state.userInfo && this.state.userInfo.taluk && this.state.userInfo.taluk.talukName}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.alterMobile(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>கைபேசி எண்</Text>
								<Text style={styles.content}>{this.state.userInfo.phone}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.phone(25, 25)}
							</View>
							<View>
								<Text style={styles.nameTitle}>மாற்று கைபேசி எண்</Text>
								<Text style={styles.content}>{(this.state.userInfo.alternativeMobileNumber== "")||(this.state.userInfo.alternativeMobileNumber== null)? "-": this.state.userInfo.alternativeMobileNumber}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.email(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>மின்னஞ்சல்</Text>
								<Text style={styles.content}>{(this.state.userInfo.email== "")||(this.state.userInfo.email== null)? "-": this.state.userInfo.email}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.money(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>ஆண்டு வருமானம்</Text>
								<Text style={styles.content}>{this.state.userInfo.income}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.community(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>ஆயிரவைசியரில் உட்பிரிவு</Text>
								<Text style={styles.content}>{this.state.userInfo && this.state.userInfo.sect &&this.state.userInfo.sect.sectName}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.group(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>கோத்திரம்</Text>
								<Text style={styles.content}>{this.state.userInfo && this.state.userInfo.subSect &&this.state.userInfo.subSect.subSectName}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.bloodDonor(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>இரத்த வகை </Text>
								<Text style={styles.content}>{this.state.userInfo && this.state.userInfo.bloodGroup && this.state.userInfo.bloodGroup.bloodGroup}</Text>
							</View>
						</View>
						<View style={[styles.row, styles.mainContent]}>
							<View style={styles.iconContainer}>
								{SvgImages.bloodDonate(30, 30)}
							</View>
							<View>
								<Text style={styles.nameTitle}>இரத்த தானம்</Text>
								<Text style={styles.content}>{this.state.userInfo.bloodDonate == "Y" ? "Yes" : "No"} </Text>
							</View>
						</View>
						<Button
							style={styles.button}
							btnName="சுயவிவரத்தைத் திருத்து"
							color={defaultTheme.colors.white}
							size={16}							
							onPress={()=>this.editProfile()}
						/>
					</View>
				</View>
			}
				</ScrollView>
    		</React.Fragment>
		);
	}
}

const styles = StyleSheet.create({
	container:{
		flex: 1,
		padding: 10,
		marginTop: -10
	},
	row:{
		flexDirection:'row',
		paddingHorizontal: 5
	},
	profile_bg:{
		// width:'100%',
		// paddingBottom: 40,
		// height:''

	},
	// profilePicContainer:{
	// 	backgroundColor: defaultTheme.colors.primary,
	// 	height: 80,
	// 	zIndex: 0,
	// 	position:'relative'
	// },
	userPic:{
		flexDirection:'row',
		justifyContent:'flex-end',
		paddingRight: 50,
		marginTop: -120
	},
	profile:{
		width: '100%',
		height: '100%',
		borderRadius: 75,
		marginTop: -30,
		borderColor: defaultTheme.colors.white,
        borderWidth:3,
        overflow: 'hidden',
        shadowColor: defaultTheme.colors.white,
        shadowRadius: 10,
        shadowOpacity: 1,
	},
	img:{
		width:150,
		height: 150,
	},
	cardbg:{
		backgroundColor: '#EAEEF3',
		borderRadius: 10,
		padding: 10
	},
	titleContainer:{
		flexDirection:'row',
		justifyContent:'flex-start',
	},
	title:{
		fontFamily: 'MeeraInimai-Regular',
		fontWeight:'bold',
		paddingVertical: 4,
		paddingHorizontal: 6,
		fontSize: 20,
		color: defaultTheme.colors.gray,
		backgroundColor: defaultTheme.colors.white
	},
	mainContent:{
		marginVertical: 10
	},
	iconContainer:{
		paddingTop: 10,
		width:40
	},
	content:{
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		fontSize: 14,
		paddingTop: 1,
		fontWeight:'bold',
	},
	mainContainer:{
		marginTop: -45,
		padding: 15
	},
	placeContainer:{
		backgroundColor: defaultTheme.colors.primary,
		marginTop: 220,
		margin: 15,
		borderRadius: 10,
		paddingTop: 10,
		paddingBottom: 25,
		paddingHorizontal: 10
	},
	place:{
		color: defaultTheme.colors.white,
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 15
	},
	placeIcon:{
		color: defaultTheme.colors.white,
		fontSize: 70
	},
	textContent:{
		paddingLeft: 18,
		paddingTop: 10
	},
	// register
	radioContainer:{
		marginTop: 15
	},
	mt12:{
		marginTop: 12
	},
	radioBtn:{
		fontFamily: 'MeeraInimai-Regular',
		marginRight: 20,
		paddingTop:5
	},
	textBox:{
		borderWidth : 1.5,
		marginVertical:10,
		borderRadius: 4,
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		borderColor: defaultTheme.colors.lighterGray
	},
	datePicker:{
		flexDirection:'row',
		alignItems:'center',
		borderBottomWidth : 1.5,
		marginVertical:10,
		borderRadius: 4,
		borderWidth : 1,
		borderColor: defaultTheme.colors.lighterGray,
		height: 45,
	},
	icons:{
		color: defaultTheme.colors.lighterGray,
		right:7 ,
		position: 'absolute'
	},
	dateTime:{
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 14,
		left:15 ,
		color: defaultTheme.colors.gray,
		position: 'relative'
	},
	datePlaceholder:{
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 14,
		left:15 ,
		color: defaultTheme.colors.lighterGray,
		position: 'relative'
	},
	lable:{
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		fontSize:15,
		top: 8,
		position:'relative'
	},
	text:{
		color: defaultTheme.colors.white
	},

	button:{
		backgroundColor: defaultTheme.colors.primary,
		color: defaultTheme.colors.white,
		width:'100%',
		fontFamily: 'MeeraInimai-Regular',
	},	
	checkBoxText:{
		color: defaultTheme.colors.gray,
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 10
	},
	imageOuter:{
		width: 108,
		height: 108,
		margin: 10,		
		justifyContent:'center',
	},
	imageplaceholder:{
		width: 108,
		height: 108,
		margin: 10,	
		borderWidth: 1,
		borderColor: defaultTheme.colors.lighterGray,
		borderRadius: 4,
		justifyContent:'center'
	},
	plus:{
		paddingLeft:30,
		fontSize:  40,
		color: defaultTheme.colors.gray
	},
	camera:{
		flexDirection:'row',
		top: 70,
		right: 125,
		padding: 10,
		zIndex: 999,
		position:'absolute',
	},
	cameraIcon:{
		color: defaultTheme.colors.primary,
	},
	edit:{
		flexDirection:'row',
		justifyContent:'flex-end',
		top: -30,
		right: -39,
		padding: 10,
		position:'absolute'
	},
	editIcon:{
		color: defaultTheme.colors.white,
		
	},
	nameTitle:{
		color: defaultTheme.colors.lighterGray,
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 13
	},
	error: {
		color: defaultTheme.colors.red,
		paddingLeft: 12
	}
  });

  function mapStateToProps(state) {
	return {
		user: state.loginReducer.user,
	};
}	
export default connect(mapStateToProps)(Profile);
