/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,	
	TouchableOpacity,
	FlatList,
	Image,
	ActivityIndicator
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
import moment from 'moment';
/* Project Import will lives here */
import {Header, TextBox, Button, Loader} from "../../components";
import FUI from '../../assets/fui/fui';
import defaultTheme from "../../config/theme/default";

class Acknowledgement extends Component {
	constructor(props) {
		super(props);
		this.state = {
			
		}
	}

	render() {
		return (			
			<React.Fragment>
				<Header title="நன்றி" navigation={this.props.navigation}/>
				{this.state.isLoading == true? 
				<Loader/>:
				<View style={styles.overlay}>
					<View style={styles.container}>
						<View style={styles.thank}>
							<FUI name="thankful" size={25}  style={styles.icons}/>
						</View>	
						<View style={styles.countryContainer}>
							<Text style={styles.lable}>உங்கள் பதிவு ஏற்றுக்கொள்ளப்பட்டது மற்றும் செயலில் உள்ளது. எங்கள் நிர்வாகிடம் இருந்து உங்களுக்கு என்னும் உள்ளயே நுழைய அனுமதி அளிக்கப்படவில்லை!</Text>
							<Text style={styles.thanks}>நன்றி ..!!</Text>
						</View>
					</View>
				</View>
	         }
			</React.Fragment>
		)}
	}
	const styles = StyleSheet.create({	
		container:{
			flex: 1,
        },
        row:{
            flexDirection: 'row',
		},
		overlay: {
			backgroundColor: defaultTheme.colors.primary,
			top:56,
			bottom: 0,
			left:0,
			right:0,
			position:'absolute'
		},
		lable:{
			paddingHorizontal:15,
			fontFamily: 'MeeraInimai-Regular',
			color: defaultTheme.colors.white,
			lineHeight: 25,
			marginTop: 18,
			fontSize: 16,
			textAlign:'center'
		},
		thanks:{
			color: defaultTheme.colors.white,
			lineHeight: 40,
			textAlign:'center',
			fontSize: 22,
		},
		thank:{
			marginTop: 250,
			flexDirection:'row',
			justifyContent:'center',
			alignItems:'center'
		},
		icons:{
			color: defaultTheme.colors.white,
			fontSize: 60,
		}
	});

	function mapStateToProps(state) {
		return {
			user: state.loginReducer.user,
		};
	}	
export default connect(mapStateToProps)(Acknowledgement);
