/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,
	TouchableOpacity,
	FlatList,
	Image,
	ActivityIndicator
} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
import moment from 'moment';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import FUI from '../../assets/fui/fui';
import defaultTheme from "../../config/theme/default";
import { SvgImages } from '../../assets/svgImges/svgImges';

class ErrorPage extends Component {
	constructor(props) {
		var params = props.route.params.error;
		console.log(params)
		super(props);
		this.state = {
			error: params
		}
	}

	render() {
		return (
			<React.Fragment>
				<Header title="சேவையகம்" navigation={this.props.navigation} />
				{this.state.error == "NetworkError" ?
					<View style={styles.overlay}>
						<View style={styles.container}>
							<View style={styles.thank}>
								<View style={styles.img}>{SvgImages.error(60, 60)}</View>
							</View>
							<View style={styles.countryContainer}>
								<Text style={styles.lable}>சேவையகம் இயங்கவில்லை. நிர்வாகியைத் தொடர்பு கொள்ளவும் !</Text>
								<Text style={styles.thanks}>நன்றி ..!!</Text>
							</View>
						</View>
					</View> :
					<View style={styles.overlay}>
						<View style={styles.container}>
							<View style={styles.thank}>
								<View style={styles.img}>{SvgImages.netConnectionError(60, 60)}</View>
							</View>
							<View style={styles.countryContainer}>
								<Text style={styles.lable}>இணைப்பு இல்லை. உங்கள் இணைய இணைப்பை சரிபார்க்கவும் !</Text>
								<Text style={styles.thanks}>நன்றி ..!!</Text>
							</View>
						</View>
					</View>

				}
			</React.Fragment>
		)
	}
}
const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	row: {
		flexDirection: 'row',
	},
	overlay: {
		backgroundColor: defaultTheme.colors.primary,
		top: 56,
		bottom: 0,
		left: 0,
		right: 0,
		position: 'absolute'
	},
	lable: {
		paddingHorizontal: 15,
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.white,
		lineHeight: 25,
		marginTop: 18,
		fontSize: 16,
		textAlign: 'center'
	},
	thanks: {
		color: defaultTheme.colors.white,
		lineHeight: 40,
		textAlign: 'center',
		fontSize: 22,
	},
	thank: {
		marginTop: 250,
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center'
	},
	icons: {
		color: defaultTheme.colors.white,
		fontSize: 60,
	}
});

function mapStateToProps(state) {
	return {
		user: state.loginReducer.user,
	};
}
export default connect(mapStateToProps)(ErrorPage);
