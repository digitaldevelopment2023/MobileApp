/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,	
	TouchableOpacity,
	ScrollView,
	ActivityIndicator
} from "react-native";
import RadioForm, {RadioButton, RadioButtonInput, RadioButtonLabel} from 'react-native-simple-radio-button';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePicker  from "react-native-modal-datetime-picker";
import Icon from 'react-native-vector-icons/MaterialIcons';
import Toast from 'react-native-simple-toast';
import moment from 'moment';
import { connect } from 'react-redux';
/* Project Import will lives here */
import {Header, TextBox, Button, Loader} from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { FormList } from "../../utils/common";

class EditFamily extends Component {
	constructor(props) {
		super(props);
		this.state = {
			occupation:[],
			userInfo:props.route.params.userInfo,
			name :props.route.params.userInfo.name || '',
			gender: props.route.params.userInfo.gender || '',
			mobileNo: props.route.params.userInfo.phone || '',
			dob:  props.route.params.userInfo.dateOfBirth || '',
			createdAt: props.route.params.userInfo.createdAt || '',
			id: props.route.params.userInfo.id || '',
			relationship: props.route.params.userInfo.relationship || null,
			defaultRelationship: props.route.params.userInfo.relationship || null,
			primaryGender: props.user.data.DATA.gender,
			errGender:'',
			minDate: null,
			maximumDate: null,
			dateCheck:true,
		}
	}

	componentDidMount(){
		if(this.props.route.params.userInfo.relationship =="அப்பா"){
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ maximumDate: dob - 18});
		}
		if(this.props.route.params.userInfo.relationship =="அம்மா"){
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ maximumDate: dob - 18,});
		}
		if(this.props.route.params.userInfo.relationship =="மகன்"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ minDate: parseInt(dob) + parseInt(18), maximumDate: parseInt(currentYear)-parseInt(1),});
		}
		if(this.props.route.params.userInfo.relationship =="மகள்"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ minDate: parseInt(dob) + parseInt(18), maximumDate: parseInt(currentYear)-parseInt(1),});
		}
		if(this.props.route.params.userInfo.relationship =="அண்ணன்"){
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ maximumDate:dob});
		}
		if(this.props.route.params.userInfo.relationship =="அக்கா"){
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ maximumDate:dob,});
		}
		if(this.props.route.params.userInfo.relationship =="தம்பி"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ minDate:dob, maximumDate: parseInt(currentYear)-parseInt(1)});
		}
		if(this.props.route.params.userInfo.relationship =="தங்கச்சி"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ minDate:dob, maximumDate: parseInt(currentYear)-parseInt(1)});
		}
		if(this.props.route.params.userInfo.relationship =="கணவன்"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ minDate:dob - parseInt(20), maximumDate: parseInt(currentYear)-parseInt(15), defaultRelationship: this.props.route.params.userInfo.relationship, relationship: this.props.route.params.userInfo.relationship, errRelationship:''});
		}
		if(this.props.route.params.userInfo.relationship =="மனைவி"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({  minDate:dob - parseInt(10), maximumDate: parseInt(currentYear)-parseInt(15), defaultRelationship: this.props.route.params.userInfo.relationship, relationship: this.props.route.params.userInfo.relationship, errRelationship:''});
		}
	}

	getFamilyMembers = (num)=>{
		this.setState({isLoading: true});
		apiService(`/api/familyMembers/${this.props.user.data.DATA.id}`, 'get', '',false, this.props.user.data.JWT,	
			(result) => {
				if(result.status === 200){
					result.data.map(val => {
						if(num ==1){
							if(val.relationship == "அப்பா" && this.props.route.params.userInfo.id != val.id){
								this.setState({isFatherCheck:true,errRelationship: "Your father is already created"});
								this.validation();
							}
						}
						if(num==2){
							if(val.relationship == "அம்மா"&& this.props.route.params.userInfo.id != val.id){
								this.setState({isMotherCheck:true,errRelationship: "Your mother is already created"});
								this.validation();
							}
						}					
					});
					this.setState({familyMembers: result.data, isLoading: false});
				}
			},
			(error) => {
				this.setState({isLoading: false});
		});
	}

	
	checkValidation=(param,type)=>{
		var valid = true;
		var nameRegex = /^[a-zA-Z ]{2,30}$/;
		var mobileNoReg =  /^[1-9][0-9]{9}$/;
		this.setState({
			errName: this.state.name != "" ? "": this.state.errName,
			errGender:this.state.gender != "" ? "":this.state.errGender, 
			errMobile:this.state.mobileNo != "" ? "": this.state.errMobile,
			errRelationship: this.state.relationship != "" ? "": this.state.errRelationship,
		});
		switch(type) {	 
		  case "NAME":
			if(param.length < 3){
				this.setState({errName: "Please enter valid name"})
			}
			break;
			case "GENDER":
				if(param == "" || param == null){
					this.setState({errGender: "Please select gender"})
					valid = false;
				}
				break;	
			case "MOBILENUMBER":
				if(mobileNoReg.test(param) === false){
					this.setState({errMobile: "Please enter your mobile Number"})
					valid = false;
				}
				break;
			case "RELATIONSHIP":
				if(nameRegex.test(param) === false){
					this.setState({errRelationship: "Please select your Relationship"})
					valid = false;
				}
				break;
				case "RELATIONSHIP":
					if(nameRegex.test(param) === false){
						this.setState({errDob: "Please select Date of Birth"})
						valid = false;
					}
					break;
		  default:
			// Alert.alert("err");
		}
	  }

	  validation=() =>{
		const {name, gender, dob, relationship,mobileNo, defaultRelationship} = this.state;
		var valid = true
		this.setState({
			errName: this.state.name != "" ? "": this.state.errName,
			errGender:this.state.gender != "" ? "":this.state.errGender,
			errMobile:this.state.mobileNo != "" ? "": this.state.errMobile,
			errRelationship: this.state.relationship != "" ? "": this.state.errRelationship, 
			errDob:this.state.dob != "" ? "": this.state.errDob, 
		});
		var nameRegex = /^[a-zA-Z ]{2,30}$/;
		var mobileNoReg =  /^[1-9][0-9]{9}$/;
		if(name.length < 3){
			this.setState({errName: "Please enter valid name"})
			valid = false;
		}
		if(gender == "" || gender == null){
			this.setState({errGender: "Please select gender"})
			valid = false;
		}
		if(mobileNo == "" || mobileNo == null){
			this.setState({errMobile: "Please enter your mobile Number"})
			valid = false;
		}
		if((relationship =="") ||( relationship == null) || (defaultRelationship == null)){
			this.setState({errRelationship: "Please select your Relationship"})
			valid = false;
		}
		if(dob =="" ||dob == null ){
			this.setState({errDob: "Please select Date of Birth"})
			valid = false;
		}

		if(relationship != null && relationship !="" && (relationship=="மகன்" || relationship=="மகள்" )){
			var currentYear = moment().format('YYYY');	
			var dobDate =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			var dobCal = currentYear - dobDate;
			if(dobCal >= 18){

			}else{
				this.setState({errRelationship: "Your son/daughter not age in 18"})
			   valid = false;
			}	
		}
		if(this.state.isFatherCheck == true){
			this.setState({errRelationship: "Your father is already created"})
			valid = false;
		}
		if(this.state.isMotherCheck == true){
			this.setState({errRelationship: "Your mother is already created"})
			valid = false;
		}
		   return valid;
	}

	_showDateTimePicker = () => this.setState({ isDateTimePickerVisible: true });

	_hideDateTimePicker = () => this.setState({ isDateTimePickerVisible: false });
  
	_handleDatePicked = (date) => {
		var selectedDateShow =  moment(date).format('DD-MM-YYYY')
		var selectedDate =  moment(date).format('YYYY-MM-DD')	  
		this.setState({ dob: selectedDate, selectedDateShow: selectedDateShow,errDob:''})
		this._hideDateTimePicker();
	};

	editFamilyMembers =()=>{
		if(this.validation()) {
			apiService(`/api/familyMember`, 'put', {
				userId : this.props.user.data.DATA.id,
				id:this.state.id,
                name: this.state.name,
				gender:this.state.gender,
				phone: this.state.mobileNo,
				relationship: this.state.relationship,
				dateOfBirth: this.state.dob,
				createdAt: this.state.createdAt
				
            },'',this.props.user.data.JWT,
			(result) => { 
				if(result.status === 200 ){
					Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
					this.props.navigation.navigate('FamilyMembers', { refresh: true })
				}
				else {  
					this.setState({isLoading: false}); 	
					Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)			
				}
			},
			(error) => {
				this.setState({isLoading: false});
				Toast.showWithGravity(error.data.MESSAGE, Toast.LONG, Toast.TOP)
			});
		}
	  }
	  
	gender =(gender)=>{
		this.checkValidation(gender,"GENDER");
		this.setState({gender:gender, defaultRelationship: null, relationship:null, errGender:''})
	}

	relationship =(id)=>{
		this.setState({ maximumDate:null,minDate: null,dateCheck:true,isFatherCheck:false,isMotherCheck:false});
		this.checkValidation(id,"RELATIONSHIP")
		if(id =="அப்பா"){
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ maximumDate: dob - 18, relationship: id, errRelationship:'',  defaultRelationship: id,});
			this.getFamilyMembers(1);
		}
		if(id =="அம்மா"){
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ maximumDate: dob - 18,  relationship: id, errRelationship:'',  defaultRelationship: id,});
			this.getFamilyMembers(2);
		}
		if(id =="மகன்"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			var dobCal = currentYear - dob;
			if(dobCal >= 18){				
				this.setState({ minDate: parseInt(dob) + parseInt(18), maximumDate: parseInt(currentYear)-parseInt(1), defaultRelationship: id,  relationship: id, errRelationship:''});
			}else{
				this.setState({dateCheck:false,defaultRelationship: id,  relationship: id, errRelationship: "Your son/daughter not age in 18"})
			}
		}
		if(id =="மகள்"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			var dobCal = currentYear - dob;
			if(dobCal >= 18){				
				this.setState({ minDate: parseInt(dob) + parseInt(18), maximumDate: parseInt(currentYear)-parseInt(1), defaultRelationship: id,  relationship: id, errRelationship:''});
			}else{
				this.setState({dateCheck:false,defaultRelationship: id,  relationship: id, errRelationship: "Your son/daughter not age in 18"})
			}
		}
		if(id =="அண்ணன்"){
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ maximumDate:dob, relationship: id, errRelationship:'',  defaultRelationship: id,});
		}
		if(id =="அக்கா"){
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ maximumDate:dob,  relationship: id, errRelationship:'', defaultRelationship: id,});
		}
		if(id =="தம்பி"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ minDate:dob, maximumDate: parseInt(currentYear)-parseInt(1), relationship: id,  defaultRelationship: id, errRelationship:''});
		}
		if(id =="தங்கச்சி"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ minDate:dob, maximumDate: parseInt(currentYear)-parseInt(1),  defaultRelationship: id, relationship: id, errRelationship:''});
		}		
		if(id =="கணவன்"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({ minDate:dob - parseInt(20), maximumDate: parseInt(currentYear)-parseInt(15), defaultRelationship: id, relationship: id, errRelationship:''});
		}
		if(id =="மனைவி"){
			var currentYear = moment().format('YYYY');
			var dob =  moment(this.props.user.data.DATA.dateOfBirth).format('YYYY');
			this.setState({  minDate:dob - parseInt(10), maximumDate: parseInt(currentYear)-parseInt(15), defaultRelationship: id, relationship: id, errRelationship:''});
		}
	}


	render() {

		var gender_props = [
			{label: 'ஆண் (Male)', value: "Male" },
			{label: 'பெண் (Female)', value: "Female" }
		  ];

		// var familyMembersMale =[
		// 	{label: 'அப்பா', value: 'அப்பா'},
		// 	{label: 'மகன்', value: 'மகன்'},
		// 	{label: 'அண்ணன்', value: 'அண்ணன்'},
		// 	{label: 'தம்பி', value: 'தம்பி'},
		// 	{label:  this.state.primaryGender !="Male"? 'கணவன்' : "", value: this.state.primaryGender !="Male"? 'கணவன்' : ""},
		// ];
		// var familyMembersFemale =[
		// 	{label: 'அம்மா', value: 'அம்மா'},
		// 	{label: 'மகள்', value: 'மகள்'},
		// 	{label: 'அக்கா', value: 'அக்கா'},
		// 	{label: 'தங்கச்சி', value: 'தங்கச்சி'},
		// 	{label:   this.state.primaryGender !="Female"? 'மனைவி' : "", value:  this.state.primaryGender !="Female"? 'மனைவி' : ""},
		// ]

		if(this.props.user.data.DATA.gender =="Male"){
			var familyMembersMale =[{label: 'அப்பா', value: 'அப்பா'},{label: 'மகன்', value: 'மகன்'},{label: 'அண்ணன்', value: 'அண்ணன்'},{label: 'தம்பி', value: 'தம்பி'}];
			var familyMembersFemale =[{label: 'அம்மா', value: 'அம்மா'},{label: 'மகள்', value: 'மகள்'},{label: 'அக்கா', value: 'அக்கா'},{label: 'தங்கச்சி', value: 'தங்கச்சி'},{label: 'மனைவி', value: 'மனைவி'}]
		}
		else{
		var familyMembersMale =[
			{label: 'அப்பா', value: 'அப்பா'},{label: 'மகன்', value: 'மகன்'},{label: 'அண்ணன்', value: 'அண்ணன்'},{label: 'தம்பி', value: 'தம்பி'},{label:'கணவன்', value: 'கணவன்'}];
			var familyMembersFemale =[{label: 'அம்மா', value: 'அம்மா'},{label: 'மகள்', value: 'மகள்'},{label: 'அக்கா', value: 'அக்கா'},{label: 'தங்கச்சி', value: 'தங்கச்சி'},{label: 'மனைவி', value: 'மனைவி'}]
		}
		
		
		return (			
			<React.Fragment>
				<Header title="திருத்தம்" navigation={this.props.navigation}/>
				<ScrollView>
					<View style={styles.container}>
						<View style={styles.textContainer}>
							<Text style={styles.lable}>பெயர் (Name) <Text  style={styles.mandatory}>*</Text></Text>
								<TextBox
									style={styles.textBox}
									placeholder="பெயர்"							      
									borderWidth={1}
									placeholderTextColor={ defaultTheme.colors.lighterGray}
									value= {this.state.name}
									onChange={name =>{this.setState({name:name},this.checkValidation(name,"NAME"))}}
																	
								/>
							<Text style={styles.errMsg}>{this.state.errName}</Text>
						</View>
						<View>
							<Text style={styles.lable}>பாலினம் (Gender) <Text  style={styles.mandatory}>*</Text></Text>
							<View style={styles.radioContainer}>
								<RadioForm
									radio_props={gender_props}
									labelStyle={styles.radioBtn}
									initial={((this.state.gender =="Male") ||(this.state.gender == "ஆண்") ? 0 : 1 )}
									formHorizontal={true}
									buttonColor={defaultTheme.colors.primary}
									labelColor={defaultTheme.colors.primary}
									selectedButtonColor={defaultTheme.colors.primary}
									buttonOuterColor={'red'}
									buttonInnerColor={'red'}
									buttonSize={14}
									animation={true}
									onPress={(value) => {this.gender(value)}}
								/>
								<Text style={styles.errMsg}>{this.state.errGender}</Text>
							</View>
						</View>
						<View style={styles.textContainer}>
							<Text style={styles.lable}>கைபேசி எண் (Mobile Number)</Text>
								<TextBox
									style={styles.textBox}
									placeholder="கைபேசி எண்"							      
									borderWidth={1}
									keyboardType="number"
									placeholderTextColor={ defaultTheme.colors.lighterGray}
									value= {this.state.mobileNo}
									onChange={mobileNo =>{this.setState({mobileNo:mobileNo},this.checkValidation(mobileNo,"MOBILENUMBER"))}}
								/>
							<Text style={styles.errMsg}>{this.state.errMobile}</Text>
						</View>
						<View style={styles.textContainer}>
							<Text style={styles.lable}>உறவு (Relationship)<Text  style={styles.mandatory}>*</Text> </Text>
							<View style={styles.mt12}>
								<DropDownPicker
									zIndex={10000}
									items={this.state.gender === "Male"? familyMembersMale : familyMembersFemale}
									defaultValue={this.state.defaultRelationship}
									containerStyle={{height: 50}}
									placeholder="உறவு"
									style={{backgroundColor: '#fafafa',borderColor: defaultTheme.colors.lighterGray}}
									itemStyle={{ justifyContent: 'flex-start'}}
									placeholderStyle={{color: defaultTheme.colors.lighterGray}}
									selectedLabelStyle={{color: defaultTheme.colors.gray}}
									dropDownStyle={{backgroundColor: '#fafafa'}}
									onChangeItem={item =>this.relationship(item.value)}
								/>
									<Text style={styles.errMsg}>{this.state.errRelationship}</Text>
							</View>
						</View>
						{(this.state.dateCheck == true) ? 
						<View style={styles.textContainer}>
							<Text style={styles.lable}>பிறந்த தேதி<Text  style={styles.mandatory}>*</Text> </Text>						
							<TouchableOpacity onPress={this._showDateTimePicker} style={styles.datePicker}>
								<Icon name="date-range" size={25}  style={styles.icons}/>
							{this.state.dob == ""?
							<Text style={styles.datePlaceholder}>பிறந்த தேதி </Text>:
							<Text style={styles.dateTime}>{moment(this.state.dob).format('DD-MM-YYYY')}</Text>}
							</TouchableOpacity>
							<DateTimePicker
								isVisible={this.state.isDateTimePickerVisible}
								mode='date'
								date={moment(`${this.state.dob}`).toDate()}
								minimumDate={new Date(this.state.minDate, 0, 1)}
								maximumDate={((this.state.relationship =="மகன்") ||(this.state.relationship =="மகள்") || (this.state.relationship =="தம்பி") || (this.state.relationship =="தங்கச்சி") ) ? new Date() : new Date(this.state.maximumDate, 11, 31)}
								onConfirm={this._handleDatePicked}
								onCancel={this._hideDateTimePicker}
							/>
							<Text style={styles.errMsg}>{this.state.errDob}</Text>						
						</View>:null}
						<View>
							<Button
								style={styles.button}
								btnName="சமர்ப்பிக்கவும்"
								color={defaultTheme.colors.white}
								size={16}							
								onPress={()=>this.editFamilyMembers()}
							/>
						</View>
					</View>
				</ScrollView>
    		</React.Fragment>
		);
	}
}

const styles = StyleSheet.create({
	container:{
		flex: 1,
		padding: 10
	},
	row:{
		flexDirection:'row',
		justifyContent:'space-between',
		paddingHorizontal: 5
	},
	radioContainer:{
		marginTop: 15
	},
	mt12:{
		marginTop: 12
	},
	textContainer: {
		paddingBottom: 4
	},
	textBox:{
		borderWidth : 1.5,
		borderRadius: 4,
		paddingBottom: 6,
		textAlignVertical: "top",
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		borderColor: defaultTheme.colors.lighterGray
	},
	textarea:{
		borderWidth : 1.5,
		borderRadius: 4,
		paddingBottom: 6,
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		borderColor: defaultTheme.colors.lighterGray
	},
	smallTextBox:{
		borderWidth : 1.5,
		borderRadius: 4,
		paddingBottom: 6,
		marginRight: 15,
		width: '90%',
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		borderColor: defaultTheme.colors.lighterGray
	},
	lable:{
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		fontSize:15,
		position:'relative'
	},
	photoText:{
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.gray,
		paddingTop: 45,
		fontSize:15,
		position:'relative'
	},
	bold:{
		fontWeight:'bold'
	},

	text:{
		color: defaultTheme.colors.white
	},
	radioBtn:{
		fontFamily: 'MeeraInimai-Regular',
		marginRight: 20,
		paddingTop:5
	},
	datePicker:{
		flexDirection:'row',
		alignItems:'center',
		borderBottomWidth : 1.5,
		marginVertical:10,
		borderRadius: 4,
		borderWidth : 1,
		borderColor: defaultTheme.colors.lighterGray,
		height: 45,
	},
	icons:{
		color: defaultTheme.colors.lighterGray,
		right:7 ,
		position: 'absolute'
	},
	dateTime:{
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 14,
		left:15 ,
		color: defaultTheme.colors.gray,
		position: 'relative'
	},
	datePlaceholder:{
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 14,
		left:15 ,
		color: defaultTheme.colors.lighterGray,
		position: 'relative'
	},
	mandatory:{
		color: defaultTheme.colors.red,	
	},
	button:{
		backgroundColor: defaultTheme.colors.primary,
		color: defaultTheme.colors.white,
		width:'100%',
		fontFamily: 'MeeraInimai-Regular',
	},
	errMsg:{
		color: defaultTheme.colors.red,
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 10,
		height: 15,
	}
  });
  function mapStateToProps(state) {
	return {
		user: state.loginReducer.user,
	};
}	
export default connect(mapStateToProps)(EditFamily);
