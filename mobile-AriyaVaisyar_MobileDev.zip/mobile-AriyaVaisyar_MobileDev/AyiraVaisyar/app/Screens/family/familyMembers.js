/* Package Import will lives here */
import React, { Component } from "react";
import {
	StyleSheet,
	Text,
	View,	
	TouchableOpacity,
	ScrollView,
	ActivityIndicator,
	FlatList
} from "react-native";
import {
	Menu,
	MenuOptions,
	MenuOption,
	MenuTrigger,
  } from 'react-native-popup-menu';
import Modal from 'react-native-modal';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Toast from 'react-native-simple-toast';
import moment from 'moment';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actions from '../../actions/loginAction';
/* Project Import will lives here */
import {Header, TextBox, Button, Loader} from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { SvgImages } from '../../assets/svgImges/svgImges';

class FamilyMembers extends Component {
	constructor(props) {
		super(props);
		this.state = {
			familyMembers:[],
			name: this.props.user.data.DATA.name,
			isModalVisible: false,
		}
    }
    
    componentDidMount (){
        this.getFamilyMembers();
	}
	
	componentDidUpdate(prevProps) {
        var params = this.props.route.params;
        if (params && params.refresh) {
            this.getFamilyMembers();
			this.props.route.params.refresh = false;
			this.props.route.params.userInfo = "";
        }
	}
	
	openModal = (id) => {
		this.setState({isModalVisible: true, selectedId: id});
		};

	cancelModal = () => {
		this.setState({isModalVisible: false, selectedId: ""});
		};

		deleteMember =()=>{
		apiService(`/api/familyMember/${this.state.selectedId}`, 'delete', '','',this.props.user.data.JWT,
		(result) => { 
			if(result.status === 200 ){
				this.setState({isModalVisible: false, selectedId: ''},function() {
					this.getFamilyMembers();                
				});
				Toast.showWithGravity(result.data.MESSAGE, Toast.LONG, Toast.TOP)
			}
			else {  
				this.setState({isLoading: false, isModalVisible: false,}); 				
			}
		},
		(error) => {
			this.setState({isLoading: false, isModalVisible: false,});
		});
	  }

    getFamilyMembers = ()=>{
		this.setState({isLoading: true});
		apiService(`/api/familyMembers/${this.props.user.data.DATA.id}`, 'get', '',false, this.props.user.data.JWT,	
			(result) => {
				if(result.status === 200){
					this.setState({familyMembers: result.data, isLoading: false});
				}
			},
			(error) => {
				this.setState({isLoading: false});
		});
	}

	render() {
		return (
			<React.Fragment>
				<Header title="குடும்ப உறுப்பினர்கள்" navigation={this.props.navigation}/>
                    <View style={styles.primaryInfo}/>
					<View style={styles.primaryContainer}>
						<View>
							<View style={styles.familyContainer}>
								<Text style={styles.primaryName}>{this.state.name}</Text>
							</View>
							<View style={styles.primary}>
								<Text style={styles.primaryLable}>முதன்மை பயனர்</Text>
							</View>
						</View>

					</View>
					<View style={styles.container}>
					<FlatList
						data={this.state.familyMembers}
						extraData={this.state}
						onEndReachedThreshold={0}
						keyExtractor={(item) => item.id.toString()}
						renderItem={({item}) =>	
                        <View style={styles.Card}>
                            <View style={styles.header}>
								<View  style={styles.row}>
									{SvgImages.user(25, 25)}
									<Text style={styles.headerTitle}>{item.name}</Text>
								</View>
								<Menu>
									<MenuTrigger text={<Icon name="more-horiz" style={styles.moreIcon}/>}  />
									<MenuOptions>
										<MenuOption onSelect={() => this.props.navigation.navigate("EditFamily", {userInfo:item})} >
											<Text style={styles.edit}>திருத்து</Text>
										</MenuOption>
										<MenuOption onSelect={() =>  this.openModal(item.id)} >
											<Text style={styles.delete}>நீக்கு</Text>
										</MenuOption>
									</MenuOptions>
								</Menu>
                            </View>
							<View style={styles.body}>
								<View style={styles.row}>
									<View style={styles.oneHalf}>
										{SvgImages.heart(20, 20)}
										<Text style={styles.text}>{item.relationship}</Text>	
									</View>
									<View style={styles.oneHalf}>
										{SvgImages.calenderSheet(20, 20)}
										<Text  style={styles.text}>{moment(item.dateOfBirth).format("DD/MM/YYYY")}</Text>
									</View>
									{(item.phone !="") && (item.phone != null) ?
									<View style={styles.oneHalf}>
										{SvgImages.phone(15, 15)}
										<Text style={styles.text}>{item.phone}</Text>
									</View> : null }
								</View>								
								{/* <View style={styles.row}>
									<View style={styles.oneHalf}>
										{SvgImages.gender(20, 20)}
										<Text  style={styles.text}>{item.gender}</Text>	
									</View>
									{(item.phone !="") && (item.phone != null) ?
									<View style={styles.oneHalf}>
										{SvgImages.phone(15, 15)}
										<Text style={styles.text}>{item.phone}</Text>
									</View> : null }
								</View> */}
							</View>
                        </View>
						}/>
					</View>

					<Modal isVisible={this.state.isModalVisible}
						animationInTiming={1000}
						animationOutTiming={1000}
						backdropTransitionInTiming={800}
						backdropTransitionOutTiming={800}
						>
						<View style={styles.popup}>
							<Text style={styles.confirmText}>நீங்கள் நிச்சயமாக நீக்க விரும்புகிறீர்களா?</Text>
							<View style={styles.popupbtn}>
								<TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
									<Text style={styles.popUpCancel}>ரத்து</Text>
								</TouchableOpacity>
								<TouchableOpacity style={styles.popbtn} onPress ={() => this.deleteMember()}>
									<Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
								</TouchableOpacity>
						</View>
						</View>
					</Modal>
                <TouchableOpacity style={styles.footer} onPress={()=>this.props.navigation.navigate("FamilyRegister")}>
                    <Icon name="add" style={styles.plus}/>
                    <Text style={styles.footerText}>குடும்ப உறுப்பினர்களைச் சேர்க்கவும்</Text>
                </TouchableOpacity>

    		</React.Fragment>
		);
	}
}

const styles = StyleSheet.create({
	container:{
		flex: 1,
		padding: 10,
	},
	row:{
		flexDirection:'row',
		justifyContent:'space-between',
		paddingHorizontal: 5
    },
    plus:{
		paddingLeft:30,
		fontSize:  40,
		color: defaultTheme.colors.gray
    },
    footer:{
        flexDirection:'row',
        justifyContent:'flex-start',
        alignItems:'center',
        backgroundColor: defaultTheme.colors.white,
        paddingVertical: 10
    },
    footerText:{
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontSize: 15,
        paddingLeft: 10
    },
    primaryInfo:{
        backgroundColor: defaultTheme.colors.primary,
        height: 80
	},
	primaryContainer:{
		backgroundColor: defaultTheme.colors.white,
		height: 80,
		borderRadius: 15,
		margin: 20,
		marginTop: -40
	},
	primaryName:{
		textAlign:'center',
		fontFamily: 'MeeraInimai-Regular',
		fontSize: 20,
		fontWeight:'bold',
		color: defaultTheme.colors.primary,
		marginTop: 22
	},
	primary:{
		flexDirection:'row',
		justifyContent:'center'
	},
	primaryLable:{
		backgroundColor: defaultTheme.colors.primary,
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.white,
		textAlign:'center',
		marginTop: 10,
		paddingTop: 5,
		borderRadius: 40,
		paddingVertical: 6,
		paddingHorizontal: 10
	},
	Card:{
		padding: 10,
		marginVertical: 10,
		borderWidth: 0.5,
		borderColor: defaultTheme.colors.lighterGray,
	},
	header:{
		flexDirection:'row',
		justifyContent:'space-between',
		paddingBottom:10,
		borderBottomColor: defaultTheme.colors.lightGray,
	},
	headerTitle:{
		color: defaultTheme.colors.gray,
		paddingTop:4,
		paddingHorizontal: 10,
		fontWeight:'bold'
	},
	body:{
		borderTopWidth: 0.5,
		borderColor: defaultTheme.colors.lighterGray
	},
	oneHalf:{
		flex: 1,
		marginTop: 15,
		flexDirection:'row',
		justifyContent:'flex-start',
		paddingVertical:6,
	},
	text:{
		fontFamily: 'MeeraInimai-Regular',
		paddingLeft: 7,
		color: defaultTheme.colors.gray,
		justifyContent:'flex-start'
	},
	icon:{
		paddingTop:3
	},
	edit:{
		color: defaultTheme.colors.gray,
		fontSize:22,
		alignItems:'center',
		paddingHorizontal:10,
		paddingTop:4,
		paddingBottom:5
	},
	popup:{
		backgroundColor:"#fff",
		height: 150,
	},
	confirmText:{
		marginTop: 20,
		textAlign:'center',
		justifyContent:'center',
		fontFamily: 'MeeraInimai-Regular',
	},
	popbtn:{
		flexDirection:'row',
		justifyContent:'center',
		alignItems:'center',
		marginTop: 20
	},
	popupbtn:{
		flexDirection:'row',
		alignItems:'center',
		justifyContent:'center',
		marginTop: 5
	},
	popUpbtnText:{
		backgroundColor: defaultTheme.colors.primary,
		color: defaultTheme.colors.white,
		borderWidth: 1,
		paddingTop:10,
		paddingHorizontal: 8,
		borderRadius: 4,
		marginHorizontal: 15,
		height:40,
		fontFamily: 'MeeraInimai-Regular',
	},
	popUpCancel:{
		borderWidth: 1,
		color: defaultTheme.colors.primary,
		paddingVertical: 7,
		paddingHorizontal: 8,
		paddingTop:10,
		marginHorizontal: 15,
		borderRadius: 4,
		height:40,
		fontFamily: 'MeeraInimai-Regular',
	},
	moreIcon:{
		fontSize: 25,
		marginTop:15,
		color: defaultTheme.colors.lighterGray
	},
	edit:{
		fontFamily:16,
		fontFamily: 'MeeraInimai-Regular',
		padding:8
	},
	delete:{
		fontFamily:16,
		fontFamily: 'MeeraInimai-Regular',
		color: defaultTheme.colors.red,
		padding:8
	}
  });
  
  function mapStateToProps(state) {
	return {
		user: state.loginReducer.user,
	};
}

function mapDispatchToProps(dispatch) {
	return bindActionCreators(
		Object.assign(
			{},
			actions,
		), dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(FamilyMembers);
