import React, {Component} from 'react';
import {
  SafeAreaView,
	StyleSheet,
	ScrollView,
	TouchableOpacity,
	View,
	Image,
	Text,
	StatusBar,
} from 'react-native';
import Logo from "../../assets/images/check.png";
import checked from "../../assets/images/checked.png";
import cancel from "../../assets/images/cancel.png";


import { Header, TextBox, Button, Loader } from "../../components";
import moment from 'moment';
import { connect } from 'react-redux';

class PaymentSuccess extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      paymentDetails: props.route.params.paymentDetails,
  

  }
  }
  
  componentDidMount() {
    console.log(this.state.paymentDetails);
    console.log(this.props.user.data.DATA)
    this.setState({isLoading:false}); 
}
gotoPaymentPage() {
  this.setState({isLoading:true}); 
  this.props.navigation.navigate("Payment")

}
  
  render() {
  
 
  return (
    <React.Fragment>
    <Header title="கட்டணம்" navigation={this.props.navigation} />
    <View style={styles.container}>

    {this.state.isLoading == true ?
        <Loader /> :
        <View>

{this.state.paymentDetails.STATUS == "TXN_SUCCESS" ?  
  <View>
  <Image source={checked}  style = {[styles.logo]} resizeMode = 'contain' />
  <Text style ={[styles.Text]}>
    Payment Successful!
  </Text>
  </View>: <View>
  <Image source={cancel}  style = {[styles.logo]} resizeMode = 'contain' />
  <Text style ={[styles.Text]}>
    Payment Failed!
  </Text>
  </View>
  }

  <View style = {styles.detailsConatiner}>
  <View style = {styles.details}>
  <Text style={[styles.amount]}>Name</Text>
  <Text style={[styles.id]}>{this.props.user.data.DATA.name}</Text>
  </View>
  <View style = {styles.mode}>
  <Text style={[styles.amount]}>Mobile Number</Text>
  <Text style={[styles.id]} selectable={true}>{this.props.user.data.DATA.phone}</Text>
  </View>
  <View style = {styles.mode}>
  <Text style={styles.transction}>Total Amount Of Paid</Text>
  <Text style={styles.amountnew}>{this.state.paymentDetails.TXNAMOUNT}</Text>
  </View>

  <View style = {styles.mode}>
  <Text style={[styles.amount]}>Gateway Name</Text>
  <Text style={[styles.id]} selectable={true}>{this.state.paymentDetails.GATEWAYNAME}</Text>
  </View>
  <View style = {styles.mode}>
  <Text style={[styles.paid]}>Payment Mode</Text>
  <Text style={[styles.type]}>{this.state.paymentDetails.PAYMENTMODE}</Text>
  </View>

  <View style = {styles.Date}>
  <Text style={[styles.transactiondate]}>Transaction Date</Text>
  <Text style={[styles.transactiondatenew]}>{moment(this.state.paymentDetails.TXNDATE).format('DD-MM-YYYY hh:mm A')} </Text>
  </View>

  <View style = {styles.Date}>
  <Text style={[styles.transactiondate]}>Transaction ID</Text>
  <Text style={[styles.transactiondatenew]} selectable={true}>{this.state.paymentDetails.TXNID}</Text>
  </View>
  <View style = {styles.Date}>
  <Text style={[styles.transactiondate]}>Status</Text>
  <Text style={[styles.transactiondatenew]}  selectable={true}>{this.state.paymentDetails.RESPMSG}</Text>
  </View>
  </View>
 

 </View>

  }
  </View>
  <TouchableOpacity style={styles.footer} onPress={() => this.gotoPaymentPage()}>
                     <Text style={styles.footerText}>DONE</Text>
    </TouchableOpacity>

       </React.Fragment>
  );
  }
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: 'white',

},
  root:{
   backgroundColor: 'white',
   padding:20,
   height:'100%',
   fontFamily: 'MeeraInimai-Regular',
},

logo: {
  alignSelf: 'center',
  width : 80,
  justifyContent: 'center',
 marginTop: -190,
 },
 detailsConatiner:{
  marginTop: 20,
  borderWidth: 1.5,
  borderRadius: 4,
  paddingBottom: 6,
  textAlignVertical: "top",
  fontFamily: 'MeeraInimai-Regular',
  color: defaultTheme.colors.gray,
  borderColor: defaultTheme.colors.lighterGray,
  paddingLeft:10
 },
 
Text: {
  color : '#52BE80',
  alignSelf: 'center',
  fontSize: 20,
  fontWeight: 'bold',
  marginTop: -200,
  fontFamily: 'MeeraInimai-Regular',

},
container2:{
  flexDirection:'row',
  justifyContent:'space-between',
  alignSelf: 'center',
  marginTop:5,  
},
transction:{
  flexDirection:'row',
  marginTop:5,  
  color:'black',
  flex:1,
  fontFamily: 'MeeraInimai-Regular',
  fontSize: 15,
},
id:{
  flexDirection:'row',
  marginTop:5,  
  color:'black',
  flex:1,
  fontWeight:'600',
  fontSize: 15,
  fontFamily: 'MeeraInimai-Regular',

},
details:{
  flexDirection:'row',
  justifyContent:'space-between',
  marginTop:10,  
  color:'black'
},
amount:{
  flexDirection:'row',
  marginTop:5,  
  color:'black',
  flex:1,
  fontFamily: 'MeeraInimai-Regular',
  fontSize: 15,


},
amountnew:{
  flexDirection:'row',
  marginTop:5,  
  color:'black',
  flex:1,
  fontWeight: 'bold',
  fontFamily: 'MeeraInimai-Regular',
  fontSize: 15,


},
mode:{
  flexDirection:'row',
  justifyContent:'space-between',
  marginTop:5, 
 },
 paid:{
  flexDirection:'row',
  marginTop:10,  
  color:'black',
  flex:1,
  fontFamily: 'MeeraInimai-Regular',
  fontSize: 15,


 },
 type:{
  flexDirection:'row',
  marginTop:5,  
  color:'black',
  flex:1,
  fontFamily: 'MeeraInimai-Regular',
  fontSize: 15,

 },
 Date:{
  flexDirection:'row',
  justifyContent:'space-between',
  marginTop:5, 
  fontSize: 15,

 },
 transactiondate:{
  flexDirection:'row',
  justifyContent:'space-between',
  marginTop:5, 
  color:'black',
  flex:1,
  fontFamily: 'MeeraInimai-Regular',
  fontSize: 15,

 },
 transactiondatenew:{
  flexDirection:'row',
  justifyContent:'space-between',
  marginTop:5,
  color:'black',
  flex:1,
  fontFamily: 'MeeraInimai-Regular',
  fontSize: 15,

 },
 popupbtn: {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  marginTop: 5,
  paddingBottom:20
},
popUpbtnText: {
  backgroundColor: '#52BE80',
  color: defaultTheme.colors.white,
  // borderWidth: 1,
  paddingTop: 10,
  paddingHorizontal: 8,
  borderRadius: 4,
  marginHorizontal: 15,
  height: 40,
  fontFamily: 'MeeraInimai-Regular',
},
popbtn: {
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: 20
},
footer: {
  flexDirection: 'row',
  justifyContent: 'flex-start',
  alignItems: 'center',
  backgroundColor: "#52BE80",
  paddingVertical: 13
},
footerText: {
  fontFamily: 'MeeraInimai-Regular',
  color: "#fff",
  fontSize: 18,
  paddingLeft: 150,
  fontWeight: 'bold',
},
});


function mapStateToProps(state) {
  return {
      user: state.loginReducer.user,
  };
}
export default connect(mapStateToProps)(PaymentSuccess);