/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image,
    ScrollView,
    TextInput,
    FlatList,
    Share,
    Linking ,
} from "react-native";
import { connect } from 'react-redux';
import ImageModal from 'react-native-image-modal';
import moment from 'moment';
import {
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger,
} from 'react-native-popup-menu';
import Toast from 'react-native-simple-toast';
import Modal from 'react-native-modal';
import Icon from 'react-native-vector-icons/MaterialIcons';
import ImagePicker from 'react-native-image-picker';
import { ApiUrls } from '../../api/apiUrls';
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import apiService from "../../utils/apiService";
import { SvgImages } from '../../assets/svgImges/svgImges';

class TermsAndConditions extends Component {
    constructor(props) {
        super(props);
        this.state = {
            description: ''

        }
    }

    onShare = async () => {
        try {
            const result = await Share.share({
                message: "https://play.google.com/store/apps/details?id=com.ayiravaisiyarnew&showAllReviews=true",
            });
            if (result.action === Share.sharedAction) {
                if (result.activityType) {
                    // shared with activity type of result.activityType
                } else {
                    // shared
                }
            } else if (result.action === Share.dismissedAction) {
                // dismissed
            }
        } catch (error) {
            alert(error.message);
        }
    };






    render() {
        return (
            <React.Fragment>
                <Header title="Terms and Conditions" navigation={this.props.navigation} />
                <View style={styles.container}>
                <ScrollView>
                        <Text style={styles.confirmText}>Terms and Conditions for Online Payment</Text>
                        <View style={styles.termsContainer}>                            
                            <Text style={styles.termsText}>
                            The Terms and Conditions contained herein shall apply to any person (“<Text style={styles.textBold}>User</Text>”) using the services of AYIRA VAISIYAR APPLICATION herein after called “<Text style={styles.textBold}>AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST</Text>” for making Fee payments through an online payment gateway service (“<Text style={styles.textBold}>Service</Text>”) and Payment Gateway Service provider, through AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST mobile app <Text
                                style={styles.urlLinkText}
                                onPress={() => {Linking.openURL('https://play.google.com/store/apps/details?id=com.ayiravaisiyarnew')}}>
                                    https://play.google.com/store/apps/details?id=com.ayiravaisiyarnew.
                            </Text>  Each User is therefore deemed to have read and accepted these Terms and Conditions.
                            </Text>
                            <Text style={styles.termsTextBold}>
                              A. Privacy Policy
                            </Text>
                            <Text style={styles.termsText}>
                              AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST respects and protects the privacy of the individuals that access the information and use the services provided through them. Individually identifiable information about the User is not wilfully disclosed to any third party without first receiving the User’s permission, as covered in this Privacy Policy. 
                            </Text>
                            <Text style={styles.termsText}>
                            This Privacy Policy describes AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST treatment of personally identifiable information that AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST collects when User is on the AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST  mobile app. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST does not collect any unique information about the User (such as User’s name, email address, age, gender etc.) except when the User specifically and knowingly provide such information on the mobile app. Like any business interested in offering the highest quality of service to clients, AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST may, from time to time, send  email and other communication to the User, tell them about the various services, features, functionality and content offered by AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST mobile app or seek voluntary information from you. 
                            </Text>
                            <Text style={styles.termsText}>
                            Please be aware, however, that AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST will release specific personal information about the User if required to do so in the following circumstances: 
                            </Text>
                            <Text style={styles.termsText}>
                            In order to comply with any valid legal process such as a search warrant, or court order, or any other judicial scrutiny. 
                            </Text>
                            <Text style={styles.termsText}>
                            If any of User’s actions on ‘AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST’ mobile app violate the Terms of Service or any of AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST guidelines for specific services, or
                            </Text>
                            <Text style={styles.termsText}>
                            To protect or defend ‘AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST’ legal rights or property, the AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST mobile app, or AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST Users; or
                            </Text>
                            <Text style={styles.termsText}>
                            To investigate, prevent, or take action regarding illegal activities, suspected fraud, situations involving potential threats to the security, integrity of AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST mobile app/offerings.
                             </Text>  
                             <Text style={styles.termsTextBold}>
                             B. General Terms and Conditions For Online-Payments
                            </Text> 
                            <Text style={styles.termsText}>
                               1. Once a User has accepted these Terms and Conditions, he/ she may register and avail the Services. A User may either register on  form if any else full name of the client’s mobile app or alternatively enter his/ her Roll number and pay their dues/ fees in any other manner as may be specified by AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST from time to time.
                            </Text>
                            <Text style={styles.termsText}>
                               2. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST rights, obligations, undertakings shall be subject to the laws in force in India, as well as any directives/ procedures of Government of India, and nothing contained in these Terms and Conditions shall be in derogation of AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST right to comply with any law enforcement agencies request or requirements relating to any User’s use of the mobile app or information provided to or gathered by AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST with respect to such use. Each User accepts and agrees that the provision of details of his/ her use of the mobile app to regulators or police or to any other third party in order to resolve disputes or complaints which relate to the mobile app shall be at the absolute discretion of AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST.  
                            </Text>
                            <Text style={styles.termsText}>
                               3. If any part of these Terms and Conditions are determined to be invalid or unenforceable pursuant to applicable law including, but not limited to, the warranty disclaimers and liability limitations set forth herein, then the invalid or unenforceable provision will be deemed superseded by a valid, enforceable provision that most closely matches the intent of the original provision and the remainder of these Terms and Conditions shall continue in effect.  
                            </Text>
                            <Text style={styles.termsText}>
                            4. These Terms and Conditions constitute the entire agreement between the User and AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST. These Terms and Conditions supersede all prior or contemporaneous communications and proposals, whether electronic, oral, or written, between the User and COLLPOLL. A printed version of these Terms and Conditions and of any notice given in electronic form shall be admissible in judicial or administrative proceedings based upon or relating to these Terms and Conditions to the same extent and subject to the same conditions as other business documents and records originally generated and maintained in printed form.
                            </Text>
                            <Text style={styles.termsText}>
                            5. The entries in the books of AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST and/or the Payment Service Providers kept in the ordinary course of business of AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST and/or the Payment Service Providers with regard to transactions covered under these Terms and Conditions and matters therein appearing shall be binding on the User and shall be conclusive proof of the genuineness and accuracy of the transaction. 
                            </Text>
                            <Text style={styles.termsText}>
                            6. Refund For Charge Back Transaction: In the event there is any claim for/ of charge back  by the User for any reason whatsoever, such User shall immediately approach AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST with his/ her claim details and claim refund from AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST alone. Such refund (if any) shall be effected only by AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST by means as AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST deems appropriate. No claims for refund/ charge back shall be made by any User to the Payment Service Provider(s) and in the event such claim is made it shall not be entertained. 
                            </Text>
                            <Text style={styles.termsText}>
                            7. In these Terms and Conditions, the term “Charge Back” shall mean, approved and settled credit card or net banking purchase transaction(s) which are at any time refused, debited or charged back to merchant account (and shall also include similar debits to Payment Service Provider’s accounts, if any) by the acquiring bank or credit card company for any reason whatsoever, together with the bank fees, penalties and other charges incidental thereto.
                            </Text>
                            <Text style={styles.termsText}>
                            8. Refund for fraudulent/duplicate transaction(s):  The User shall directly contact AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST for any fraudulent transaction(s) on account of misuse of Card/ Bank details by a fraudulent individual/party and such issues shall be suitably addressed by AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST alone in line with their policies and  rules.  
                            </Text>
                            <Text style={styles.termsText}>
                            9. Server Slow Down/Session Timeout: In case the mobile app or Payment Service Provider’s webpage, that is linked to the mobile app, is experiencing any server related issues like ‘slow down’ or ‘failure’ or ‘session timeout’, the User shall, before initiating the second payment, check whether his/her Bank Account has been debited or not and accordingly resort to one of the following options:   
                            </Text>
                            <Text style={styles.termsText}>
                            (I) In case the Bank Account appears to be debited, ensure that he/ she does not make the payment twice and immediately thereafter contact AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST via e-mail or any other mode of contact as provided by AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST to confirm payment.   
                            </Text>
                            <Text style={styles.termsText}>
                            (ii) In case the Bank Account is not debited, the User may initiate a fresh transaction to make payment.
                            </Text>
                            <Text style={styles.termsText}>
                            However, the User agrees that under no circumstances the Payment Gateway Service Provider shall be held responsible for such fraudulent/duplicate transactions and hence no claims should be raised to Payment Gateway Service Provider.  No communication received by the Payment Service Provider(s) in this regards  shall be entertained by the Payment Service Provider(s).  
                            </Text>
                            <Text style={styles.termsTextBold}>
                            C. Limitation of Liability
                            </Text>
                            <Text style={styles.termsText}>
                            1. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST has made this Service available to the User as a matter of convenience. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST expressly   disclaims any claim or liability arising out of the provision of this Service. The User agrees and acknowledges that he/ she shall be solely responsible for his/ her conduct and that AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST reserves the right to terminate the rights to use of the Service immediately without giving any prior notice thereof.
                            </Text>
                            <Text style={styles.termsText}>
                            2. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST and/or the Payment Service Providers shall not be liable for any inaccuracy, error or delay in, or omission of (a) any data, information or message, or (b) the transmission or delivery of any such data, information or message; or (c) any loss or damage arising from or occasioned by any such inaccuracy, error, delay or omission, non-performance or interruption in any such data, information or message. Under no circumstances shall the AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST and/or the Payment Service Providers, statutory and non-statutory officers, employees and its third party agents  involved in processing, delivering or managing the Services, be liable for any direct, indirect, incidental, special or consequential damages, or any damages whatsoever, including punitive or exemplary  arising out of or in any way connected with the provision of or any inadequacy or deficiency in the provision of the Services or resulting from unauthorized access or alteration of transmissions of data or arising from suspension or termination of the Services.     
                            </Text>
                            <Text style={styles.termsText}>
                            3. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST and the Payment Service Provider(s) assume no liability whatsoever for any monetary or other damage suffered by the User on account of:   
                            </Text>
                            <Text style={styles.termsText}>
                            (I) the delay, failure, interruption, or corruption of any data or other information transmitted in connection with use of the Payment Gateway or Services in connection thereto; and/ or     
                            </Text>
                            <Text style={styles.termsText}>
                            (ii) Any interruption or errors in the operation of the Payment Gateway.  
                            </Text>
                            <Text style={styles.termsText}>
                            4. The User shall indemnify and hold harmless the Payment Service Provider(s) and AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST and their respective officers, directors, agents, and employees, from any claim or demand, or actions arising out of or in connection with the utilization of the Services.
                            </Text>
                            <Text style={styles.termsText}>
                            5. The User agrees that AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST or any of its employees will not be held liable by the User for any loss or damages arising from your use of, or reliance upon the information contained on the mobile app, or any failure to comply with these Terms and Conditions where such failure is due to circumstance beyond AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST reasonable control.   
                            </Text>
                            <Text style={styles.termsTextBold}>
                            D. Miscellaneous Conditions:   
                            </Text>
                            <Text style={styles.termsText}>
                            1. Any waiver of any rights available to AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST under these Terms and Conditions shall not mean that those rights are automatically waived. 
                            </Text>
                            <Text style={styles.termsText}>
                            2. The User agrees, understands and confirms that his/ her personal data including without limitation details relating to debit card/ credit card transmitted over the Internet may be susceptible to misuse, hacking, theft and/ or fraud and that AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST or the Payment Service Provider(s) have no control over such matters.   
                            </Text>
                            <Text style={styles.termsText}>
                            3. Although all reasonable care has been taken towards guarding against unauthorized use of any information transmitted by the User, AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST does not represent or guarantee that the use of the Services provided by/ through it will not result in theft and/or unauthorized use of data over the Internet.   
                            </Text>
                            <Text style={styles.termsText}>
                            4. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST, the Payment Service Provider(s) and its affiliates and associates shall not be liable, at any time, for any failure of performance, error, omission, interruption, deletion, defect, delay in operation or transmission, computer virus, communications line failure, theft or destruction or unauthorized access to, alteration of, or use of information contained on the mobile app.  
                            </Text>
                            <Text style={styles.termsText}>
                            5. The User may be required to create his/ her own User ID and Password in order to register and/ or use the Services provided by AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST on the mobile app. By accepting these Terms and Conditions the User agrees that his/ her User ID and Password are very important pieces of information and it shall be the User’s own responsibility to keep them secure and confidential. In furtherance hereof, the User agrees to;   
                            </Text>
                            <Text style={styles.termsText}>
                            {"\n"}
                            i. Choose a new password, whenever required for security reasons. {"\n"}
                            ii. Keep his/ her User ID & Password strictly confidential.
                            {"\n"}
                            iii. Be responsible for any transactions made by User under such User ID and Password.  
                            </Text>
                            <Text style={styles.termsText}>
                            The User is hereby informed that AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST will never ask the User for the User’s password in an unsolicited phone call or in an unsolicited email. The User is hereby required to sign out of his/ her AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST account on the mobile app and close the web browser window when the transaction(s) have been completed. This is to ensure that others cannot access the User’s personal information and correspondence when the User happens to share a computer with someone else or is using a computer in a public place like a library or Internet café.   
                            </Text>
                            <Text style={styles.termsTextBold}>
                            E. Debit/Credit Card, Bank Account Details   
                            </Text>
                            <Text style={styles.termsText}>
                            1. The User agrees that the debit/credit card details provided by him/ her for use of the aforesaid Service(s) must be correct and accurate and that the User shall not use a debit/ credit card, that is not lawfully owned by him/ her or the use of which is not authorized by the lawful owner thereof. The User further agrees and undertakes to provide correct and valid debit/credit card details.   
                            </Text>
                            <Text style={styles.termsText}>
                            2. The User may pay his/ her fees to AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST by using a debit/credit card or through online banking account. The User warrants, agrees and confirms that when he/ she initiates a payment transaction and/or issues an online payment instruction and provides his/ her card / bank details: 
                            </Text>
                            <Text style={styles.termsText}>
                            The User is fully and lawfully entitled to use such credit / debit card, bank account for such     transactions; 
                            </Text>
                            <Text style={styles.termsText}>
                            The User is responsible to ensure that the card/ bank account details provided by him/ her are accurate; 
                            </Text>
                            <Text style={styles.termsText}>
                            The User is authorizing debit of the nominated card/ bank account for the payment of fees selected by such User along with the applicable Fees. 
                            </Text>
                            <Text style={styles.termsText}>
                            The User is responsible to ensure sufficient credit is available on the nominated card/ bank account at the time of making the payment to permit the payment of the dues payable or the bill(s) selected by the User inclusive of the applicable Fee.
                            </Text>
                            <Text style={styles.termsTextBold}>
                            F. Personal Information 
                            </Text>
                            <Text style={styles.termsText}>
                            1. The User agrees that, to the extent required or permitted by law, AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST and/ or the Payment Service Provider(s) may also collect, use and disclose personal information in connection with security related or law enforcement investigations or in the course of cooperating with authorities or complying with legal requirements.   
                            </Text>
                            <Text style={styles.termsText}>
                            2. The User agrees that any communication sent by the User vide e-mail, shall imply release of information therein/ therewith to AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST. The User agrees to be contacted via e-mail on such mails initiated by him/ her. 
                            </Text>
                            <Text style={styles.termsText}>
                            3. In addition to the information already in the possession of AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST and/ or the Payment Service Provider(s), AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST may have collected similar information from the User in the past. By entering the mobile app the User consents to the terms of AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST information privacy policy and to AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST continued use of previously collected information. By submitting the User’s personal information to AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST, the User will be treated as having given his/her permission for the processing of the User’s personal data as set out herein. 
                            </Text>
                            <Text style={styles.termsText}>
                            4. The User acknowledges and agrees that his/ her information will be managed in accordance with the laws for the time in force.
                            </Text>
                            <Text style={styles.termsTextBold}>
                            G. Payment Gateway Disclaimer 
                            </Text>
                            <Text style={styles.termsText}>
                            The Service is provided in order to facilitate access to view and pay online. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST or the Payment Service Provider(s) do not make any representation of any kind, express or implied, as to the operation of the Payment Gateway other than what is specified in the mobile app for this purpose. By accepting/ agreeing to these Terms and Conditions, the User expressly agrees that his/ her use of the aforesaid online payment Service is entirely at own risk and responsibility of the User.  
                            </Text>
                            <Text style={styles.termsText}>
                            We at AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST value your privacy and understand how important it is for you. To that effect, we have the following privacy policy in place with regard to the collection, use and dissemination of personal information submitted to this mobile app. This document will help you understand the terms and conditions under which personal information is provided to this mobile app. Please note that this policy is effective only within AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST domain, and does not apply to mobile app that may be accessible from external links suggested at various pages of this mobile app. Please note that due to the very nature of internet technology and evolving threats, this policy may be updated from time to time. All such updates will be posted in the privacy policy page. By using this mobile app, you indicate your acceptance of the terms and policies mentioned here.
                            </Text>
                            <Text style={styles.termsTextBold}>
                            Information Collection and Use
                            </Text>
                            <Text style={styles.termsText}>
                            While you can use parts of this mobile app without providing any personal information, certain sections will only be accessible after you have registered with the mobile app by providing specific data. These sections include, but are not limited to Donations, Registration for matrimony postings, advertisements. The information collected by AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST will be used strictly for the purpose stated at the time of collection. Such information will not be sold, traded, rented or in any way transferred to a third party, including direct marketing companies and similar organizations for commercial purposes. However, AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST reveal the collected information to its selected employees, agents, consultants and others who the AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST should know. The Institute may also divulge the information to law enforcement authorities, courts and such others if need arises.  
                            </Text>
                            <Text style={styles.termsTextBold}>
                            System Information Including IP Addresses
                            </Text>
                            <Text style={styles.termsText}>
                            Information that is not personal in nature, i.e., IP addresses, web browsers and operating system details, browsing habits, demo-graphical and geographic data and other similar information may be logged and used to analyse and extrapolate information about general user behaviour within the AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST mobile app. Such extrapolations and statistics may be made public. However, they cannot be tracked to individual users. IP addresses are not linked to anything that can help identify the user. Neither are IP addresses, except in rare occasions, handed out to a third party.  
                            </Text>
                            <Text style={styles.termsTextBold}>
                            Cookies   
                            </Text>
                            <Text style={styles.termsText}>
                            This mobile app uses “cookies” to track usage and manage services on the mobile app. Cookies are small bits of data that may be transferred to the user’s hard drive when they log in or access a particular part of the mobile app. These are used for a variety of purposes including authentication and can be blocked by reconfiguring the appropriate settings in user’s web browser. Doing so, however, may restrict access to certain parts of the mobile app. Through their browser options the user can remove the cookies from their hard disk. Information collected through cookies cannot be traced back to the user as it contains no personally identifiable data like name, address or phone number.   
                            </Text>
                            <Text style={styles.termsTextBold}>
                            Online Forms
                            </Text>
                            <Text style={styles.termsText}>
                            The AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST uses online forms where you may be asked to provide certain bits of personal information. This is necessary to access certain services in the mobile app (e.g. matrimony, advertisements, books and Journals) or to take part in surveys. By filling out and submitting the form you are understood to have consented to AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST storing and using the information for the purposes for which it has been collected.
                            </Text>
                            <Text style={styles.termsTextBold}>
                            Security 
                            </Text>
                            <Text style={styles.termsText}>
                            At , AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST we take every possible precaution to ensure that your data is safe and secure barring circumstances beyond our control. Unfortunately, we cannot guarantee control over the medium of transmission i.e., internet. Though you have to supply the necessary information at your own risk, AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST always try to ensure the security and safety of the same. Once we receive the data, we will strive to keep it secure using the latest technology, constant upgrades to our digital security infrastructure and restricted access.  
                            </Text>
                            <Text style={styles.termsText}>
                            The link for mobile app in google store is: official mobile app of AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST is <Text
                                style={styles.urlLinkText}
                                onPress={() => {Linking.openURL('https://play.google.com/store/apps/details?id=com.ayiravaisiyarnew')}}>
                                "https://play.google.com/store/apps/details?id=com.ayiravaisiyarnew".
                            </Text>
                            </Text>
                            <Text style={styles.termsText}>
                            All its contents are for general information and use. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST provides no warranty, express or implied, regarding the quality, accuracy and completeness of that information. AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST will not be liable for any damage arising from the use of this site. The copyright of the proprietary material that appears remains solely with AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST
                            </Text>
                            <Text style={styles.termsText}>
                            For the sake of convenience, AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST may provide, links to mobile app operated by other entities/persons, but it does not endorse or accept any responsibility for the content, or the AYIRAVYSIAR EDUCATIONAL CHARITABLE TRUST use of such mobile app.    
                            </Text>

                        </View>
                       
                        {/* <View style={styles.popupbtn}>
                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                <Text style={styles.popUpCancel}>ரத்து</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.popbtn} onPress={() => this.agreeTermsAndCondition()}>
                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                            </TouchableOpacity>
                        </View> */}
                        </ScrollView>
                </View>
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        margin: 10
    },
    iosImage: {

    },
    shareBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },

    shareText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        paddingTop: 10,
        paddingHorizontal: 25,
        paddingVertical:8,
        borderRadius: 4,
        marginHorizontal: 15,
        fontFamily: 'MeeraInimai-Regular',
    },
    // popup start
    popup: {
        backgroundColor: "#fff",
        height: 400,
    },
    confirmText: {
        marginTop: 20,
        textAlign: 'center',
        justifyContent: 'center',
        fontFamily: 'MeeraInimai-Regular',
        fontWeight:'bold',
    },
    urlLinkText:{
        color:defaultTheme.colors.lightBlue,
    },
    termsText: {
        marginTop: 10,
        // textAlign: 'center',
        // justifyContent: 'center',
        paddingLeft:10,
        fontFamily: 'MeeraInimai-Regular',
    },
    termsTextBold:{
        fontWeight:'bold',
        marginTop:10,
        paddingLeft:10,
    },
    termsContainer:{
        // marginTop: 20,
        // textAlign: 'center',
        // justifyContent: 'center',
        // fontFamily: 'MeeraInimai-Regular',
    },
    textBold:{
        fontWeight:'bold',
    },
    popbtn: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20
    },
    popupbtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5,
        paddingBottom:20
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },


});

export default (TermsAndConditions);
