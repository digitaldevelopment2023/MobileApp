/* Package Import will lives here */
import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    FlatList,
    Image,
    ActivityIndicator,
    ScrollView,
    Linking ,
    CheckBox

} from "react-native";
import { connect } from 'react-redux';
import DropDownPicker from 'react-native-dropdown-picker';
// import { ScrollView, TextInput } from "react-native-gesture-handler";
/* Project Import will lives here */
import { Header, TextBox, Button, Loader } from "../../components";
import defaultTheme from "../../config/theme/default";
import { FormList } from "../../utils/common";
import apiService from "../../utils/apiService";
import { ApiUrls } from '../../api/apiUrls';
import { SvgImages } from '../../assets/svgImges/svgImges';
import RazorpayCheckout from 'react-native-razorpay';
import moment from 'moment';
import Toast from 'react-native-simple-toast';
import AllInOneSDKManager from 'paytm_allinone_react-native';
import Modal from 'react-native-modal';
import RadioForm, { RadioButton, RadioButtonInput, RadioButtonLabel } from 'react-native-simple-radio-button';


class Payment extends Component {
    constructor(props) {
        super(props);
        this.state = {
            donationType: [],
            isLoading: false,
            donationTypeValue: null,
            amountValue: null,
            isModalVisible: false,
            isModalVisible2: false,
            isSelected:false,
            paymentResultMessage:""

        }
    }


    componentDidMount() {
        // this.props.navigation.navigate("PaymentSuccess")

        this.state.donationType.push({ label: 'உறுப்பினர் கட்டணம் (Membership fee)', value: "Membership fee" },
            { label: 'நன்கொடை (Donation)', value: "Donation" },
            { label: 'வெளியீட்டிற்கு (For publication)', value: "For publication" },
            { label: 'நிறுவன செலவு (Organizational Expense)', value: "Organizational Expense" })
    }


    getPaymentKey = () => {
        apiService(`/api/rp/paymentSecretKey`, 'get', '', false, this.props.user.data.JWT,
            (result) => {
                if (result.status === 200) {
                    this.setState({ paymentKey: result.data.paymentSecretKey });
                }
            },
            (error) => {
            });
    }


    submitPayment = () => {
        var decimalAmount=parseFloat(this.state.amountValue).toFixed(2);
        console.log(decimalAmount)
        if (this.validation()) {
            this.setState({isLoading:true})
        apiService(`/api/paytmPayment/order`, 'post', {
            donationType: this.state.donationTypeValue,
            amount: this.state.amountValue,
            currency:"INR"
        }, '', this.props.user.data.JWT,
            (result) => {
                let jsonObjectParams = JSON.parse(result.data.paytmParams);
                let jsonObjectResponse = JSON.parse(result.data.Response);
                var paymentResult = jsonObjectResponse.body;
                var paymentResultParams = jsonObjectParams.body;
                console.log(paymentResult)

                console.log(paymentResultParams)

                this.setState({isLoading:false})
                if(paymentResult.resultInfo.resultMsg == "Success"){
                 const orderDetails={
                    orderId:paymentResultParams.orderId,
                    mid:paymentResultParams.mid,
                    tranxToken:paymentResult.txnToken,
                    amount: decimalAmount,
                    // callbackUrl:'https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID='+paymentResultParams.orderId,

                    callbackUrl:'https://securegw.paytm.in/theia/paytmCallback?ORDER_ID='+paymentResultParams.orderId,
                    isStaging:true,
                    appInvokeRestricted:true,
                    urlScheme:""
            
                }
              
                 this.paytmProcess(orderDetails)


                }else{
                    Toast.showWithGravity("Payment Failure - Server Side", Toast.LONG, Toast.TOP)
                }           
            
            },
            (error) => {
                this.setState({ isLoading: false });
            });  
        }

    }




    paytmProcess =  async(orderDetails) =>{
        console.log(orderDetails)
        try{
        AllInOneSDKManager.startTransaction(
            orderDetails.orderId,
            orderDetails.mid,
            orderDetails.tranxToken,
            orderDetails.amount,
            orderDetails.callbackUrl,
            false,
            true,
        )
        .then((result) => {
        console.log(result);
        if(result.STATUS == "TXN_SUCCESS"){
            this.props.navigation.navigate("PaymentSuccess", { paymentDetails: result })

            // this.setState({ isModalVisible: true });
            this.paymentCaptured(orderDetails.orderId);
            // Toast.showWithGravity("நன்கொடை செலுத்தப்பட்டது", Toast.LONG, Toast.TOP);
        }else{
            console.log(result);
            this.paymentFailed(orderDetails.orderId);
            // this.setState({paymentResultMessage:result.RESPMSG, isModalVisible2: true});
            // Toast.showWithGravity(result.RESPMSG, Toast.LONG, Toast.TOP);
            this.props.navigation.navigate("PaymentSuccess", { paymentDetails: result })
        }
 
        })
        .catch((err) => {
            this.props.navigation.navigate("Payment");
        // console.log("startTransaction error", err)
        });
        } catch (error) {
             this.props.navigation.navigate("Payment")
        }
         
    }


    paymentCaptured = (orderId) =>{
        apiService(`/api/paytmPayment/updateStatus`, 'post', {
            orderId: orderId,
            status:"captured",
        }, '', this.props.user.data.JWT,
            (result) => {
                console.log(result);
           
            },
            (error) => {
                this.setState({ isLoading: false });
            });        
}

paymentFailed = (orderId) =>{
    apiService(`/api/paytmPayment/updateStatus`, 'post', {
        orderId: orderId,
        status:"failed",
    }, '', this.props.user.data.JWT,
        (result) => {
            console.log(result);
       
        },
        (error) => {
            this.setState({ isLoading: false });
        });        
}



    openModal = () => {
        if (this.validation()) {
        this.setState({ isModalVisible: true });
        }
    };

    cancelModal = () => {
        this.setState({ isModalVisible: false,isModalVisible2: false});
    };

    agreeTermsAndCondition = () => {
        if(this.state.isSelected == false){
            this.setState({ isSelected: true,isSelectedErr:''});
        }else{
            this.setState({ isSelected: false});

        }
        // this.setState({ isModalVisible: false});
        // this.submitPayment();
    }

    gotoTermsAndCOndition= () => {
        this.props.navigation.navigate("TermsAndConditions")
    }
    validation = () => {
        const { donationTypeValue, amountValue,isSelected } = this.state;
        var valid = true
        this.setState({ typeErr: this.state.donationTypeValue != "" ? "" : this.state.typeErr, isSelectedErr: this.state.isSelected != false ? false : this.state.isSelectedErr,amountValueErr: this.state.amountValue != "" ? "" : this.state.amountValueErr });


        if (donationTypeValue == "" || donationTypeValue == null) {
            this.setState({ typeErr: "Please select donation type" })
            valid = false;
        }
        if (amountValue == "" || amountValue == null) {
            this.setState({ amountValueErr: "Please enter amount" })
            valid = false;
        }

        if (amountValue != null) {
            var amount = parseInt(amountValue);
            if(amount < 10){
                this.setState({ amountValueErr: "Enter a minimum amount of ₹10" })
                valid = false;
            }
        }
        if (isSelected == false) {
            this.setState({ isSelectedErr: "Please Accept Terms and Conditions" })
            valid = false;
        }
        return valid;
    }



    render() {
        var gender_props = [
			{ label: 'Terms and Conditions for Online Payment', value: "termsAndCondition" },
		];
        return (
            <React.Fragment>
                <Header title="கட்டணம்" navigation={this.props.navigation} />
                {this.state.isLoading == true ?
                    <Loader /> :
                <View style={styles.container}>
                    <View style={styles.placeContainer}>
                        <Text style={styles.lable}>நன்கொடை வகை (DonationType) <Text style={styles.mandatory}>*</Text></Text>
                        <View style={styles.mt12}>
                            <DropDownPicker
                                items={this.state.donationType}
                                containerStyle={{ height: 50 }}
                                placeholder="நன்கொடை வகை "
                                style={{ backgroundColor: '#fafafa', borderColor: defaultTheme.colors.lighterGray }}
                                itemStyle={{ justifyContent: 'flex-start' }}
                                placeholderStyle={{ color: defaultTheme.colors.gray }}
                                selectedLabelStyle={{ color: defaultTheme.colors.gray }}
                                dropDownStyle={{ backgroundColor: '#fafafa' }}
                                onChangeItem={item => this.setState({ donationTypeValue: item.value, typeErr: "" })}
                            />
                            <Text style={styles.errMsg}>{this.state.typeErr}</Text>
                        </View>


                        <View style={styles.textContainer}>
                            <Text style={styles.lableText}>தொகை (Amount) <Text style={styles.mandatory}>*</Text></Text>
                            <TextBox
                                style={styles.textBox}
                                keyboardType="number"
                                placeholder="தொகை (Amount)"
                                borderWidth={1}
                                placeholderTextColor={defaultTheme.colors.lighterGray}
                                value={this.state.amountValue}
                                onChange={amountValue => { this.setState({ amountValue: amountValue }) }}
                            />
                            <Text style={styles.errMsg}>{this.state.amountValueErr}</Text>
                        </View>

                        <View style={styles.textContainer}>
                        <View style={styles.checkboxContainer}>
                        <CheckBox
                        value={this.state.isSelected}
                        style={styles.checkbox}
                        onChange={isSelected => { this.agreeTermsAndCondition(isSelected) }}
                        />
                        <Text style={styles.checklabel} onPress={this.gotoTermsAndCOndition}>Terms and Conditions for Online Payment</Text>
                    </View>
                    <Text style={styles.errMsg}>{this.state.isSelectedErr}</Text>


                    </View>


                        {/* <View>
								<View style={styles.radioContainer}>
									<RadioForm
										radio_props={gender_props}
										labelStyle={styles.radioBtn}
										initial={-1}
										formHorizontal={true}
										buttonColor={defaultTheme.colors.primary}
										labelColor={defaultTheme.colors.primary}
										selectedButtonColor={defaultTheme.colors.primary}
										buttonOuterColor={'red'}
										buttonInnerColor={'red'}
										buttonSize={14}
										animation={true}
										onPress={(value) => { this.termsAndCondition(value) }}
									/>
									<Text style={styles.errMsg}>{this.state.errGender}</Text>
								</View>
							</View> */}

                    </View>

                    <View style={styles.popupbtn}>
                        <TouchableOpacity style={styles.popbtn}>
                            <Text style={styles.popUpCancel} onPress={() => this.props.navigation.navigate("Menu")}>ரத்து</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.popbtn} onPress={() => this.submitPayment()}>
                            <Text style={styles.popUpbtnText}>சமர்ப்பிக்கவும்</Text>
                        </TouchableOpacity>
                    </View>
                </View>
          } 
            <Modal isVisible={this.state.isModalVisible}
                    animationInTiming={1000}
                    animationOutTiming={1000}
                    backdropTransitionInTiming={800}
                    backdropTransitionOutTiming={800}
                >
                  <View style={styles.popup}>
                                        <Text style={styles.confirmText}>நன்கொடை செலுத்தப்பட்டது</Text>
                                        <View style={styles.popupbtn}>
                                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                                <Text style={styles.popUpCancel}>ரத்து</Text>
                                            </TouchableOpacity>
                                            {/* <TouchableOpacity style={styles.popbtn} onPress={() => this.deleteRegister()}>
                                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                                            </TouchableOpacity> */}
                                        </View>
                                    </View>
                </Modal>
                <Modal isVisible={this.state.isModalVisible2}
                    animationInTiming={1000}
                    animationOutTiming={1000}
                    backdropTransitionInTiming={800}
                    backdropTransitionOutTiming={800}
                >
                  <View style={styles.popup2}>
                                        <Text style={styles.confirmText}>{this.state.paymentResultMessage}</Text>
                                        <View style={styles.popupbtn}>
                                            <TouchableOpacity style={styles.popbtn} onPress={this.cancelModal}>
                                                <Text style={styles.popUpCancel}>ரத்து</Text>
                                            </TouchableOpacity>
                                            {/* <TouchableOpacity style={styles.popbtn} onPress={() => this.deleteRegister()}>
                                                <Text style={styles.popUpbtnText}>உறுதிப்படுத்தவும்</Text>
                                            </TouchableOpacity> */}
                                        </View>
                                    </View>
                </Modal>
            </React.Fragment>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    btncontainer: {
        flex: 1,
        padding: 20
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 10,
        marginBottom: 15
    },
    textBox: {
        borderWidth: 1.5,
        marginTop: 10,
        borderRadius: 4,
        paddingBottom: 5,
        paddingLeft: 10,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        borderColor: defaultTheme.colors.lighterGray
    },
    placeContainer: {
        // backgroundColor: defaultTheme.colors.primary,
        // minHeight: 460,
        // zIndex: 10
    },
    head: {
        flexDirection: 'row',
        height: 32,
        paddingLeft: 5
    },

    mt12: {
        margin: 10,
    },
    textContainer: {
        margin: 10,
        marginTop: -10
    },

    mainContainer: {
        position: 'relative',
        zIndex: 0,
        padding: 10,
        marginTop: 20,
        marginBottom: 365
    },
    content: {
        // paddingLeft: 5,
    },
    bottomText: {
        paddingLeft: 20
    },
    name: {
        marginTop: 15,
        fontFamily: 'MeeraInimai-Regular',
        color: defaultTheme.colors.gray,
        fontWeight: 'bold'
    },
    lable: {
        fontFamily: 'MeeraInimai-Regular',
        // color: defaultTheme.colors.white,
        fontSize: 15,
        top: 8,
        paddingLeft: 12,
        position: 'relative'
    },
    lableText: {
        fontFamily: 'MeeraInimai-Regular',
        // color: defaultTheme.colors.white,
        fontSize: 15,
        top: 8,
        paddingLeft: 5,
        position: 'relative'
    },
    mandatory: {
        color: defaultTheme.colors.red,
    },
    popupbtn: {
        // backgroundColor: defaultTheme.colors.white,
        // flexDirection: 'row',
        // alignItems: 'center',
        // justifyContent: 'center',
        // marginTop: 15,
        // paddingBottom:15
    },
    popUpbtnText: {
        backgroundColor: defaultTheme.colors.primary,
        color: defaultTheme.colors.white,
        borderWidth: 1,
        paddingTop: 10,
        paddingHorizontal: 8,
        borderRadius: 4,
        marginHorizontal: 15,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },
    errMsg: {
        color: defaultTheme.colors.red,
        fontFamily: 'MeeraInimai-Regular',
        fontSize: 12,
        paddingLeft: 4,
        paddingTop: 2
    },
    popUpCancel: {
        borderWidth: 1,
        color: defaultTheme.colors.primary,
        paddingVertical: 7,
        paddingHorizontal: 8,
        paddingTop: 10,
        marginHorizontal: 15,
        borderRadius: 4,
        height: 40,
        fontFamily: 'MeeraInimai-Regular',
    },

        // popup start
        popup: {
            backgroundColor: "#fff",
            height: 125,
        },
        popup2: {
            backgroundColor: "#fff",
            height: 145,
        },
        confirmText: {
            marginTop: 20,
            textAlign: 'center',
            justifyContent: 'center',
            fontFamily: 'MeeraInimai-Regular',
            fontWeight:'bold',
        },
        urlLinkText:{
            color:defaultTheme.colors.lightBlue,
        },
        termsText: {
            marginTop: 10,
            // textAlign: 'center',
            // justifyContent: 'center',
            paddingLeft:10,
            fontFamily: 'MeeraInimai-Regular',
        },
        termsTextBold:{
            fontWeight:'bold',
            marginTop:10,
            paddingLeft:10,
        },
        termsContainer:{
            // marginTop: 20,
            // textAlign: 'center',
            // justifyContent: 'center',
            // fontFamily: 'MeeraInimai-Regular',
        },
        textBold:{
            fontWeight:'bold',
        },
        popbtn: {
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            marginTop: 20
        },
        popupbtn: {
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            marginTop: 5,
            paddingBottom:20
        },
        popUpbtnText: {
            backgroundColor: defaultTheme.colors.primary,
            color: defaultTheme.colors.white,
            borderWidth: 1,
            paddingTop: 10,
            paddingHorizontal: 8,
            borderRadius: 4,
            marginHorizontal: 15,
            height: 40,
            fontFamily: 'MeeraInimai-Regular',
        },
        popUpCancel: {
            borderWidth: 1,
            color: defaultTheme.colors.primary,
            paddingVertical: 7,
            paddingHorizontal: 8,
            paddingTop: 10,
            marginHorizontal: 15,
            borderRadius: 4,
            height: 40,
            fontFamily: 'MeeraInimai-Regular',
        },
        checkboxContainer: {
            flexDirection: "row",
            // marginBottom: 20,
          },
          checkbox: {
            alignSelf: "center",
          },
          checklabel:{
            marginTop: 4,
            // color:defaultTheme.colors.lightBlue,
            borderBottomWidth:0.5,
            // borderBottomColor:defaultTheme.colors.lightBlue,
          }

});

function mapStateToProps(state) {
    return {
        user: state.loginReducer.user,
    };
}
export default connect(mapStateToProps)(Payment);
