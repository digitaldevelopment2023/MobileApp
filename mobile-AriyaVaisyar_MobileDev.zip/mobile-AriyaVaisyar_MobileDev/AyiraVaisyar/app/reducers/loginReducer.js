/* Project Import will be here */
import * as actions from '../actions/loginAction';
/* Project Import will be here */

/* Const,Let & Var will be here */
let cloneObject = function (obj) {
    return JSON.parse(JSON.stringify(obj));
};

let newState = {
    user: {
        data:'',
    }
   
};
/* Const,Let & Var will be here */

export default function (state = newState, action) {
    newState = cloneObject(state);
    switch (action.type) {

        case actions.LOGIN_SUCCESS:
            newState.user.data = action.data;   
            return newState;           
        default:
            return newState;
    }
}

