export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';


export function login(data) {
    return {
        type: LOGIN_SUCCESS,
        data:data,
    };
}
