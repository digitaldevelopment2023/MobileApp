export class ApiUrls {
    //  static apiEnvironment = "http://192.168.124.232:8080"; 
    // static apiEnvironment = "http://avs.furtimtechnologies.com";  // dev
    // static apiEnvironment = "https://new.ayiravaisya.com";      //Live
    static apiEnvironment = "https://new.ayiravysiar.com/";      //new-domain -Live
}