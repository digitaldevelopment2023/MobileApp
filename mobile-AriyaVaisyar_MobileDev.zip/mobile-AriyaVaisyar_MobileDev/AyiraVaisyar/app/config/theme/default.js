import { scale } from "../../utils";

/* Project Color Specification */
const color = {
	primary: "#0C1F38",
	secondory:'#262626',
	white: "#ffffff",
	black: "#000000",
	gray: '#444444',
	lightGray: '#ECEFF1',
	lighterGray:'#858080',
	yellow:'#FFC439',
	darkYellow:'#f9de20',
	green:'#27ae60',
	red:'#DA2A04',
	blue:'#2a62de',
	lightBlue:'#2196f3',
	transparentBlue: "rgba(10,35,62,0.8)",
	liteBorder:'#F5DEDE',
};
/* Project Color Specification */
/* Font Base Value */
const FontBaseValue = scale(16);
/* Font Base Value */

export default (defaultTheme = {
	name: "defaultTheme",
	colors: {
		primary: color.primary,
		secondory: color.secondory,
		white: color.white,
		black: color.black,
		gray: color.gray,
		lightGray: color.lightGray,
		lighterGray: color.lighterGray,
		yellow: color.yellow,
		darkYellow: color.darkYellow,
		green: color.green,
		red: color.red,
		blue: color.blue,
		lightBlue: color.lightBlue,
		transparentBlue: color.transparentBlue,
		liteBorder:color.liteBorder
	}
});
