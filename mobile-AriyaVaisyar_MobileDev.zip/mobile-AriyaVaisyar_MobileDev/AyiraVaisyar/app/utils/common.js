/* Project Import will lives here */
import { ApiUrls } from '../api/apiUrls';
import axios from 'axios';
// import { connect } from 'react-redux';
// import store from '../../app/store';
/* Project Import will lives here */

export const FormList = (callback) => {
    axios({
        method: 'get',
        url: `${ApiUrls.apiEnvironment}/unsecure/mobile/register/formlist`,
        headers: {
            'content-type': 'application/json',
            accept: 'application/json',
        }
    }).then((response) => {           
       if(response){ 
        if(typeof  callback === "function" )
            callback(response);
       }
    })    
    .catch(function (error) {
        console.log(error);
    });
}